AXM Adventure Pack 002 — The Roads Between (Casual Pack)

Take this ZIP in directly through the AXM Pocket Adventure Engine.
Do not extract it before import.

What is inside:
- 60 separate scene images cut from 5 multiverse contact boards
- lighter casual-adventure story flow
- 5 connected location clusters
- 7 reusable curiosity items
- wandering hooks for bus, door, reflection and robot

This pack is meant as a lighter, more playful follow-up intake.
