AXM Adventure Pack 003 — Strange Routes

Take this ZIP in directly through the AXM Pocket Adventure Engine.
Do not extract it before import.

What is inside:
- 60 separate cut scene images
- stranger and more adventurous casual story flow
- 5 connected location clusters
- 7 reusable curiosity items
- extra item interactions and a few returning hook moments

This intake leans more into: “oeh, what happens if I try this?”
