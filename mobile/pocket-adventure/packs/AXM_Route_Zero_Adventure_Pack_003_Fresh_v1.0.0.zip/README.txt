AXM Adventure Pack 003 — Route Zero: The Lantern Market

Keep this ZIP intact.
Open the permanent AXM Pocket Adventure Engine on your phone.
Tap TAKE IN and select this ZIP.

Fresh build contents:
- 60 newly cut scene images from the five fresh multiverse boards
- entirely new story and choice structure
- 7 mapped world regions
- 8 reusable curiosity items
- wandering unchosen-route hooks
- phone-friendly 4:5 WebP scene assets

No internet is needed after the pack has been imported.
