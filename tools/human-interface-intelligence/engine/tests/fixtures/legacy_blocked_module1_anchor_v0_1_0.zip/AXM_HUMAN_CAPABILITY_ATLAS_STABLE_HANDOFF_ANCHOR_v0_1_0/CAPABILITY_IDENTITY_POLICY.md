# AXM Human Capability Atlas — Capability Identity Policy

Policy version: 0.1.0  
Stable module: `axm.module.human_capability_atlas`  
Shared contract: `axm.capability-interface-contract` `0.1.0`

## 1. Stable capability ID

A `capability_id` is a case-sensitive source identity. Module One preserves the
exact declared string. It must not silently trim, recase, translate, regenerate,
or substitute the ID.

An invalid or missing ID is rejected or marked unresolved. The Atlas may propose
a repair, but a proposal is not a new authoritative ID.

## 2. Capability revisions

`capability_revision` describes technical capability revision, not documentation
wording. Preserve the source revision exactly. If absent, export `unknown` or the
contract-approved unknown representation.

A technical behavior, accepted input, produced output, irreversible effect,
security boundary, or dependency change normally requires a capability revision.

## 3. Renamed capabilities

A human-facing rename does not create a new capability and does not require a
technical revision. Preserve the same `capability_id`.

A machine-name change also preserves the stable capability ID when the source
explicitly declares continuity. Record the former name as an alias in the
identity/lifecycle evidence outside the shared record when no accepted shared
field exists.

## 4. Duplicates

Exact duplicate declarations are grouped but never silently deleted or merged.
Preserve every source reference and hash.

Two declarations sharing an ID but differing in technical meaning are
`CONFLICTED`, not duplicates to be averaged or auto-selected.

## 5. Aliases

An alias may point to a stable capability ID only when supported by an
authoritative source or an explicit reviewed identity decision. Aliases do not
replace the original source text and may not be used to hide conflicting IDs.

## 6. Capability splits

When one capability becomes multiple capabilities:

- preserve the original ID as deprecated or historical;
- issue distinct new IDs from an authoritative source;
- preserve a reviewed split relationship in lifecycle metadata;
- do not privately add unsupported relationship fields to the shared contract;
- request a shared-contract change when Module Two needs structured split data.

## 7. Capability merges

When several capabilities become one:

- preserve all former IDs as deprecated or historical;
- issue or identify the authoritative merged ID;
- preserve merge evidence and migration mapping;
- never silently redirect old IDs without a reviewed mapping.

## 8. Deprecated capabilities

Deprecated records remain discoverable. Preserve source identity, revision,
reason, replacement when known, and evidence. Deprecation does not mean deletion.

## 9. Removed capabilities

A removed capability becomes a tombstone in snapshot/lifecycle records. It must
not disappear from history. The tombstone records the last known identity,
revision, provenance, removal evidence, and replacement when known.

## 10. Human explanation changes

Changes to human wording, examples, course steps, categories, or tags do not
change technical capability identity or revision unless they reveal a real
technical correction.

Track explanation changes through the Atlas package version, changelog,
provenance, or an explanation-specific revision outside the shared technical
revision.

## 11. Conflicting source declarations

Preserve every conflicting source, hash, claim, and evidence reference. Mark
affected fields `CONFLICTED`. A canonical-selection proposal is not an automatic
resolution.

Conflict resolution requires an explicit review event. The original conflict
history remains append-only and auditable.
