"""Reference implementation of AXM-CJ-1 canonical JSON.

This file has no third-party dependencies.
"""

from __future__ import annotations
from decimal import Decimal
import hashlib
import json
import unicodedata


class DuplicateKeyError(ValueError):
    pass


def _pairs_no_duplicates(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise DuplicateKeyError(f"Duplicate JSON object key: {key!r}")
        out[key] = value
    return out


def loads(text: str):
    return json.loads(
        text,
        parse_float=Decimal,
        parse_int=Decimal,
        object_pairs_hook=_pairs_no_duplicates,
    )


def _number(value) -> str:
    if isinstance(value, bool):
        raise TypeError("Boolean is not a number here")
    if isinstance(value, int):
        d = Decimal(value)
    elif isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise ValueError("Non-finite number is forbidden")
        d = Decimal(str(value))
    elif isinstance(value, Decimal):
        d = value
    else:
        raise TypeError(f"Unsupported numeric type: {type(value)!r}")

    if not d.is_finite():
        raise ValueError("Non-finite number is forbidden")
    if d == 0:
        return "0"
    text = format(d, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return "0" if text in ("-0", "+0", "") else text


def canonicalize(value) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        return _number(value)
    if isinstance(value, str):
        return json.dumps(
            unicodedata.normalize("NFC", value),
            ensure_ascii=False,
            separators=(",", ":"),
        )
    if isinstance(value, list):
        return "[" + ",".join(canonicalize(item) for item in value) + "]"
    if isinstance(value, dict):
        normalized = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("AXM-CJ-1 object keys must be strings")
            nkey = unicodedata.normalize("NFC", key)
            if nkey in normalized:
                raise DuplicateKeyError(
                    f"Unicode normalization created duplicate key: {nkey!r}"
                )
            normalized[nkey] = item
        keys = sorted(normalized.keys())
        return "{" + ",".join(
            canonicalize(key) + ":" + canonicalize(normalized[key])
            for key in keys
        ) + "}"
    raise TypeError(f"Unsupported AXM-CJ-1 type: {type(value)!r}")


def canonical_sha256(value) -> str:
    return hashlib.sha256(canonicalize(value).encode("utf-8")).hexdigest()
