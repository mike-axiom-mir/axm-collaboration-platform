# Changelog

## 0.1.0 — 2026-08-05T00:37:10+00:00

- Established stable Module One identity and export anchor.
- Declared field authority boundaries.
- Defined capability identity, provenance, evidence-state, producer-state, and
  compatibility policies.
- Defined stable invariants for the ten shared fixtures without freezing mutable
  explanation or teaching output.
- Added AXM-CJ-1 canonical JSON and test vectors.
- Ran the real Atlas v0.5.0 against ten fixtures.
- Confirmed ten source-schema passes and ten shared Capability Record schema
  passes.
- Identified a real strict-evidence compatibility gap in six inferred human-name
  records.
- Did not run the real AXM registry, Module Two, or local integration.
