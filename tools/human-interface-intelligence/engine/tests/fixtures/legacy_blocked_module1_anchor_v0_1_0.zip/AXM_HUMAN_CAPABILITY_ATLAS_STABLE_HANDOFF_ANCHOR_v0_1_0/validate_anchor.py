from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import sys

from axm_canonical_json import loads, canonicalize, DuplicateKeyError

ROOT = Path(__file__).resolve().parent
HEX64 = re.compile(r"^[0-9a-f]{64}$")
AUTHORITY = {
    "SOURCE_AUTHORITATIVE",
    "ATLAS_EXPLANATORY",
    "SHARED_CONTRACT_OWNED",
    "DERIVED_WITH_EVIDENCE",
    "FORBIDDEN_TO_REDEFINE",
}

errors = []
checks = 0

def check(condition, message):
    global checks
    checks += 1
    if not condition:
        errors.append(message)

def load_json(name):
    path = ROOT / name
    check(path.is_file(), f"Missing file: {name}")
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"Invalid JSON {name}: {exc}")
        return {}

manifest = load_json("atlas_stable_handoff_manifest.json")
identity = load_json("MODULE_IDENTITY.json")
authority = load_json("FIELD_AUTHORITY_MAP.json")
provenance = load_json("PROVENANCE_AND_HASH_POLICY.json")
fixtures = load_json("STABLE_FIXTURE_INVARIANTS.json")
run_evidence = load_json("ATLAS_FIXTURE_RUN_EVIDENCE.json")
vectors = load_json("CANONICALIZATION_TEST_VECTORS.json")
inventory = load_json("FILE_INVENTORY_SHA256.json")

check(
    manifest.get("package_name") == "AXM_HUMAN_CAPABILITY_ATLAS_STABLE_HANDOFF_ANCHOR_v0_1_0",
    "Unexpected package name",
)
check(manifest.get("package_version") == "0.1.0", "Unexpected package version")
check(
    identity.get("stable_module_identifier") == "axm.module.human_capability_atlas",
    "Unexpected module identifier",
)
check(
    manifest.get("shared_contract", {}).get("identifier") == "axm.capability-interface-contract",
    "Unexpected shared-contract identifier",
)
check(
    manifest.get("shared_contract", {}).get("version") == "0.1.0",
    "Unexpected shared-contract version",
)

for field, entry in authority.get("fields", {}).items():
    check(entry.get("authority") in AUTHORITY, f"Invalid authority for {field}")

fixture_list = fixtures.get("fixtures", [])
check(len(fixture_list) == 10, f"Expected 10 fixture invariants, got {len(fixture_list)}")
ids = [item.get("capability_id") for item in fixture_list]
check(len(ids) == len(set(ids)), "Duplicate capability IDs in stable fixture invariants")
for item in fixture_list:
    identity_block = item.get("immutable_source_identity", {})
    check(
        bool(HEX64.match(identity_block.get("raw_source_sha256", ""))),
        f"Invalid raw source hash for {item.get('capability_id')}",
    )
    check(
        bool(HEX64.match(identity_block.get("source_record_axm_cj_1_sha256", ""))),
        f"Invalid canonical source record hash for {item.get('capability_id')}",
    )

records = run_evidence.get("records", [])
check(len(records) == 10, f"Expected 10 run-evidence entries, got {len(records)}")
for item in records:
    check(
        item.get("producer_execution_state") in {"RUN", "NOT_RUN", "UNVERIFIED"},
        f"Invalid producer state for {item.get('capability_id')}",
    )
    out_hash = item.get("output", {}).get("atlas_record_axm_cj_1_sha256", "")
    check(bool(HEX64.match(out_hash)), f"Invalid Atlas record hash for {item.get('capability_id')}")

for name, entry in manifest.get("shared_schema_sha256_hashes", {}).items():
    check(bool(HEX64.match(entry.get("sha256", ""))), f"Invalid shared-schema hash: {name}")

for vector in vectors.get("vectors", []):
    if "input_json" in vector:
        try:
            actual = canonicalize(loads(vector["input_json"]))
            check(actual == vector.get("expected_canonical"), f"Canonicalization mismatch: {vector.get('id')}")
            digest = hashlib.sha256(actual.encode("utf-8")).hexdigest()
            check(digest == vector.get("canonical_sha256"), f"Canonical hash mismatch: {vector.get('id')}")
        except Exception as exc:
            errors.append(f"Canonicalization vector error {vector.get('id')}: {exc}")
    elif vector.get("id") == "unicode_key_normalization_collision":
        try:
            canonicalize({"é": 1, "e\u0301": 2})
            errors.append("Expected Unicode normalization collision was not rejected")
        except DuplicateKeyError:
            checks += 1

included = manifest.get("included_files", [])
for name in included:
    check((ROOT / name).is_file(), f"Manifest included file missing: {name}")

inventory_entries = inventory.get("files", [])
for entry in inventory_entries:
    path = ROOT / entry.get("path", "")
    check(path.is_file(), f"Inventory file missing: {entry.get('path')}")
    if path.is_file():
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        check(actual == entry.get("sha256"), f"Inventory hash mismatch: {entry.get('path')}")

if errors:
    print(f"FAIL — {len(errors)} errors across {checks} checks")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)

print(f"PASS — {checks} checks")
print("Note: this validates the standalone anchor package. It does not rerun the Atlas or Module Two.")
