# AXM Producer Execution-State Policy

Policy version: 0.1.0

## RUN

Use `RUN` only when the real declared Atlas implementation executed on the exact
identified source payload.

Required evidence:

- Atlas module ID and version;
- build, package, or commit identifier;
- source identity and source hash;
- execution timestamp;
- generated record hash;
- schema-validation result;
- run identifier or equivalent evidence entry.

A record may be `RUN` and still fail policy or schema validation. Execution state
describes whether the producer actually ran, not whether the result is trusted.

## NOT_RUN

Use `NOT_RUN` when the real Atlas did not execute on the represented source.

The following remain `NOT_RUN`:

- manually written examples;
- policy illustrations;
- copied Capability Records without a new run;
- fixture expectations;
- surrogate or mock outputs;
- records authored to resemble Atlas output.

## UNVERIFIED

Use `UNVERIFIED` when an execution or generated record is claimed or present but
the evidence chain is incomplete. Examples include missing build identity,
missing source hash, missing output hash, unknown producer version, or copied
records whose origin cannot be verified.

## Required transition behavior

- `NOT_RUN → RUN`: only after a real execution with full run evidence.
- `UNVERIFIED → RUN`: only after recovering and checking the complete evidence
  chain; do not merely relabel it.
- `RUN → UNVERIFIED`: when required evidence is later found missing, corrupted,
  or mismatched.
- Never infer `RUN` from valid-looking JSON or successful schema validation.

## Anchor creation state

During creation of this anchor, Atlas `0.5.0` genuinely executed on the
ten existing shared source fixtures. Their full generated records are not frozen
inside this package. Only immutable run evidence and hashes are retained.

The real AXM registry was `NOT_RUN` in this anchor-creation environment.
Module Two was `NOT_RUN`.
