# AXM Human Capability Atlas Stable Handoff Anchor v0.1.0

This package is a long-lived handshake anchor from Module One to Module Two.

It is intentionally separate from:

- the evolving Human Capability Atlas implementation;
- the canonical shared contract package;
- Module Two interface-selection logic.

It fixes only the rules, identifiers, authority boundaries, provenance behavior,
evidence meanings, producer-state meanings, compatibility expectations, and
stable fixture invariants that Module Two needs.

## Current anchors

- Module ID: `axm.module.human_capability_atlas`
- Current Atlas implementation observed: `0.5.0`
- Shared contract: `axm.capability-interface-contract` `0.1.0`
- Capability Record export format: `axm.shared-capability-record` `0.1.0`

## Important current compatibility finding

The real Atlas v0.5.0 was run against all ten shared fixtures while producing
this package. All ten source fixtures and generated Capability Records passed
their current canonical JSON Schemas.

However, six generated records contain inferred human names whose current
inference objects do not yet include all metadata required by the stable
evidence policy: reasoning, source basis, confidence, and evidence reference.

This anchor therefore remains `TEST-HOLD-REVIEW` for strict Module Two
consumption until that Module One export gap is repaired or explicitly handled
as policy-nonconformant.

## Validation

Run:

```text
python validate_anchor.py
```

The validator checks package structure, file hashes, canonicalization vectors,
authority values, fixture uniqueness, run evidence, and manifest consistency.
It does not claim to rerun the Atlas because the implementation and source
fixtures are deliberately not bundled here.
