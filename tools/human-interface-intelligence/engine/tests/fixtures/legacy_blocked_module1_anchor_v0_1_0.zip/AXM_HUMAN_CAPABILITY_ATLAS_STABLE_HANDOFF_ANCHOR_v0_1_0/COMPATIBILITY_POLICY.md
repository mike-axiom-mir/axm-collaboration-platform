# AXM Human Capability Atlas — Compatibility Policy

Policy version: 0.1.0

## Additive change

An additive change adds optional, namespaced, or separately packaged information
without changing existing required fields, field meanings, enum meanings,
canonicalization, hashes, IDs, or validation outcomes for existing valid
records.

Adding an enum value is not automatically additive because consumers may use
exhaustive logic.

## Compatible change

Examples:

- improving human wording without changing technical claims;
- adding optional examples or learning material;
- adding a new fixture without altering existing fixture invariants;
- improving internal Atlas architecture while preserving export behavior;
- fixing a bug that makes output conform to already-declared policy.

A compatible change still requires a changelog entry and suitable tests.

## Breaking change

Any of the following is breaking:

- changing a field type, required status, or semantic meaning;
- removing or renaming a field or enum value;
- changing a capability ID or identity rule;
- changing hash payload, algorithm, encoding, or canonicalization;
- changing evidence-state meaning or transition requirements;
- changing producer-state meaning;
- making previously valid records invalid without migration;
- silently moving responsibility between Module One and Module Two.

## Deprecation

A deprecated field, enum, format, or behavior remains supported for at least one
published transition version unless an urgent integrity issue makes continued
support unsafe.

Deprecation requires:

- changelog entry;
- replacement;
- migration path;
- first deprecated version;
- planned removal version when known;
- test coverage for old and new forms during transition.

## Migration requirement

Every breaking change requires:

- a new shared-contract or export-format version;
- machine-readable migration or deterministic conversion rules where possible;
- before/after examples;
- negative tests;
- rollback guidance;
- explicit Merge Gate review.

## Shared-contract change request

When Module One or Module Two needs a shared field or semantic not present in the
contract, create a change request containing:

1. requested field or semantic;
2. owner and authority;
3. reason and use cases;
4. schema diff;
5. compatibility impact;
6. migration plan;
7. positive and negative fixtures;
8. acceptance decision.

Neither module may use the proposed field in canonical shared exports before the
change is accepted.

## Minimum notice and changelog

There is no reliable time-based notice requirement for an offline/local system.
The minimum is version-based:

- no silent mutation within an already published version;
- every change receives a changelog entry;
- breaking changes receive a version bump and migration document;
- removal normally follows at least one published deprecation version;
- urgent integrity fixes document why normal notice was shortened.

## Needed field absent from shared contract

Module One may retain internal information in its own private implementation or
a clearly separate module-specific sidecar. It must not inject the field into
the canonical shared Capability Record.

Module One must file a shared-contract change request when Module Two needs that
information for interoperable behavior.

## Contract fork prohibition

`axm.module.human_capability_atlas` and Module Two may not publish different meanings under the same
contract identifier and version. A schema-hash mismatch is a compatibility
failure, not a harmless variation.
