# AXM Evidence State Policy

Policy version: 0.1.0  
Shared serialization tokens in contract `0.1.0` are lowercase. Their stable
semantic names are shown in uppercase below.

| Stable meaning | Serialized token |
|---|---|
| KNOWN | `known` |
| INFERRED | `inferred` |
| UNKNOWN | `unknown` |
| CONFLICTED | `conflicted` |
| NOT_APPLICABLE | `not_applicable` |

## KNOWN

A value is directly supported by an authoritative source declaration, a
reproducible observation/test with provenance, or an explicit reviewed decision
whose authority is appropriate for that field.

A record-level source reference may support directly mapped source fields.
`KNOWN` does not mean universally true; it means known within the identified
scope and revision.

## INFERRED

A value is derived rather than directly declared. Every inferred value must
include:

- field path;
- inferred value;
- reasoning or rule;
- source basis;
- confidence from `0.0` to `1.0`;
- evidence reference;
- producer/build identity when machine-generated.

An inferred value may help explanation or classification but may not silently
become a technical capability claim.

## UNKNOWN

The available evidence is insufficient to assign a value honestly. Keep the
field visible as unknown. Missing documentation, unavailable sources, and
unsupported assumptions remain `UNKNOWN`.

## CONFLICTED

Two or more credible declarations or observations disagree. Preserve all
claims, provenance, hashes, scopes, and evidence references. Do not average,
hide, or silently select a winner.

## NOT_APPLICABLE

The field genuinely does not apply to this capability or context. Include an
applicability reason. Do not use `NOT_APPLICABLE` as a replacement for missing
information.

## Transition requirements

### UNKNOWN → INFERRED

Requires a deterministic or reviewed inference with all mandatory inference
metadata listed above.

### UNKNOWN → KNOWN

Requires a direct authoritative declaration, reproducible verified execution,
or reviewed evidence appropriate to the field authority.

### INFERRED → KNOWN

Requires evidence independent of the inference itself. Repeating the same rule
or model output is not confirmation.

### KNOWN or INFERRED → CONFLICTED

Occurs when credible contradictory evidence appears. Preserve the earlier state
and the new conflict evidence.

### CONFLICTED → KNOWN

Requires an explicit resolution event identifying the accepted claim, authority,
reason, and rejected or superseded claims. Conflict history remains preserved.

### Any evidence-bearing state → UNKNOWN

Allowed only when prior evidence is invalidated or lost and no adequate evidence
remains. Record the invalidation reason and audit event.

### NOT_APPLICABLE transitions

A change in capability scope or context may make the field applicable. Record
the reason and relevant revision or context change.

## Evidence sufficient for KNOWN

At least one of:

1. An authoritative source declaration with reproducible provenance.
2. A successful reproducible test or observation tied to the exact capability
   ID, revision, environment, procedure, result, and evidence artifact.
3. A reviewed human decision for a field whose authority permits human review.

Human-readable wording may be a faithful explanation of known facts, but the
wording itself does not authorize new technical behavior.
