AXM transactional intake fixture module3
