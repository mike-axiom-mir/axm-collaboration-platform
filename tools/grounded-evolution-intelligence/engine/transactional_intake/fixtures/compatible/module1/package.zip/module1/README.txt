AXM transactional intake fixture module1
