conflict fixture
