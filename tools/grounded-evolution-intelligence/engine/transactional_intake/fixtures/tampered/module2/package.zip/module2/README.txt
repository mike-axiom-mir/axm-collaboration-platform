AXM transactional intake fixture module2
