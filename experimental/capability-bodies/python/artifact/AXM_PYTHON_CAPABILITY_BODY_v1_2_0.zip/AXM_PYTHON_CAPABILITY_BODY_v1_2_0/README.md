# AXM Python Capability Body v0.9.0

Python continues as the rapidly matured **reference donor body** while HTML
remains the first code body already under live local testing.

v0.9 moves from individual engineering organs toward an **evidence pipeline for
large projects and real change sets**.

## SemanticChangeGraph

Change units can declare:

- `provides`
- `requires`
- `depends_on`

The graph resolves a requirement only when its provider is unique, or when an
explicit dependency selects exactly one provider.

Missing or ambiguous providers produce HOLD.

This avoids silently inventing semantic ordering from filenames or prose.

## StreamingRepositoryIndex

Very large repositories no longer require an eagerly materialized source
bundle merely to obtain a deterministic content index.

The stream index:

- requires explicit `READ_PROJECT_TREE`
- walks incrementally
- hashes files while walking
- emits deterministic pages
- refuses symlinks and special files
- applies file/byte limits
- ignores common generated/cache/vendor directories
- never mutates source

## AdvancedMemberFlow

Builds on the earlier member evidence with:

- properties / setters / deleters
- constructor parameter → instance attribute assignments
- classmethod / staticmethod classification
- local `super().method()` resolution
- local override evidence
- structural Protocol candidate matching

Protocol candidates are structural evidence only—not runtime typing proof.

## ChangePassport

A single deterministic packet can now aggregate:

- API passport before/after
- structural change risk
- affected tests
- prioritized tests
- dependency migration
- architecture before/after
- minimum Python grammar
- architecture policy evidence
- behavioral fixture structural validation
- optional static-adapter evidence
- optional sandbox-test evidence
- explicit evidence gaps

Possible outcome:

`EVIDENCE_COMPLETE_FOR_GOVERNANCE_REVIEW`

That still means:

- automatic release = false
- automatic merge = false
- automatic promotion = false
- automatic CANON = false

## Behavioral fixture sandbox plan

Behavior fixtures can now generate deterministic builtin-`unittest` source.

Execution readiness is decided by the existing hard-sandbox doctor.

No verified hard sandbox:

`HOLD_NO_VERIFIED_HARD_SANDBOX`

There is no host execution fallback.

## Host verified

Python 3.13

## Status

`DETACHED_CANDIDATE`


## Behavioral fixture execution

v0.9 includes the actual execution path as well as the plan.

The generated fixture test module is written only into a temporary shadow copy.
Execution is allowed only when the existing sandbox doctor reports a verified
hard provider. Otherwise the receipt is:

`HOLD_NO_VERIFIED_HARD_SANDBOX`

There is no ordinary-host fallback.


# v1.0 — Reference Freeze Candidate

The 1.0 rung changes the role of this package.

Python remains a usable local deterministic Python capability body, but it now
also ships machine-readable donor artifacts:

- `REFERENCE_BODY_BLUEPRINT.json`
- `PYTHON_REFERENCE_IMPLEMENTATION_MAP.json`
- `DONOR_INTAKE_CHECKLIST.json`
- `REFERENCE_FREEZE.md`

The blueprint describes the generic nine-layer code-body contract.

The implementation map shows where Python implements each layer without
requiring later languages to copy Python filenames or tools.

A candidate future language body can be assessed as partial maturity without
being forced to pretend it already implements every layer.

The self-audit verifies:

- manifest / runtime / pyproject version alignment
- authority ceiling consistency
- mandatory refusal authorities
- schema registry integrity
- manifest file references
- reference layers 0–8
- shipped Python compile validity
- symlink absence
- feature uniqueness
- static blueprint parity
- implementation-map parity
- implementation-module existence
- donor checklist roots

A passing self-audit produces a `REFERENCE_FREEZE_CANDIDATE` maturity state,
not automatic CANON.


# v1.1 — Verification Science

v1.0 froze the donor architecture. v1.1 deliberately does **not** add another
generic layer.

Instead it attacks the frozen donor with evidence:

- v1.0 reference blueprint digest regression lock
- deterministic syntax corpus
- independent-root module/project reproducibility
- repeated patch reproducibility
- hash-chained append-only regression ledger
- cache/rollback/authority/root-governance fault injection
- synthetic repository scale probe
- one orchestrated verification campaign receipt

The scale probe intentionally records functional outcomes rather than wall-clock
performance. It is not a benchmark SLA.

The reference blueprint is allowed to remain useful and frozen while the
verification harness continues to improve.


# v1.2 — Python Ecosystem Cheatcode Intake

v1.2 keeps the v1.0 generic donor blueprint frozen and adds Python-specific
evidence capabilities identified through current Python/GitHub ecosystem
research.

New lanes:

- PackagingTruth (`pyproject`, `pylock`, Import-Name / Import-Namespace evidence)
- SemanticConsensus (Pyright / Pyrefly / mypy / ty evidence)
- FineGrainedInvalidation (symbol-level change propagation)
- InterfacePolicy (public interface / visibility / ownership evidence)
- DeepFlowEvidence (CodeQL / Semgrep normalization without cloning their solvers)
- TestStrength (coverage contexts + mutation/property/symbolic evidence)
- optional LibCST lossless CST evidence
- optional preinstalled Pyrefly and ty analyzer adapters

The baseline AST/compile path remains the default deterministic core.

No third-party analyzer is automatically installed.

CrossHair, Hypothesis, mutation testing, runtime coverage contexts, fuzzing and
other execution-capable evidence remain behind the hard-sandbox authority
boundary.
