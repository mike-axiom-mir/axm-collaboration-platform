from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from axm_python_capability.implementation_map import build_python_implementation_map
from axm_python_capability.maturity import build_maturity_passport
from axm_python_capability.reference_blueprint import build_reference_blueprint
from axm_python_capability.self_audit import audit_package


def main() -> int:
    suite = unittest.defaultTestLoader.discover(
        start_dir=str(ROOT / "tests"),
        top_level_dir=str(ROOT),
    )
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    if not result.wasSuccessful():
        return 1

    blueprint = build_reference_blueprint()
    implementation = build_python_implementation_map()
    audit = audit_package(ROOT)
    if audit["status"] != "PASS":
        print(json.dumps(audit, indent=2, sort_keys=True))
        return 2

    manifest = json.loads((ROOT / "manifest.json").read_text())
    maturity = build_maturity_passport(
        self_audit=audit,
        test_count=result.testsRun,
        feature_count=len(manifest.get("features", [])),
        schema_count=len(list((ROOT / "schemas").glob("*.json"))),
    )

    assert maturity["maturity_state"] == "REFERENCE_FREEZE_CANDIDATE"
    assert maturity["automatic_canon"] is False

    print(json.dumps({
        "tests_run": result.testsRun,
        "blueprint": blueprint["blueprint_digest"],
        "implementation": implementation["implementation_digest"],
        "self_audit": audit["audit_digest"],
        "maturity": maturity["passport_digest"],
        "maturity_state": maturity["maturity_state"],
    }, sort_keys=True))
    print("SELFTEST PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
