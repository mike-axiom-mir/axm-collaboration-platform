import copy
import sys
import unittest

from axm_python_capability.errors import ContractError
from axm_python_capability.fault_campaign import run_fault_campaign
from axm_python_capability.regression_ledger import (
    append_regression_record,
    verify_regression_ledger,
)
from axm_python_capability.verification_corpus import CORPUS, run_corpus


HOST = f"{sys.version_info.major}.{sys.version_info.minor}"


class CorpusLedgerFaultTests(unittest.TestCase):
    def test_syntax_corpus_all_passes(self):
        result = run_corpus(HOST)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["case_count"], len(CORPUS))
        self.assertEqual(result["failure_count"], 0)
        self.assertGreaterEqual(result["case_count"], 25)

    def test_regression_ledger_is_deterministic(self):
        a = append_regression_record(None, {"kind": "test", "result": "PASS"})
        a = append_regression_record(a, {"kind": "test2", "result": "PASS"})
        b = append_regression_record(None, {"kind": "test", "result": "PASS"})
        b = append_regression_record(b, {"kind": "test2", "result": "PASS"})
        self.assertEqual(a, b)
        verify_regression_ledger(a)

    def test_regression_ledger_tamper_refused(self):
        ledger = append_regression_record(None, {"kind": "test"})
        tampered = copy.deepcopy(ledger)
        tampered["entries"][0]["record"]["kind"] = "tampered"
        with self.assertRaises(ContractError):
            verify_regression_ledger(tampered)

    def test_fault_campaign_all_passes(self):
        result = run_fault_campaign(HOST)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["summary"]["failed"], 0)
        self.assertGreaterEqual(result["summary"]["total"], 6)


if __name__ == "__main__":
    unittest.main()
