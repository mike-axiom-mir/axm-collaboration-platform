import json
import unittest
from pathlib import Path

from axm_python_capability.dead_code import dead_code_candidates
from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.reference_index import build_reference_index


ROOT = Path(__file__).resolve().parents[1]


class ReferenceAndDeadTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/reference_engineering_bundle.json").read_text())
        )

    def test_reference_index_resolves_from_import_and_attribute(self):
        b = self.bundle()
        index = build_reference_index(b["files"], b["target_python"], b["package"])
        targets = [
            (r["target"], r["resolution"])
            for r in index["references"]
        ]
        self.assertIn(
            ("refdemo.api.greet", "RESOLVED_IMPORTED_SYMBOL"),
            targets,
        )
        self.assertIn(
            ("refdemo.api.greet", "RESOLVED_IMPORTED_ATTRIBUTE"),
            targets,
        )

    def test_incoming_reference_count(self):
        b = self.bundle()
        index = build_reference_index(b["files"], b["target_python"], b["package"])
        self.assertGreaterEqual(
            index["incoming_reference_counts"]["refdemo.api.greet"],
            2,
        )

    def test_private_unreferenced_is_higher_confidence_candidate(self):
        b = self.bundle()
        result = dead_code_candidates(b["files"], b["target_python"], b["package"])
        candidates = {x["symbol"]: x for x in result["candidates"]}
        self.assertEqual(
            candidates["refdemo.api._unused_private"]["confidence"],
            "HIGHER",
        )
        self.assertFalse(candidates["refdemo.api._unused_private"]["automatic_delete"])

    def test_public_unreferenced_is_low_confidence_only(self):
        b = self.bundle()
        result = dead_code_candidates(b["files"], b["target_python"], b["package"])
        candidates = {x["symbol"]: x for x in result["candidates"]}
        self.assertEqual(
            candidates["refdemo.api.exported_but_unreferenced"]["confidence"],
            "LOW",
        )

    def test_test_symbols_are_not_dead_code_candidates(self):
        b = self.bundle()
        result = dead_code_candidates(b["files"], b["target_python"], b["package"])
        self.assertFalse(any(
            candidate["path"].startswith("tests/")
            for candidate in result["candidates"]
        ))

    def test_function_local_shadow_does_not_resolve_import(self):
        raw = {
            "schema": "axm.python-engineering-bundle.v1",
            "target_python": b["target_python"] if False else "3.13",
            "package": "shadowdemo",
            "dependencies": [],
            "files": [
                {
                    "path": "src/shadowdemo/api.py",
                    "source": "def greet(name: str) -> str:\n    return name\n",
                },
                {
                    "path": "src/shadowdemo/use.py",
                    "source": (
                        "from .api import greet\n\n"
                        "def use(greet):\n"
                        "    return greet('x')\n"
                    ),
                },
            ],
        }
        # Use the current interpreter minor instead of hard-coding a future grammar.
        import sys
        raw["target_python"] = f"{sys.version_info.major}.{sys.version_info.minor}"
        from axm_python_capability.engineering_bundle import normalize_engineering_bundle
        bundle = normalize_engineering_bundle(raw)
        index = build_reference_index(
            bundle["files"], bundle["target_python"], bundle["package"]
        )
        refs = [
            ref for ref in index["references"]
            if ref["path"] == "src/shadowdemo/use.py"
            and ref["raw"] == "greet"
        ]
        self.assertTrue(any(ref["resolution"] == "SHADOWED_LOCAL" for ref in refs))
        self.assertFalse(any(
            ref["target"] == "shadowdemo.api.greet"
            and ref["resolution"] == "RESOLVED_IMPORTED_SYMBOL"
            for ref in refs
        ))


if __name__ == "__main__":
    unittest.main()
