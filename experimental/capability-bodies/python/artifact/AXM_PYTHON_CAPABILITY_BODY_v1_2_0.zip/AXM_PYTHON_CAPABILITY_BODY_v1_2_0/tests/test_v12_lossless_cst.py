import unittest

from axm_python_capability.lossless_cst import (
    analyze_lossless_source,
    libcst_status,
)


class LosslessCSTTests(unittest.TestCase):
    def test_status_never_installs(self):
        status = libcst_status()
        self.assertFalse(status["automatic_install"])

    def test_optional_adapter_pass_or_not_installed(self):
        source = "# keep me\n\ndef f(x: int) -> int:\n    return (x + 1)  # trailing\n"
        result = analyze_lossless_source(source)
        self.assertIn(result["status"], {"PASS", "NOT_INSTALLED"})
        self.assertFalse(result["source_rewritten"])
        if result["status"] == "PASS":
            self.assertTrue(result["roundtrip_exact"])
            self.assertTrue(result["structural_nodes"])


if __name__ == "__main__":
    unittest.main()
