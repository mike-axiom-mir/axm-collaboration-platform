import json
import unittest
from pathlib import Path

from axm_python_capability.architecture_policy import check_architecture_policy
from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.test_priority import prioritize_affected_tests


ROOT = Path(__file__).resolve().parents[1]


class PolicyPriorityTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )

    def test_policy_pass(self):
        b = self.bundle()
        policy = json.loads((ROOT / "examples/architecture_policy.json").read_text())
        result = check_architecture_policy(
            b["files"], b["target_python"], policy, b["package"]
        )
        self.assertEqual(result["status"], "PASS")

    def test_policy_violation_detected(self):
        b = self.bundle()
        policy = {
            "schema": "axm.python-architecture-policy.v1",
            "policy_id": "bad",
            "rules": [{
                "rule_id": "api-cannot-import-service",
                "from_prefixes": ["demo.api"],
                "deny_to_prefixes": ["demo.service"],
            }],
        }
        result = check_architecture_policy(
            b["files"], b["target_python"], policy, b["package"]
        )
        self.assertEqual(result["status"], "VIOLATIONS")
        self.assertEqual(result["violations"][0]["rule_id"], "api-cannot-import-service")

    def test_test_priority_uses_dependency_distance(self):
        b = self.bundle()
        result = prioritize_affected_tests(
            b["files"], b["target_python"],
            ["src/demo/models.py"], b["package"],
        )
        rows = result["prioritized_tests"]
        self.assertTrue(rows)
        self.assertEqual(rows[0]["path"], "tests/test_api.py")
        self.assertGreater(rows[0]["priority_score"], 0)


if __name__ == "__main__":
    unittest.main()
