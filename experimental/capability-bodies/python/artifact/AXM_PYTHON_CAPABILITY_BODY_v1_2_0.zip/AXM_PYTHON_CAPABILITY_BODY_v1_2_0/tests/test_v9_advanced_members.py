import json
import unittest
from pathlib import Path

from axm_python_capability.advanced_members import advanced_member_flow
from axm_python_capability.engineering_bundle import normalize_engineering_bundle


ROOT = Path(__file__).resolve().parents[1]


class AdvancedMemberTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/advanced_member_bundle.json").read_text())
        )

    def test_property_and_constructor_flow(self):
        b = self.bundle()
        result = advanced_member_flow(
            b["files"], b["target_python"], b["package"]
        )
        child = next(
            x for x in result["classes"]
            if x["symbol"] == "adv.child.Child"
        )
        prop = next(x for x in child["properties"] if x["name"] == "display_name")
        self.assertIsNotNone(prop["getter"])
        self.assertIsNotNone(prop["setter"])
        self.assertTrue(any(
            x["attribute"] == "name" and x["parameter"] == "name"
            for x in child["constructor_assignments"]
        ))

    def test_method_kinds_and_super_resolution(self):
        b = self.bundle()
        result = advanced_member_flow(
            b["files"], b["target_python"], b["package"]
        )
        child = next(
            x for x in result["classes"]
            if x["symbol"] == "adv.child.Child"
        )
        self.assertEqual(child["methods"]["kind"]["kind"], "CLASSMETHOD")
        self.assertEqual(child["methods"]["version"]["kind"], "STATICMETHOD")
        self.assertTrue(any(
            x["resolution"] == "RESOLVED_LOCAL_SUPER_METHOD"
            and x["member"] == "speak"
            for x in result["super_calls"]
        ))

    def test_protocol_structural_candidate(self):
        b = self.bundle()
        result = advanced_member_flow(
            b["files"], b["target_python"], b["package"]
        )
        self.assertTrue(any(
            x["protocol"] == "adv.contracts.Speaker"
            and x["class"] == "adv.child.Child"
            and x["status"] == "STRUCTURAL_CANDIDATE"
            for x in result["protocol_conformance_candidates"]
        ))


if __name__ == "__main__":
    unittest.main()
