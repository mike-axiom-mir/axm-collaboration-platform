import json
import unittest
from pathlib import Path

from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.risk import change_risk_passport


ROOT = Path(__file__).resolve().parents[1]


class RiskTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )

    def test_no_change_is_low(self):
        b = self.bundle()
        result = change_risk_passport(
            b["files"], b["files"], b["target_python"],
            ["src/demo/models.py"], b["package"],
        )
        self.assertEqual(result["level"], "LOW")
        self.assertLessEqual(result["score"], 20)
        self.assertFalse(result["automatic_approval"])

    def test_api_break_and_network_increase_risk(self):
        b = self.bundle()
        after = []
        for item in b["files"]:
            item = dict(item)
            if item["path"].endswith("api.py"):
                item["source"] = (
                    "import socket\n"
                    + item["source"].replace(
                        "def greeting(name: str) -> str:",
                        "def greeting(name: bytes) -> str:",
                    )
                )
            after.append(item)
        result = change_risk_passport(
            b["files"], after, b["target_python"],
            ["src/demo/api.py"], b["package"],
        )
        dimensions = {x["dimension"] for x in result["dimensions"]}
        self.assertIn("PUBLIC_API_CHANGE", dimensions)
        self.assertIn("NEW_EFFECT_CAPABILITY", dimensions)
        self.assertGreater(result["score"], 20)


if __name__ == "__main__":
    unittest.main()
