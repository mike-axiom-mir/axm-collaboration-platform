import json
import unittest
from pathlib import Path

from axm_python_capability.semantic_consensus import (
    semantic_consensus_passport,
)


ROOT = Path(__file__).resolve().parents[1]


class SemanticConsensusTests(unittest.TestCase):
    def test_consensus_and_disagreement_both_preserved(self):
        raw = json.loads(
            (ROOT / "examples/semantic_consensus_input.json").read_text()
        )
        result = semantic_consensus_passport(raw)
        self.assertEqual(result["summary"]["consensus"], 1)
        self.assertEqual(result["summary"]["disagreements"], 1)
        self.assertEqual(result["status"], "DISAGREEMENTS_PRESENT")

    def test_deterministic(self):
        raw = json.loads(
            (ROOT / "examples/semantic_consensus_input.json").read_text()
        )
        self.assertEqual(
            semantic_consensus_passport(raw),
            semantic_consensus_passport(raw),
        )


if __name__ == "__main__":
    unittest.main()
