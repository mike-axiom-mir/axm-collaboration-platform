import json
import unittest
from pathlib import Path

from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.stewardship import stewardship_report


ROOT = Path(__file__).resolve().parents[1]


class StewardshipTests(unittest.TestCase):
    def test_stewardship_has_attention_without_actions(self):
        b = normalize_engineering_bundle(
            json.loads((ROOT / "examples/reference_engineering_bundle.json").read_text())
        )
        report = stewardship_report(
            b["files"], b["target_python"], b["package"]
        )
        self.assertFalse(report["automatic_changes"])
        self.assertTrue(report["report_digest"])
        self.assertTrue(any(
            x["kind"] == "DEAD_CODE_CANDIDATE"
            for x in report["attention_queue"]
        ))

    def test_policy_violation_enters_attention_queue(self):
        b = normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )
        policy = {
            "schema": "axm.python-architecture-policy.v1",
            "policy_id": "deny",
            "rules": [{
                "rule_id": "deny-service",
                "from_prefixes": ["demo.api"],
                "deny_to_prefixes": ["demo.service"],
            }],
        }
        report = stewardship_report(
            b["files"], b["target_python"], b["package"], policy
        )
        self.assertEqual(report["policy_status"], "VIOLATIONS")
        self.assertTrue(any(
            x["kind"] == "ARCHITECTURE_POLICY_VIOLATION"
            for x in report["attention_queue"]
        ))


if __name__ == "__main__":
    unittest.main()
