import json
import unittest
from pathlib import Path

from axm_python_capability.reproducibility import (
    module_build_reproducibility,
    patch_reproducibility,
    project_build_reproducibility,
)


ROOT = Path(__file__).resolve().parents[1]


class ReproducibilityTests(unittest.TestCase):
    def test_module_build_reproducible(self):
        request = json.loads(
            (ROOT / "examples/example_request.json").read_text()
        )
        result = module_build_reproducibility(request, runs=3)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["identical"])
        self.assertEqual(len(set(result["run_ids"])), 1)

    def test_project_build_reproducible(self):
        request = json.loads(
            (ROOT / "examples/project_request.json").read_text()
        )
        result = project_build_reproducibility(request, runs=3)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["identical"])
        self.assertEqual(len(set(result["receipt_digests"])), 1)

    def test_patch_reproducible(self):
        request = json.loads(
            (ROOT / "examples/guarded_patch_request.json").read_text()
        )
        result = patch_reproducibility(request, runs=5)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["identical"])
        self.assertEqual(len(set(result["receipt_digests"])), 1)


if __name__ == "__main__":
    unittest.main()
