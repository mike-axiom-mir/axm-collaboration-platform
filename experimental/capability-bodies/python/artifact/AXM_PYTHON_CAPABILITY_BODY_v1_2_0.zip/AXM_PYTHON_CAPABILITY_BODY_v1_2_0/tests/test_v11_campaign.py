import json
import unittest
from pathlib import Path

from axm_python_capability.verification_campaign import run_verification_campaign


ROOT = Path(__file__).resolve().parents[1]


class CampaignTests(unittest.TestCase):
    def test_verification_campaign_passes(self):
        result = run_verification_campaign(
            package_root=ROOT,
            module_request=json.loads(
                (ROOT / "examples/example_request.json").read_text()
            ),
            project_request=json.loads(
                (ROOT / "examples/project_request.json").read_text()
            ),
            patch_request=json.loads(
                (ROOT / "examples/guarded_patch_request.json").read_text()
            ),
            scale_modules=80,
        )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["failed_checks"], [])
        self.assertTrue(result["checks"]["reference_blueprint_stable"])
        self.assertFalse(result["automatic_promotion"])
        self.assertFalse(result["automatic_canon"])


if __name__ == "__main__":
    unittest.main()
