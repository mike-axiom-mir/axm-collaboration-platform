import json
import sys
import tempfile
import unittest
from pathlib import Path

from axm_python_capability import ContractError, VerificationError, build_request
from axm_python_capability.analyze import analyze_source
from axm_python_capability.catalog import CATALOG
from axm_python_capability.recipes import RECIPES

ROOT = Path(__file__).resolve().parents[1]


class V2SurfaceTests(unittest.TestCase):
    def load(self):
        return json.loads((ROOT / "examples" / "almost_all_python_request.json").read_text())

    def test_advanced_surface_builds(self):
        with tempfile.TemporaryDirectory() as d:
            result = build_request(self.load(), d)
            manifest = json.loads(Path(result.manifest_path).read_text())
            self.assertEqual(result.receipt["verification"], "PASS")
            self.assertTrue(any(x["name"] == "Record" for x in manifest["symbol_index"]))
            self.assertIn("asyncio", manifest["dependency_index"])

    def test_nested_packages_and_resources(self):
        with tempfile.TemporaryDirectory() as d:
            result = build_request(self.load(), d)
            base = Path(result.staging_dir) / "advanced_capability"
            self.assertTrue((base / "subpkg" / "__init__.py").exists())
            self.assertTrue((base / "subpkg" / "helpers.py").exists())
            self.assertTrue((base / "data" / "defaults.json").exists())

    def test_source_not_executed(self):
        req = self.load()
        req["modules"] = [{
            "path": "dangerous_if_executed.py",
            "source": 'raise RuntimeError("THIS MUST NEVER EXECUTE")\n'
        }]
        with tempfile.TemporaryDirectory() as d:
            result = build_request(req, d)
            self.assertEqual(result.receipt["verification"], "PASS")
            self.assertFalse(result.receipt["generated_code_executed"])

    def test_effect_signal_is_static_only(self):
        req = self.load()
        req["modules"] = [{"path": "effects.py", "source": "import socket\nimport subprocess\n"}]
        with tempfile.TemporaryDirectory() as d:
            result = build_request(req, d)
            manifest = json.loads(Path(result.manifest_path).read_text())
            self.assertIn("network_capable_code", manifest["effect_signals"])
            self.assertIn("process_control", manifest["effect_signals"])
            self.assertTrue(manifest["effect_signals_are_static_only"])

    def test_invalid_syntax_refused(self):
        req = self.load()
        req["modules"] = [{"path": "broken.py", "source": "def nope(:\n    pass\n"}]
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(VerificationError):
                build_request(req, d)

    def test_path_traversal_refused(self):
        req = self.load()
        req["modules"][0]["path"] = "../escape.py"
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ContractError):
                build_request(req, d)

    def test_catalog_and_recipes_are_present(self):
        self.assertIn("stdlib_domains", CATALOG)
        self.assertGreaterEqual(len(CATALOG["stdlib_domains"]), 40)
        self.assertGreaterEqual(len(RECIPES), 8)

    def test_analyzer_detects_language_features(self):
        source = """
async def f(xs):
    y = [x * 2 for x in xs if x > 0]
    match y:
        case []: return None
        case _: return y
"""
        target = f"{sys.version_info.major}.{sys.version_info.minor}"
        result = analyze_source(source, "x.py", target)
        self.assertTrue(result["feature_flags"]["async"])
        self.assertTrue(result["feature_flags"]["comprehensions"])
        self.assertTrue(result["feature_flags"]["pattern_matching"])


if __name__ == "__main__":
    unittest.main()
