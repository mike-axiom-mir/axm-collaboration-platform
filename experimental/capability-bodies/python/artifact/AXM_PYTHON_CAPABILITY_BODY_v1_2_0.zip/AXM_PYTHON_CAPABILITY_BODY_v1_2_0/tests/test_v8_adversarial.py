import copy
import json
import tempfile
import unittest
from pathlib import Path

from axm_python_capability.change_sets import (
    change_set_order,
    compose_change_sets,
)
from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.evidence_cache import incremental_evidence_snapshot
from axm_python_capability.evidence_store import load_snapshot, persist_snapshot
from axm_python_capability.errors import ContractError
from axm_python_capability.rollback import (
    apply_rollback_packet,
    generate_rollback_packet,
)


ROOT = Path(__file__).resolve().parents[1]


class AdversarialTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )

    def test_tampered_previous_cache_refused(self):
        b = self.bundle()
        first = incremental_evidence_snapshot(
            b["files"], b["target_python"], b["package"]
        )
        first["entries"][0]["analysis"]["syntax"] = "FAKE"
        with self.assertRaises(ContractError):
            incremental_evidence_snapshot(
                b["files"], b["target_python"], b["package"], first
            )

    def test_persisted_cache_round_trip_and_tamper_refusal(self):
        b = self.bundle()
        snapshot = incremental_evidence_snapshot(
            b["files"], b["target_python"], b["package"]
        )
        with tempfile.TemporaryDirectory() as d:
            receipt = persist_snapshot(d, snapshot)
            loaded = load_snapshot(receipt["path"])
            self.assertEqual(loaded, snapshot)

            path = Path(receipt["path"])
            raw = json.loads(path.read_text())
            raw["entries"][0]["cache_state"] = "TAMPERED"
            path.write_text(json.dumps(raw))
            with self.assertRaises(ContractError):
                load_snapshot(path)

    def test_rollback_packet_tamper_refused(self):
        b = self.bundle()
        after = copy.deepcopy(b["files"])
        after[0]["source"] += "\n# change\n"
        packet = generate_rollback_packet(
            change_id="tamper",
            before_files=b["files"],
            after_files=after,
        )
        packet["actions"][0]["path"] = "wrong.py"
        with self.assertRaises(ContractError):
            apply_rollback_packet(after, packet)

    def test_change_dependency_order(self):
        sets = [
            {
                "change_id": "b",
                "depends_on": ["a"],
                "operations": [{"op": "append", "path": "x.py", "text": "# b\n"}],
            },
            {
                "change_id": "a",
                "operations": [{"op": "append", "path": "x.py", "text": "# a\n"}],
            },
        ]
        result = change_set_order(sets)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["order"], ["a", "b"])

    def test_change_dependency_cycle_holds(self):
        sets = [
            {
                "change_id": "a",
                "depends_on": ["b"],
                "operations": [{"op": "append", "path": "x.py", "text": "# a\n"}],
            },
            {
                "change_id": "b",
                "depends_on": ["a"],
                "operations": [{"op": "append", "path": "x.py", "text": "# b\n"}],
            },
        ]
        result = change_set_order(sets)
        self.assertEqual(result["status"], "DEPENDENCY_CYCLE")

    def test_composition_respects_declared_dependency(self):
        b = self.bundle()
        sets = [
            {
                "change_id": "b",
                "depends_on": ["a"],
                "operations": [{
                    "op": "replace_exact",
                    "path": "src/demo/api.py",
                    "old": "Hello,",
                    "new": "Hi,",
                    "expected_count": 1,
                }],
            },
            {
                "change_id": "a",
                "operations": [{
                    "op": "replace_exact",
                    "path": "src/demo/api.py",
                    "old": 'return f"Hello {make_user(name).name}"',
                    "new": 'return f"Hello, {make_user(name).name}!"',
                    "expected_count": 1,
                }],
            },
        ]
        result = compose_change_sets(
            request_id="dependency-compose",
            target_python=b["target_python"],
            base_files=b["files"],
            change_sets=sets,
        )
        self.assertEqual(result["status"], "VERIFIED_COMPOSED_CANDIDATE")
        self.assertEqual(result["change_order"], ["a", "b"])
        api = next(
            x["source"] for x in result["files"]
            if x["path"] == "src/demo/api.py"
        )
        self.assertIn('return f"Hi, {make_user(name).name}!"', api)


if __name__ == "__main__":
    unittest.main()
