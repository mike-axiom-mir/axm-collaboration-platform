import json
import unittest
from pathlib import Path

from axm_python_capability.test_strength import test_strength_passport


ROOT = Path(__file__).resolve().parents[1]


class TestStrengthTests(unittest.TestCase):
    def fixture(self):
        return json.loads(
            (ROOT / "examples/test_strength_input.json").read_text()
        )

    def test_weaknesses_from_mutants_and_symbolic_diff(self):
        result = test_strength_passport(**self.fixture())
        self.assertEqual(result["mutation"]["score_percent"], 90.0)
        self.assertIn("SURVIVING_MUTANTS", result["weaknesses"])
        self.assertIn("SYMBOLIC_BEHAVIOR_DIFFERENCES", result["weaknesses"])
        self.assertFalse(result["automatic_merge"])

    def test_context_mapping(self):
        result = test_strength_passport(**self.fixture())
        self.assertEqual(
            result["observed_test_to_files"]["tests/test_api.py::test_ok"],
            ["src/demo/api.py", "src/demo/service.py"],
        )

    def test_no_evidence_is_not_correctness(self):
        result = test_strength_passport()
        self.assertEqual(result["status"], "NO_REPORTED_WEAKNESSES")
        self.assertIn("not proof", result["truth_boundary"])


if __name__ == "__main__":
    unittest.main()
