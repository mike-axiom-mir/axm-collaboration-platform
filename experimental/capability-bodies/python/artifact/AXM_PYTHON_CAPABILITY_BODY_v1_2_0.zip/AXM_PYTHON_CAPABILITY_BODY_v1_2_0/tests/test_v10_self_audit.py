import json
import unittest
from pathlib import Path

from axm_python_capability.implementation_map import (
    build_python_implementation_map,
)
from axm_python_capability.maturity import build_maturity_passport
from axm_python_capability.self_audit import audit_package


ROOT = Path(__file__).resolve().parents[1]


class SelfAuditTests(unittest.TestCase):
    def test_implementation_map_has_all_layers(self):
        result = build_python_implementation_map()
        self.assertEqual(
            [x["layer"] for x in result["layers"]],
            list(range(9)),
        )
        self.assertTrue(result["implementation_digest"])

    def test_static_implementation_map_matches_generated(self):
        static = json.loads(
            (ROOT / "PYTHON_REFERENCE_IMPLEMENTATION_MAP.json").read_text()
        )
        self.assertEqual(static, build_python_implementation_map())

    def test_package_self_audit_passes(self):
        result = audit_package(ROOT)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["summary"]["failed"], 0)
        self.assertTrue(result["audit_digest"])

    def test_maturity_passport_freeze_candidate_not_canon(self):
        audit = audit_package(ROOT)
        manifest = json.loads((ROOT / "manifest.json").read_text())
        schema_count = len(list((ROOT / "schemas").glob("*.json")))
        passport = build_maturity_passport(
            self_audit=audit,
            test_count=1,
            feature_count=len(manifest["features"]),
            schema_count=schema_count,
            known_truth_boundaries=[
                "future languages retain language-specific work",
            ],
        )
        self.assertEqual(
            passport["maturity_state"],
            "REFERENCE_FREEZE_CANDIDATE",
        )
        self.assertFalse(passport["automatic_canon"])
        self.assertFalse(passport["automatic_promotion"])
        self.assertFalse(passport["automatic_cross_language_install"])


if __name__ == "__main__":
    unittest.main()
