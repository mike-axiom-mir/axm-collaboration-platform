import sys
import unittest

from axm_python_capability.scale_probe import (
    run_scale_probe,
    synthetic_python_files,
)


HOST = f"{sys.version_info.major}.{sys.version_info.minor}"


class ScaleTests(unittest.TestCase):
    def test_synthetic_source_is_deterministic(self):
        self.assertEqual(
            synthetic_python_files(20),
            synthetic_python_files(20),
        )

    def test_functional_scale_probe(self):
        result = run_scale_probe(
            count=120,
            target_python=HOST,
            shard_max_files=25,
        )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["generated_python_modules"], 120)
        self.assertEqual(result["second_pass_misses"], 0)
        self.assertEqual(
            result["second_pass_hits"],
            result["total_files"],
        )
        self.assertEqual(
            result["stream_file_count"],
            result["total_files"],
        )
        self.assertGreater(result["shard_count"], 1)


if __name__ == "__main__":
    unittest.main()
