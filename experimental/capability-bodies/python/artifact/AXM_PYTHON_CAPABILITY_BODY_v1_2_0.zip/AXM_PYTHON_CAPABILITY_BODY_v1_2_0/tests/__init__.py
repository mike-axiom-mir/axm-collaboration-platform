"""AXM Python Capability test suite."""
