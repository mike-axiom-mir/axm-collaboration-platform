import copy
import json
import unittest
from pathlib import Path

from axm_python_capability.change_passport import build_change_passport
from axm_python_capability.engineering_bundle import normalize_engineering_bundle


ROOT = Path(__file__).resolve().parents[1]


class ChangePassportTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )

    def test_static_only_passport_keeps_evidence_gaps(self):
        b = self.bundle()
        result = build_change_passport(
            before_files=b["files"],
            after_files=b["files"],
            target_python=b["target_python"],
            package=b["package"],
            before_dependencies=b["dependencies"],
            after_dependencies=b["dependencies"],
            changed_paths=["src/demo/models.py"],
        )
        self.assertEqual(result["evidence_grade"], "STATIC_ONLY")
        self.assertIn(
            "NO_SANDBOX_TEST_EVIDENCE",
            result["evidence_gaps"],
        )
        self.assertFalse(result["automatic_release"])
        self.assertFalse(result["automatic_merge"])

    def test_breaking_api_is_explicit_hold(self):
        b = self.bundle()
        after = copy.deepcopy(b["files"])
        for item in after:
            if item["path"].endswith("api.py"):
                item["source"] = item["source"].replace(
                    "def greeting(name: str) -> str:",
                    "def greeting(name: bytes) -> str:",
                )
        result = build_change_passport(
            before_files=b["files"],
            after_files=after,
            target_python=b["target_python"],
            package=b["package"],
            before_dependencies=b["dependencies"],
            after_dependencies=b["dependencies"],
            changed_paths=["src/demo/api.py"],
        )
        self.assertIn(
            "PUBLIC_API_BREAK_OR_CHANGE",
            result["evidence_gaps"],
        )
        self.assertEqual(
            result["api"]["compatibility"]["compatibility"],
            "BREAKING_OR_CHANGED",
        )

    def test_complete_mock_evidence_still_not_approval(self):
        b = self.bundle()
        result = build_change_passport(
            before_files=b["files"],
            after_files=b["files"],
            target_python=b["target_python"],
            package=b["package"],
            before_dependencies=b["dependencies"],
            after_dependencies=b["dependencies"],
            changed_paths=["src/demo/models.py"],
            sandbox_test_evidence={
                "test_execution": True,
                "result": "PASS",
            },
            static_adapter_evidence={
                "overall_status": "PASS",
            },
        )
        self.assertEqual(
            result["evidence_grade"],
            "STATIC_ADAPTERS_SANDBOX",
        )
        self.assertEqual(result["evidence_gaps"], [])
        self.assertEqual(
            result["governance_status"],
            "EVIDENCE_COMPLETE_FOR_GOVERNANCE_REVIEW",
        )
        self.assertFalse(result["automatic_release"])
        self.assertFalse(result["automatic_promotion"])


if __name__ == "__main__":
    unittest.main()
