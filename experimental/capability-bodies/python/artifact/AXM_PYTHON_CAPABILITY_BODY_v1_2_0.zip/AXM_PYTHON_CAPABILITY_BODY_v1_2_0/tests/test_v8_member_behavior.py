import json
import unittest
from pathlib import Path

from axm_python_capability.behavior_fixtures import (
    normalize_behavior_fixtures,
    validate_behavior_fixtures_against_api,
)
from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.member_flow import class_member_flow


ROOT = Path(__file__).resolve().parents[1]


class MemberBehaviorTests(unittest.TestCase):
    def test_member_flow_inheritance_override_and_self_members(self):
        b = normalize_engineering_bundle(
            json.loads((ROOT / "examples/member_flow_bundle.json").read_text())
        )
        result = class_member_flow(
            b["files"], b["target_python"], b["package"]
        )
        self.assertTrue(any(
            edge["class"] == "members.child.Child"
            and edge["resolved_base"] == "members.base.Base"
            for edge in result["inheritance"]
        ))
        self.assertTrue(any(
            item["method"] == "speak"
            for item in result["overrides"]
        ))
        resolutions = {x["resolution"] for x in result["member_references"]}
        self.assertIn("RESOLVED_SELF_METHOD", resolutions)
        self.assertIn("RESOLVED_SELF_ATTRIBUTE", resolutions)
        self.assertIn("RESOLVED_CLASS_ATTRIBUTE", resolutions)

    def test_behavior_fixture_target_present(self):
        b = normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )
        fixture = json.loads((ROOT / "examples/behavior_fixtures.json").read_text())
        result = validate_behavior_fixtures_against_api(
            fixture, b["files"], b["target_python"]
        )
        self.assertEqual(result["status"], "PASS")
        self.assertFalse(result["fixtures_executed"])

    def test_behavior_fixture_missing_target_detected(self):
        b = normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )
        fixture = {
            "schema": "axm.python-behavior-fixture-set.v1",
            "fixtures": [{
                "fixture_id": "missing",
                "target": "src/demo/api.py::not_there",
                "args": [],
                "kwargs": {},
                "expected_return": None,
            }],
        }
        result = validate_behavior_fixtures_against_api(
            fixture, b["files"], b["target_python"]
        )
        self.assertEqual(result["status"], "BROKEN_FIXTURE_TARGETS")

    def test_fixture_set_digest_deterministic(self):
        raw = json.loads((ROOT / "examples/behavior_fixtures.json").read_text())
        self.assertEqual(
            normalize_behavior_fixtures(raw),
            normalize_behavior_fixtures(raw),
        )


if __name__ == "__main__":
    unittest.main()
