import copy
import json
import unittest
from pathlib import Path

from axm_python_capability.change_sets import (
    analyze_change_set_conflicts,
    compose_change_sets,
)
from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.errors import ContractError
from axm_python_capability.rollback import (
    apply_rollback_packet,
    generate_rollback_packet,
)


ROOT = Path(__file__).resolve().parents[1]


class ChangeRollbackTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )

    def test_conflict_detected(self):
        raw = json.loads((ROOT / "examples/change_sets_conflict.json").read_text())
        result = analyze_change_set_conflicts(raw["change_sets"])
        self.assertEqual(result["status"], "CONFLICTS")
        self.assertTrue(any(
            x["kind"] == "SAME_ANCHOR_DIFFERENT_REPLACEMENT"
            for x in result["conflicts"]
        ))

    def test_clean_change_sets_compose(self):
        b = self.bundle()
        raw = json.loads((ROOT / "examples/change_sets_clean.json").read_text())
        result = compose_change_sets(
            request_id="compose-test",
            target_python=b["target_python"],
            base_files=b["files"],
            change_sets=raw["change_sets"],
        )
        self.assertEqual(result["status"], "VERIFIED_COMPOSED_CANDIDATE")
        self.assertTrue(result["composition_digest"])

    def test_rollback_restores_exact_before(self):
        b = self.bundle()
        raw = json.loads((ROOT / "examples/change_sets_clean.json").read_text())
        composed = compose_change_sets(
            request_id="compose-rollback",
            target_python=b["target_python"],
            base_files=b["files"],
            change_sets=raw["change_sets"],
        )
        packet = generate_rollback_packet(
            change_id="compose-rollback",
            before_files=b["files"],
            after_files=composed["files"],
        )
        rolled = apply_rollback_packet(composed["files"], packet)
        self.assertEqual(rolled["files"], b["files"])

    def test_rollback_refuses_drift(self):
        b = self.bundle()
        raw = json.loads((ROOT / "examples/change_sets_clean.json").read_text())
        composed = compose_change_sets(
            request_id="compose-drift",
            target_python=b["target_python"],
            base_files=b["files"],
            change_sets=raw["change_sets"],
        )
        packet = generate_rollback_packet(
            change_id="compose-drift",
            before_files=b["files"],
            after_files=composed["files"],
        )
        drifted = copy.deepcopy(composed["files"])
        drifted[0]["source"] += "\n# external drift\n"
        with self.assertRaises(ContractError):
            apply_rollback_packet(drifted, packet)


if __name__ == "__main__":
    unittest.main()
