import json
import unittest
from pathlib import Path

from axm_python_capability.reference_blueprint import (
    assess_candidate_body,
    build_reference_blueprint,
)


ROOT = Path(__file__).resolve().parents[1]


class BlueprintTests(unittest.TestCase):
    def test_blueprint_has_nine_layers_and_stable_digest(self):
        a = build_reference_blueprint()
        b = build_reference_blueprint()
        self.assertEqual(a, b)
        self.assertEqual([x["layer"] for x in a["layers"]], list(range(9)))
        self.assertTrue(a["blueprint_digest"])

    def test_static_blueprint_matches_generated(self):
        static = json.loads(
            (ROOT / "REFERENCE_BODY_BLUEPRINT.json").read_text()
        )
        self.assertEqual(static, build_reference_blueprint())

    def test_partial_candidate_is_legal_partial_maturity(self):
        candidate = json.loads(
            (ROOT / "examples/partial_code_body_candidate.json").read_text()
        )
        result = assess_candidate_body(candidate)
        self.assertEqual(result["status"], "PARTIAL_MATURITY")
        self.assertEqual(result["maturity_percent"], 11)
        self.assertEqual(result["root_violations"], [])
        self.assertFalse(result["automatic_promotion"])

    def test_root_violation_overrides_maturity(self):
        blueprint = build_reference_blueprint()
        layers = {
            str(layer["layer"]): {
                "contracts": layer["required_contracts"],
            }
            for layer in blueprint["layers"]
        }
        candidate = {
            "body_id": "bad",
            "language": "x",
            "authority": {
                "automatic_install": False,
                "automatic_register": False,
                "automatic_promote": False,
                "automatic_canon": True,
            },
            "unsandboxed_execution_fallback": False,
            "layers": layers,
        }
        result = assess_candidate_body(candidate)
        self.assertEqual(result["status"], "ROOT_VIOLATIONS")
        self.assertIn("AUTOMATIC_CANON_FORBIDDEN", result["root_violations"])

    def test_complete_contract_can_score_100_without_promotion(self):
        blueprint = build_reference_blueprint()
        candidate = {
            "body_id": "complete",
            "language": "example",
            "authority": {
                "automatic_install": False,
                "automatic_register": False,
                "automatic_promote": False,
                "automatic_canon": False,
            },
            "unsandboxed_execution_fallback": False,
            "layers": {
                str(layer["layer"]): {
                    "contracts": layer["required_contracts"],
                }
                for layer in blueprint["layers"]
            },
        }
        result = assess_candidate_body(candidate)
        self.assertEqual(result["status"], "COMPLETE_REFERENCE_CONTRACT")
        self.assertEqual(result["maturity_percent"], 100)
        self.assertFalse(result["automatic_promotion"])


if __name__ == "__main__":
    unittest.main()
