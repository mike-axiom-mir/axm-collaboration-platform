import json
import os
import tempfile
import unittest
from pathlib import Path

from axm_python_capability import AuthorityError, ContractError
from axm_python_capability.stream_index import stream_repository_index


class StreamIndexTests(unittest.TestCase):
    def request(self, root: Path):
        return {
            "schema": "axm.python-stream-index-request.v1",
            "root": str(root),
            "authorities": ["READ_PROJECT_TREE"],
            "page_size": 2,
            "max_files": 100,
            "max_total_bytes": 1024 * 1024,
        }

    def test_stream_pages_and_digest(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "a.py").write_text("x = 1\n")
            (root / "b.py").write_text("y = 2\n")
            (root / "c.txt").write_text("z")
            result = stream_repository_index(self.request(root))
            self.assertEqual(result["file_count"], 3)
            self.assertEqual(len(result["page_payloads"]), 2)
            self.assertTrue(result["root_digest"])
            self.assertFalse(result["source_mutation"])

    def test_ignored_git_directory(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / ".git").mkdir()
            (root / ".git" / "secret").write_text("x")
            (root / "a.py").write_text("x = 1\n")
            result = stream_repository_index(self.request(root))
            self.assertEqual(result["file_count"], 1)

    def test_authority_required(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "a.py").write_text("x=1\n")
            req = self.request(root)
            req["authorities"] = []
            with self.assertRaises(AuthorityError):
                stream_repository_index(req)

    def test_symlink_refused(self):
        if not hasattr(os, "symlink"):
            self.skipTest("symlink unsupported")
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "repo"
            root.mkdir()
            target = Path(d) / "outside"
            target.write_text("x")
            try:
                os.symlink(target, root / "link")
            except OSError:
                self.skipTest("symlink creation unavailable")
            with self.assertRaises(ContractError):
                stream_repository_index(self.request(root))


if __name__ == "__main__":
    unittest.main()
