import os
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

from axm_python_capability import AuthorityError, ContractError, run_adapter_request
from axm_python_capability.adapter_runner import _run_adapter_request
from axm_python_capability.adapters import AdapterSpec, BUILTIN_ADAPTERS


def fake_spec(script: Path, *, adapter_id: str = "fake", diagnostic_codes=()):
    return AdapterSpec(
        adapter_id=adapter_id,
        category="test",
        executables=(sys.executable,),
        args=(str(script),),
        version_args=("--version",),
        network_behavior="none_expected",
        executes_project_code=False,
        source_write_intent=False,
        diagnostic_exit_codes=tuple(diagnostic_codes),
        description="test adapter",
    )


class AdapterTests(unittest.TestCase):
    def project(self, root: Path):
        (root / "pkg").mkdir()
        (root / "pkg" / "__init__.py").write_text("")
        (root / "pkg" / "core.py").write_text("def add(a: int, b: int) -> int:\n    return a + b\n")

    def request(self, root: Path, adapters):
        return {
            "schema": "axm.python-adapter-request.v1",
            "request_id": "adapter-test",
            "project_root": str(root),
            "adapters": list(adapters),
            "authorities": ["READ_SPEC", "RUN_STATIC_ANALYZER"],
            "policy": {
                "allow_network": False,
                "timeout_seconds": 3,
                "max_output_bytes": 8192,
                "max_files": 100,
                "max_total_bytes": 1024 * 1024,
            },
        }

    def test_host_compile_runs_on_shadow(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "project"
            root.mkdir()
            self.project(root)
            result = run_adapter_request(self.request(root, ["host_compile"]))
            self.assertEqual(result["results"][0]["status"], "PASS")
            self.assertTrue(result["source_unchanged"])
            self.assertFalse(result["shell_used"])
            self.assertFalse(result["project_code_execution_authorized"])

    def test_network_capable_audit_refused(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "project"
            root.mkdir()
            self.project(root)
            result = run_adapter_request(self.request(root, ["pip_audit"]))
            self.assertEqual(result["results"][0]["status"], "REFUSED_NETWORK_POLICY")
            self.assertFalse(result["results"][0]["executed"])

    def test_uncertain_bootstrap_refused(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "project"
            root.mkdir()
            self.project(root)
            result = run_adapter_request(self.request(root, ["pyright"]))
            self.assertEqual(
                result["results"][0]["status"],
                "REFUSED_UNCERTAIN_BOOTSTRAP_POLICY",
            )

    def test_static_authority_required(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "project"
            root.mkdir()
            self.project(root)
            req = self.request(root, ["host_compile"])
            req["authorities"] = ["READ_SPEC"]
            with self.assertRaises(AuthorityError):
                run_adapter_request(req)

    def test_network_authority_cannot_be_smuggled(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "project"
            root.mkdir()
            self.project(root)
            req = self.request(root, ["pip_audit"])
            req["policy"]["allow_network"] = True
            with self.assertRaises(AuthorityError):
                run_adapter_request(req)

    def test_symlink_refused(self):
        if not hasattr(os, "symlink"):
            self.skipTest("symlink unsupported")
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "project"
            root.mkdir()
            self.project(root)
            target = Path(d) / "outside.txt"
            target.write_text("outside")
            try:
                os.symlink(target, root / "link.txt")
            except OSError:
                self.skipTest("symlink creation unavailable")
            with self.assertRaises(ContractError):
                run_adapter_request(self.request(root, ["host_compile"]))

    def test_shadow_mutation_recorded_but_source_unchanged(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            root = base / "project"
            root.mkdir()
            self.project(root)
            script = base / "mutate.py"
            script.write_text(
                "from pathlib import Path\nPath('created-by-tool.txt').write_text('x')\n"
            )
            spec = fake_spec(script)
            result = _run_adapter_request(self.request(root, ["fake"]), {"fake": spec})
            self.assertTrue(result["shadow_mutated"])
            self.assertTrue(result["source_unchanged"])
            self.assertFalse((root / "created-by-tool.txt").exists())

    def test_findings_exit_code_is_not_tool_error(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            root = base / "project"
            root.mkdir()
            self.project(root)
            script = base / "findings.py"
            script.write_text("import sys\nprint('finding')\nsys.exit(1)\n")
            spec = fake_spec(script, diagnostic_codes=(1,))
            result = _run_adapter_request(self.request(root, ["fake"]), {"fake": spec})
            self.assertEqual(result["results"][0]["status"], "FINDINGS")
            self.assertEqual(result["overall_status"], "FINDINGS")

    def test_timeout_kills_tool(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            root = base / "project"
            root.mkdir()
            self.project(root)
            script = base / "slow.py"
            script.write_text("import time\ntime.sleep(5)\n")
            spec = fake_spec(script)
            req = self.request(root, ["fake"])
            req["policy"]["timeout_seconds"] = 0.2
            result = _run_adapter_request(req, {"fake": spec})
            self.assertEqual(result["results"][0]["status"], "TIMEOUT")

    def test_output_limit_kills_tool(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            root = base / "project"
            root.mkdir()
            self.project(root)
            script = base / "loud.py"
            script.write_text("print('x' * 100000)\n")
            spec = fake_spec(script)
            req = self.request(root, ["fake"])
            req["policy"]["max_output_bytes"] = 2048
            result = _run_adapter_request(req, {"fake": spec})
            self.assertEqual(result["results"][0]["status"], "OUTPUT_LIMIT")
            self.assertLessEqual(result["results"][0]["recorded_output_bytes"], 2048)

    def test_not_installed_is_evidence_not_crash(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "project"
            root.mkdir()
            self.project(root)
            spec = AdapterSpec(
                adapter_id="missing",
                category="test",
                executables=("definitely-not-an-axm-real-command-49382",),
                args=(),
                version_args=("--version",),
                network_behavior="none_expected",
                executes_project_code=False,
                source_write_intent=False,
                diagnostic_exit_codes=(),
                description="missing",
            )
            result = _run_adapter_request(self.request(root, ["missing"]), {"missing": spec})
            self.assertEqual(result["results"][0]["status"], "NOT_INSTALLED")

    def test_unknown_adapter_refused(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "project"
            root.mkdir()
            self.project(root)
            with self.assertRaises(ContractError):
                run_adapter_request(self.request(root, ["not_real"]))


if __name__ == "__main__":
    unittest.main()
