import sys
import unittest

from axm_python_capability import ContractError, apply_patch_request


HOST = f"{sys.version_info.major}.{sys.version_info.minor}"


class PatchGuardTests(unittest.TestCase):
    def base(self):
        return {
            "schema": "axm.python-patch-request.v1",
            "request_id": "guard-test",
            "target_python": HOST,
            "files": [
                {
                    "path": "api.py",
                    "source": "def greet(name: str) -> str:\n    return name\n",
                }
            ],
            "operations": [],
            "guards": {},
        }

    def test_safe_guarded_patch_passes(self):
        req = self.base()
        req["operations"] = [{
            "op": "replace_exact",
            "path": "api.py",
            "old": "return name",
            "new": "return name.strip()",
            "expected_count": 1,
        }]
        req["guards"] = {
            "preserve_public_api": True,
            "no_new_import_roots": True,
            "no_new_effect_signals": True,
        }
        result = apply_patch_request(req)
        self.assertEqual(result["receipt"]["verification"], "PASS")
        self.assertEqual(result["impact"]["public_api_removed_or_changed"], [])

    def test_api_break_guard_refuses(self):
        req = self.base()
        req["operations"] = [{
            "op": "replace_exact",
            "path": "api.py",
            "old": "def greet(name: str) -> str:",
            "new": "def greet(name: bytes) -> str:",
            "expected_count": 1,
        }]
        req["guards"] = {"preserve_public_api": True}
        with self.assertRaises(ContractError):
            apply_patch_request(req)

    def test_effect_guard_refuses(self):
        req = self.base()
        req["operations"] = [{
            "op": "prepend",
            "path": "api.py",
            "text": "import socket\n",
        }]
        req["guards"] = {"no_new_effect_signals": True}
        with self.assertRaises(ContractError):
            apply_patch_request(req)


if __name__ == "__main__":
    unittest.main()
