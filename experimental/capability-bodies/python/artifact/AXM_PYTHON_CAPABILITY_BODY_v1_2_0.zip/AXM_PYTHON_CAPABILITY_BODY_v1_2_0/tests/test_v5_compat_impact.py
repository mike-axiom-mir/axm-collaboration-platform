import sys
import unittest

from axm_python_capability.compatibility import grammar_matrix
from axm_python_capability.errors import VerificationError
from axm_python_capability.impact import analyze_bundle, diff_bundle, enforce_guards
from axm_python_capability.analyze import analyze_source


HOST = f"{sys.version_info.major}.{sys.version_info.minor}"


class CompatibilityImpactTests(unittest.TestCase):
    def test_compile_gate_catches_top_level_return(self):
        with self.assertRaises(VerificationError):
            analyze_source("return 42\n", "bad.py", HOST)

    def test_match_grammar_is_at_least_310(self):
        result = grammar_matrix(
            "def f(x):\n    match x:\n        case 1: return True\n        case _: return False\n",
            "matchy.py",
        )
        self.assertGreaterEqual(
            int(result["minimum_tracked_grammar"].split(".")[1]),
            10,
        )

    def test_except_star_needs_311_or_newer(self):
        if sys.version_info.minor < 11:
            self.skipTest("host too old")
        result = grammar_matrix(
            "try:\n    pass\nexcept* ValueError:\n    pass\n",
            "eg.py",
        )
        self.assertGreaterEqual(
            int(result["minimum_tracked_grammar"].split(".")[1]),
            11,
        )

    def test_public_api_change_detected(self):
        before = analyze_bundle(
            [{"path": "a.py", "source": "def f(x: int) -> int:\n    return x\n"}],
            HOST,
        )
        after = analyze_bundle(
            [{"path": "a.py", "source": "def f(x: str) -> int:\n    return len(x)\n"}],
            HOST,
        )
        impact = diff_bundle(before, after)
        self.assertTrue(impact["public_api_removed_or_changed"])
        violations = enforce_guards(impact, {"preserve_public_api": True})
        self.assertIn("PUBLIC_API_CHANGED", violations)

    def test_new_effect_signal_detected(self):
        before = analyze_bundle(
            [{"path": "a.py", "source": "x = 1\n"}],
            HOST,
        )
        after = analyze_bundle(
            [{"path": "a.py", "source": "import socket\nx = 1\n"}],
            HOST,
        )
        impact = diff_bundle(before, after)
        self.assertIn("network_capable_code", impact["effect_signals_added"])
        self.assertIn(
            "NEW_EFFECT_SIGNALS",
            enforce_guards(impact, {"no_new_effect_signals": True}),
        )

    def test_new_import_root_detected(self):
        before = analyze_bundle(
            [{"path": "a.py", "source": "import json\n"}],
            HOST,
        )
        after = analyze_bundle(
            [{"path": "a.py", "source": "import json\nimport httpx\n"}],
            HOST,
        )
        impact = diff_bundle(before, after)
        self.assertIn("httpx", impact["import_roots_added"])
        self.assertIn(
            "NEW_IMPORT_ROOTS",
            enforce_guards(impact, {"no_new_import_roots": True}),
        )


if __name__ == "__main__":
    unittest.main()
