import copy
import json
import unittest
from pathlib import Path

from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.fine_grained import (
    fine_grained_invalidation,
    symbol_snapshot,
)


ROOT = Path(__file__).resolve().parents[1]


class FineGrainedTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )

    def test_symbol_snapshot_deterministic(self):
        b = self.bundle()
        self.assertEqual(
            symbol_snapshot(b["files"], b["target_python"], b["package"]),
            symbol_snapshot(b["files"], b["target_python"], b["package"]),
        )

    def test_one_function_change_does_not_mark_all_symbols_changed(self):
        b = self.bundle()
        after = copy.deepcopy(b["files"])
        for item in after:
            if item["path"] == "src/demo/service.py":
                item["source"] = item["source"].replace(
                    "return User(name=name)",
                    "return User(name=name.strip())",
                )
        result = fine_grained_invalidation(
            before_files=b["files"],
            after_files=after,
            target_python=b["target_python"],
            package=b["package"],
        )
        self.assertIn("demo.service.make_user", result["changed_symbols"])
        self.assertNotIn("demo.models.Item", result["changed_symbols"])
        self.assertGreaterEqual(
            len(result["invalidated_symbols"]),
            len(result["changed_symbols"]),
        )


if __name__ == "__main__":
    unittest.main()
