import json
import tempfile
import unittest
from pathlib import Path

from axm_python_capability import AuthorityError, build_request

ROOT = Path(__file__).resolve().parents[1]


class BuilderTests(unittest.TestCase):
    def load(self):
        return json.loads((ROOT / "examples" / "example_request.json").read_text())

    def test_determinism(self):
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            x = build_request(self.load(), a)
            y = build_request(self.load(), b)
            self.assertEqual(x.run_id, y.run_id)
            self.assertEqual(x.receipt, y.receipt)
            self.assertEqual(
                json.loads(Path(x.manifest_path).read_text()),
                json.loads(Path(y.manifest_path).read_text()),
            )

    def test_no_execution_or_promotion(self):
        with tempfile.TemporaryDirectory() as d:
            r = build_request(self.load(), d)
            self.assertEqual(r.receipt["verification"], "PASS")
            self.assertFalse(r.receipt["generated_code_executed"])
            self.assertFalse(r.receipt["packages_installed"])
            self.assertFalse(r.receipt["registered"])
            self.assertFalse(r.receipt["promoted"])
            self.assertFalse(r.receipt["canon"])

    def test_execution_authority_refused(self):
        req = self.load()
        req["authorities"].append("EXECUTE_GENERATED_CODE")
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(AuthorityError):
                build_request(req, d)

    def test_canon_authority_refused(self):
        req = self.load()
        req["authorities"].append("CANON")
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(AuthorityError):
                build_request(req, d)


if __name__ == "__main__":
    unittest.main()
