import copy
import json
import unittest
from pathlib import Path

from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.evidence_cache import incremental_evidence_snapshot


ROOT = Path(__file__).resolve().parents[1]


class CacheTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )

    def test_first_snapshot_all_misses_second_all_hits(self):
        b = self.bundle()
        first = incremental_evidence_snapshot(
            b["files"], b["target_python"], b["package"]
        )
        self.assertEqual(
            first["cache_summary"]["miss_count"],
            len(b["files"]),
        )
        second = incremental_evidence_snapshot(
            b["files"], b["target_python"], b["package"], first
        )
        self.assertEqual(
            second["cache_summary"]["hit_count"],
            len(b["files"]),
        )
        self.assertTrue(second["project_derived_evidence_reusable"])

    def test_one_file_change_invalidates_only_file_cache(self):
        b = self.bundle()
        first = incremental_evidence_snapshot(
            b["files"], b["target_python"], b["package"]
        )
        changed = copy.deepcopy(b["files"])
        changed[0]["source"] += "\n# changed\n"
        second = incremental_evidence_snapshot(
            changed, b["target_python"], b["package"], first
        )
        self.assertEqual(second["cache_summary"]["miss_count"], 1)
        self.assertEqual(
            second["cache_summary"]["hit_count"],
            len(b["files"]) - 1,
        )
        self.assertFalse(second["project_derived_evidence_reusable"])

    def test_removed_file_is_recorded(self):
        b = self.bundle()
        first = incremental_evidence_snapshot(
            b["files"], b["target_python"], b["package"]
        )
        second = incremental_evidence_snapshot(
            b["files"][:-1], b["target_python"], b["package"], first
        )
        self.assertEqual(second["cache_summary"]["removed_count"], 1)


if __name__ == "__main__":
    unittest.main()
