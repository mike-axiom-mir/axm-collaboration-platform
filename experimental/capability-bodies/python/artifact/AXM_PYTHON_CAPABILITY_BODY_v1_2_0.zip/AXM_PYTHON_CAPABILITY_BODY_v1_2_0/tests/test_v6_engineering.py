import json
import sys
import unittest
from pathlib import Path

from axm_python_capability.engineering import (
    affected_tests,
    api_passport,
    architecture_report,
    compare_api_passports,
)
from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.migrations import dependency_migration_plan
from axm_python_capability.project_graph import build_call_graph
from axm_python_capability.refactor import plan_public_symbol_rename


ROOT = Path(__file__).resolve().parents[1]


class EngineeringTests(unittest.TestCase):
    def bundle(self):
        raw = json.loads((ROOT / "examples" / "engineering_bundle.json").read_text())
        return normalize_engineering_bundle(raw)

    def test_architecture_report_maps_chain(self):
        b = self.bundle()
        report = architecture_report(b["files"], b["target_python"], b["package"])
        edges = {(x["from"], x["target"]) for x in report["module_graph"]["edges"]}
        self.assertIn(("demo.service", "demo.models"), edges)
        self.assertIn(("demo.api", "demo.service"), edges)
        self.assertTrue(report["architecture_digest"])

    def test_affected_test_mapping_is_transitive(self):
        b = self.bundle()
        result = affected_tests(
            b["files"], b["target_python"],
            ["src/demo/models.py"], b["package"],
        )
        self.assertIn("demo.models", result["changed_modules"])
        self.assertIn("demo.service", result["impacted_modules"])
        self.assertIn("demo.api", result["impacted_modules"])
        self.assertIn("tests/test_api.py", result["affected_test_paths"])

    def test_api_passport_is_stable(self):
        b = self.bundle()
        a = api_passport(b["files"], b["target_python"])
        c = api_passport(b["files"], b["target_python"])
        self.assertEqual(a, c)
        self.assertTrue(a["project_api_digest"])

    def test_api_passport_detects_break(self):
        b = self.bundle()
        before = api_passport(b["files"], b["target_python"])
        changed = []
        for item in b["files"]:
            item = dict(item)
            if item["path"].endswith("api.py"):
                item["source"] = item["source"].replace(
                    "def greeting(name: str) -> str:",
                    "def greeting(name: bytes) -> str:",
                )
            changed.append(item)
        after = api_passport(changed, b["target_python"])
        diff = compare_api_passports(before, after)
        self.assertEqual(diff["compatibility"], "BREAKING_OR_CHANGED")
        self.assertTrue(diff["changed"])

    def test_dependency_migration_plan(self):
        plan = dependency_migration_plan(
            ["httpx>=0.27", "pydantic>=2"],
            ["httpx>=0.28", "rich>=13"],
            ["tests/test_api.py"],
        )
        self.assertEqual(plan["added"], ["rich"])
        self.assertEqual(plan["removed"], ["pydantic"])
        self.assertEqual(plan["changed"], ["httpx"])
        self.assertFalse(plan["automatic_install"])

    def test_call_graph_finds_imported_symbol_call(self):
        b = self.bundle()
        graph = build_call_graph(b["files"], b["target_python"], b["package"])
        self.assertTrue(any(
            x["target"] == "demo.service.make_user"
            and x["resolution"] == "resolved_import_reference"
            for x in graph["calls"]
        ))
        self.assertTrue(any(
            x["target"] == "demo.api.greeting"
            and x["resolution"] == "resolved_import_reference"
            for x in graph["calls"]
        ))

    def test_rename_plan_is_conservative(self):
        b = self.bundle()
        plan = plan_public_symbol_rename(
            b["files"], b["target_python"],
            module="demo.api", old="greeting", new="welcome",
            package=b["package"],
        )
        self.assertTrue(plan["exact_edits"])
        # Test imports/bare references create ambiguity instead of a guessed global rewrite.
        self.assertEqual(plan["status"], "HOLD_AMBIGUOUS_REFERENCES")
        self.assertTrue(plan["ambiguous_references"])

    def test_cycle_detection(self):
        raw = json.loads((ROOT / "examples" / "cycle_engineering_bundle.json").read_text())
        b = normalize_engineering_bundle(raw)
        report = architecture_report(b["files"], b["target_python"], b["package"])
        self.assertTrue(report["cycles"])
        self.assertEqual(set(report["cycles"][0]), {"cyc.a", "cyc.b"})


if __name__ == "__main__":
    unittest.main()
