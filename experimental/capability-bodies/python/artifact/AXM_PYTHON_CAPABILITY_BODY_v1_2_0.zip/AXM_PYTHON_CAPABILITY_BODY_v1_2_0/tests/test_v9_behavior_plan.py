import json
import unittest
from pathlib import Path

from axm_python_capability.behavior_runner import (
    behavior_fixture_execution_plan,
    generate_behavior_unittest_source,
)
from axm_python_capability.engineering_bundle import normalize_engineering_bundle


ROOT = Path(__file__).resolve().parents[1]


class BehaviorPlanTests(unittest.TestCase):
    def fixture(self):
        return json.loads((ROOT / "examples/behavior_fixtures.json").read_text())

    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )

    def test_generated_test_source_is_deterministic(self):
        b = self.bundle()
        a = generate_behavior_unittest_source(
            self.fixture(), package=b["package"]
        )
        c = generate_behavior_unittest_source(
            self.fixture(), package=b["package"]
        )
        self.assertEqual(a, c)
        self.assertIn("importlib.import_module('demo.api')", a)
        self.assertIn("self.assertEqual", a)

    def test_plan_holds_without_hard_sandbox_or_is_ready_if_proven(self):
        b = self.bundle()
        plan = behavior_fixture_execution_plan(
            fixture_set=self.fixture(),
            package=b["package"],
            authorities=["RUN_SANDBOX_TESTS"],
        )
        if plan["sandbox_doctor"]["generated_test_execution_available"]:
            self.assertEqual(plan["status"], "READY_FOR_HARD_SANDBOX")
            self.assertTrue(plan["execution_authorized"])
        else:
            self.assertEqual(
                plan["status"],
                "HOLD_NO_VERIFIED_HARD_SANDBOX",
            )
            self.assertFalse(plan["execution_authorized"])
        self.assertFalse(plan["host_execution_fallback"])

    def test_actual_behavior_runner_never_falls_back_to_host(self):
        import tempfile
        from axm_python_capability.behavior_runner import run_behavior_fixtures_sandboxed

        b = self.bundle()
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / "src" / "demo").mkdir(parents=True)
            (root / "src" / "demo" / "__init__.py").write_text("")
            (root / "src" / "demo" / "api.py").write_text(
                "def greeting(name: str) -> str:\n"
                "    return f'Hello {name}'\n"
            )
            result = run_behavior_fixtures_sandboxed(
                project_root=root,
                fixture_set=self.fixture(),
                package=b["package"],
                authorities=["RUN_SANDBOX_TESTS"],
            )
            self.assertFalse(result["host_execution_fallback"])
            if not result["sandbox_doctor"]["generated_test_execution_available"]:
                self.assertEqual(
                    result["result"],
                    "HOLD_NO_VERIFIED_HARD_SANDBOX",
                )
                self.assertFalse(result["fixtures_executed"])
            else:
                self.assertTrue(result["fixtures_executed"])
                self.assertIn(
                    result["result"],
                    {"PASS", "BEHAVIOR_FIXTURE_FAILURE", "TIMEOUT", "OUTPUT_LIMIT"},
                )


if __name__ == "__main__":
    unittest.main()
