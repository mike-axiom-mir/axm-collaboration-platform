import json
import unittest
from pathlib import Path

from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.interface_policy import check_interface_policy


ROOT = Path(__file__).resolve().parents[1]


class InterfacePolicyTests(unittest.TestCase):
    def bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )

    def policy(self):
        return json.loads((ROOT / "examples/interface_policy.json").read_text())

    def test_valid_public_imports_pass(self):
        b = self.bundle()
        result = check_interface_policy(
            files=b["files"],
            target_python=b["target_python"],
            package=b["package"],
            policy=self.policy(),
        )
        self.assertEqual(result["status"], "PASS")

    def test_private_import_violation(self):
        b = self.bundle()
        modified = list(b["files"]) + [{
            "path": "src/demo/bad.py",
            "source": "from .service import _private_helper\n",
        }]
        result = check_interface_policy(
            files=modified,
            target_python=b["target_python"],
            package=b["package"],
            policy=self.policy(),
        )
        self.assertEqual(result["status"], "VIOLATIONS")
        self.assertTrue(any(
            x["kind"] == "PRIVATE_INTERFACE_IMPORT"
            and x.get("symbol") == "_private_helper"
            for x in result["violations"]
        ))

    def test_visibility_violation(self):
        b = self.bundle()
        modified = list(b["files"]) + [{
            "path": "src/other/use.py",
            "source": "from demo.service import make_user\n",
        }]
        result = check_interface_policy(
            files=modified,
            target_python=b["target_python"],
            package=b["package"],
            policy=self.policy(),
        )
        self.assertTrue(any(
            x["kind"] == "MODULE_VISIBILITY_VIOLATION"
            for x in result["violations"]
        ))


if __name__ == "__main__":
    unittest.main()
