import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class DonorFileTests(unittest.TestCase):
    def test_checklist_points_to_blueprint(self):
        blueprint = json.loads(
            (ROOT / "REFERENCE_BODY_BLUEPRINT.json").read_text()
        )
        checklist = json.loads(
            (ROOT / "DONOR_INTAKE_CHECKLIST.json").read_text()
        )
        self.assertEqual(
            checklist["reference_blueprint_digest"],
            blueprint["blueprint_digest"],
        )
        self.assertFalse(checklist["automatic_install"])
        self.assertFalse(checklist["automatic_promotion"])

    def test_freeze_note_preserves_html_lane(self):
        text = (ROOT / "REFERENCE_FREEZE.md").read_text()
        self.assertIn("HTML remains the first local-tested code body", text)

    def test_candidate_schema_exists(self):
        schema = json.loads(
            (ROOT / "schemas/code_body_candidate.schema.json").read_text()
        )
        self.assertEqual(schema["$id"], "axm.code-body-candidate.v1")


if __name__ == "__main__":
    unittest.main()
