import json
import unittest
from pathlib import Path

from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.proven_refactor import (
    plan_module_move,
    proven_symbol_rename_plan,
)


ROOT = Path(__file__).resolve().parents[1]


class ProvenRefactorTests(unittest.TestCase):
    def ref_bundle(self):
        return normalize_engineering_bundle(
            json.loads((ROOT / "examples/reference_engineering_bundle.json").read_text())
        )

    def test_proven_rename_finds_definition_import_and_references(self):
        b = self.ref_bundle()
        plan = proven_symbol_rename_plan(
            b["files"], b["target_python"],
            module="refdemo.api", old="greet", new="welcome",
            package=b["package"],
        )
        kinds = {x["kind"] for x in plan["exact_edits"]}
        self.assertIn("DEFINITION_NAME", kinds)
        self.assertIn("FROM_IMPORT_BINDING", kinds)
        self.assertIn("PROVEN_NAME_REFERENCE", kinds)
        self.assertIn("PROVEN_ATTRIBUTE_REFERENCE", kinds)
        self.assertEqual(plan["status"], "READY_EXACT_EDITS")

    def test_module_move_absolute_import_plan(self):
        b = self.ref_bundle()
        # api.py has no relative imports so moving it to helpers is provable;
        # consumer has a relative import, which is not currently rewritten here
        # because the importer remains in place and resolves old module. This
        # should appear as a hold only if the move invalidates a relative import
        # inside the moved module itself.
        plan = plan_module_move(
            b["files"], b["target_python"],
            old_module="refdemo.api",
            new_module="refdemo.helpers.api",
            new_path="src/refdemo/helpers/api.py",
            package=b["package"],
        )
        self.assertEqual(plan["file_move"]["from"], "src/refdemo/api.py")
        self.assertEqual(plan["file_move"]["to"], "src/refdemo/helpers/api.py")
        self.assertTrue(any(x["kind"] == "IMPORT_MODULE" for x in plan["import_edits"]))
        self.assertTrue(any(
            x["kind"] == "FROM_MODULE_IMPORT"
            and x["path"] == "src/refdemo/consumer.py"
            and "refdemo.helpers.api" in x["new"]
            for x in plan["import_edits"]
        ))

    def test_parent_change_with_relative_import_holds(self):
        b = self.ref_bundle()
        modified = []
        for item in b["files"]:
            item = dict(item)
            if item["path"] == "src/refdemo/api.py":
                item["source"] = "from .consumer import consume\n\ndef greet(name: str) -> str:\n    return consume(name)\n"
            modified.append(item)
        plan = plan_module_move(
            modified, b["target_python"],
            old_module="refdemo.api",
            new_module="refdemo.sub.api",
            new_path="src/refdemo/sub/api.py",
            package=b["package"],
        )
        self.assertEqual(plan["status"], "HOLD_PARTIAL_PROOF")
        self.assertTrue(plan["holds"])


if __name__ == "__main__":
    unittest.main()
