import copy
import json
import tempfile
import unittest
from pathlib import Path

from axm_python_capability import build_request
from axm_python_capability.canonical import digest_object

ROOT = Path(__file__).resolve().parents[1]


class TamperTests(unittest.TestCase):
    def test_receipt_tamper_changes_digest(self):
        request = json.loads((ROOT / "examples" / "example_request.json").read_text())
        with tempfile.TemporaryDirectory() as d:
            result = build_request(request, d)
            receipt = copy.deepcopy(result.receipt)
            original = receipt.pop("receipt_digest")
            self.assertEqual(original, digest_object(receipt))
            receipt["promoted"] = True
            self.assertNotEqual(original, digest_object(receipt))


if __name__ == "__main__":
    unittest.main()
