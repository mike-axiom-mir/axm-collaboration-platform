import json
import tempfile
import unittest
from pathlib import Path

from axm_python_capability import build_project

ROOT = Path(__file__).resolve().parents[1]


class ProjectTests(unittest.TestCase):
    def load(self):
        return json.loads((ROOT / "examples" / "project_request.json").read_text())

    def test_project_build_and_intelligence(self):
        with tempfile.TemporaryDirectory() as d:
            result = build_project(self.load(), d)
            m = result["manifest"]
            self.assertEqual(result["receipt"]["verification"], "PASS")
            self.assertIn("asyncio", m["import_graph"]["stdlib_used"])
            self.assertIn("httpx", m["import_graph"]["third_party_or_external"])
            self.assertEqual(m["import_graph"]["undeclared_external_import_roots"], [])
            self.assertTrue(any(x["name"] == "Item" for x in m["public_api_index"]))
            self.assertGreaterEqual(m["project_metrics"]["function_count"], 2)
            self.assertTrue(any(x["path"].endswith("test_models.py") for x in m["project_metrics"]["test_files"]))

    def test_pyproject_generated(self):
        with tempfile.TemporaryDirectory() as d:
            result = build_project(self.load(), d)
            root = Path(result["staging_dir"])
            text = (root / "pyproject.toml").read_text()
            self.assertIn("[project]", text)
            self.assertIn("httpx>=0.27", text)
            self.assertTrue((root / "src" / "axm_example" / "service.py").exists())

    def test_project_determinism(self):
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            x = build_project(self.load(), a)
            y = build_project(self.load(), b)
            self.assertEqual(x["run_id"], y["run_id"])
            self.assertEqual(x["receipt"], y["receipt"])
            self.assertEqual(x["manifest"], y["manifest"])

    def test_undeclared_external_import_detected(self):
        req = self.load()
        req["project"]["dependencies"] = []
        with tempfile.TemporaryDirectory() as d:
            result = build_project(req, d)
            self.assertIn("httpx", result["manifest"]["import_graph"]["undeclared_external_import_roots"])


if __name__ == "__main__":
    unittest.main()
