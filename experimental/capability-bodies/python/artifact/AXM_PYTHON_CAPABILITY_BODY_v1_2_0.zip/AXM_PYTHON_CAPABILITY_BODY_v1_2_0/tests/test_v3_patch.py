import copy
import json
import unittest
from pathlib import Path

from axm_python_capability import ContractError, apply_patch_request

ROOT = Path(__file__).resolve().parents[1]


class PatchTests(unittest.TestCase):
    def load(self):
        return json.loads((ROOT / "examples" / "patch_request.json").read_text())

    def test_patch_repairs_source_without_execution(self):
        result = apply_patch_request(self.load())
        source = result["files"][0]["source"]
        self.assertIn("return a + b", source)
        self.assertIn("def subtract", source)
        self.assertEqual(result["receipt"]["verification"], "PASS")
        self.assertFalse(result["receipt"]["code_executed"])

    def test_patch_is_deterministic(self):
        x = apply_patch_request(self.load())
        y = apply_patch_request(self.load())
        self.assertEqual(x, y)

    def test_patch_precondition_failure(self):
        req = self.load()
        req["operations"][0]["old"] = "not present"
        with self.assertRaises(ContractError):
            apply_patch_request(req)

    def test_create_delete_with_hash_guard(self):
        req = {
            "schema": "axm.python-patch-request.v1",
            "request_id": "create-delete",
            "files": [{"path": "a.py", "source": "x = 1\n"}],
            "operations": [
                {"op": "create", "path": "b.py", "source": "y = 2\n"},
            ],
        }
        result = apply_patch_request(req)
        self.assertEqual([x["path"] for x in result["files"]], ["a.py", "b.py"])


if __name__ == "__main__":
    unittest.main()
