import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class ReferenceContractTests(unittest.TestCase):
    def test_reference_architecture_has_all_layers(self):
        text = (ROOT / "CODE_BODY_REFERENCE_ARCHITECTURE.md").read_text()
        for layer in range(0, 9):
            self.assertIn(f"Layer {layer}", text)

    def test_reference_contract_forbids_unsandboxed_fallback(self):
        text = (ROOT / "CODE_BODY_REFERENCE_ARCHITECTURE.md").read_text()
        self.assertIn("no unsandboxed fallback", text.lower())

    def test_reference_contract_keeps_promotion_outside_body(self):
        text = (ROOT / "CODE_BODY_REFERENCE_ARCHITECTURE.md").read_text()
        self.assertIn("promoted", text)
        self.assertIn("CANON", text)


if __name__ == "__main__":
    unittest.main()
