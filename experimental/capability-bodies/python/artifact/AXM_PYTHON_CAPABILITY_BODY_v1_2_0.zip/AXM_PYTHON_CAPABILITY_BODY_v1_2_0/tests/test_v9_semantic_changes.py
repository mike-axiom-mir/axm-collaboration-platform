import json
import unittest
from pathlib import Path

from axm_python_capability.semantic_changes import semantic_change_graph


ROOT = Path(__file__).resolve().parents[1]


class SemanticChangeTests(unittest.TestCase):
    def test_unique_providers_form_order(self):
        raw = json.loads((ROOT / "examples/semantic_change_units.json").read_text())
        result = semantic_change_graph(raw["change_units"])
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["order"], ["models", "service", "api"])
        self.assertEqual(len(result["semantic_edges"]), 2)

    def test_ambiguous_provider_holds(self):
        raw = json.loads(
            (ROOT / "examples/semantic_change_units_ambiguous.json").read_text()
        )
        result = semantic_change_graph(raw["change_units"])
        self.assertEqual(result["status"], "HOLD")
        self.assertTrue(any(
            x["kind"] == "AMBIGUOUS_SEMANTIC_PROVIDER"
            for x in result["holds"]
        ))

    def test_explicit_dependency_resolves_ambiguous_provider(self):
        units = [
            {"change_id": "a", "provides": ["x"], "operations": []},
            {"change_id": "b", "provides": ["x"], "operations": []},
            {
                "change_id": "c",
                "requires": ["x"],
                "depends_on": ["b"],
                "operations": [],
            },
        ]
        result = semantic_change_graph(units)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(any(
            x["from"] == "c" and x["to"] == "b"
            and x["resolution"] == "EXPLICIT_PROVIDER"
            for x in result["semantic_edges"]
        ))

    def test_missing_provider_holds(self):
        result = semantic_change_graph([
            {"change_id": "x", "requires": ["missing"], "operations": []}
        ])
        self.assertEqual(result["status"], "HOLD")
        self.assertTrue(any(
            x["kind"] == "MISSING_SEMANTIC_PROVIDER"
            for x in result["holds"]
        ))


if __name__ == "__main__":
    unittest.main()
