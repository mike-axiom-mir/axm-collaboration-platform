import json
import unittest
from pathlib import Path

from axm_python_capability.flow_evidence import (
    compare_flow_providers,
    normalize_flow_findings,
)


ROOT = Path(__file__).resolve().parents[1]


class FlowEvidenceTests(unittest.TestCase):
    def findings(self):
        return json.loads((ROOT / "examples/flow_findings.json").read_text())

    def test_normalization(self):
        result = normalize_flow_findings("codeql", self.findings())
        self.assertEqual(result["finding_count"], 1)
        self.assertEqual(result["status"], "FINDINGS")
        self.assertFalse(result["source_code_executed_by_normalizer"])

    def test_provider_corroboration(self):
        a = normalize_flow_findings("codeql", self.findings())
        b = normalize_flow_findings("semgrep", self.findings())
        result = compare_flow_providers([a, b])
        self.assertEqual(
            result["comparisons"][0]["status"],
            "MULTI_PROVIDER_CORROBORATION",
        )

    def test_empty_findings_not_proof(self):
        result = normalize_flow_findings("custom", [])
        self.assertEqual(result["status"], "NO_FINDINGS_REPORTED")
        self.assertIn("not proof", result["truth_boundary"])


if __name__ == "__main__":
    unittest.main()
