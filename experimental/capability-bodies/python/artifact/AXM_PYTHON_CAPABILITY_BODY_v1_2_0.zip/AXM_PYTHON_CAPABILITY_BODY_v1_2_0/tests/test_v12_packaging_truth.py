import json
import unittest
from pathlib import Path

from axm_python_capability.packaging_truth import (
    normalize_distribution_name,
    packaging_truth_passport,
    parse_pylock,
    requirement_distribution,
)


ROOT = Path(__file__).resolve().parents[1]


class PackagingTruthTests(unittest.TestCase):
    def fixture(self):
        return json.loads(
            (ROOT / "examples/packaging_truth_input.json").read_text()
        )

    def test_distribution_normalization(self):
        self.assertEqual(
            normalize_distribution_name("My_Package.Name"),
            "my-package-name",
        )
        self.assertEqual(
            requirement_distribution("httpx>=0.27; python_version>'3.10'"),
            "httpx",
        )

    def test_import_name_mapping_uses_metadata_not_guess(self):
        raw = self.fixture()
        result = packaging_truth_passport(**raw)
        self.assertEqual(result["mapped_imports"]["sklearn"], "scikit-learn")
        self.assertEqual(result["mapped_imports"]["httpx"], "httpx")
        self.assertIn("json", result["unknown_import_roots"])
        self.assertNotIn("scikit-learn", result["missing_runtime_declarations"])

    def test_pylock_runtime_declarations_locked(self):
        raw = self.fixture()
        result = packaging_truth_passport(**raw)
        self.assertEqual(result["unlocked_runtime_declarations"], [])
        self.assertIsNotNone(result["lock"])

    def test_unknown_mapping_stays_unknown(self):
        raw = self.fixture()
        raw["observed_import_roots"] = ["totally_unknown"]
        result = packaging_truth_passport(**raw)
        self.assertEqual(result["mapped_imports"], {})
        self.assertEqual(result["unknown_import_roots"], ["totally_unknown"])


if __name__ == "__main__":
    unittest.main()
