import json
import unittest
from pathlib import Path

from axm_python_capability.reference_blueprint import build_reference_blueprint
from axm_python_capability.implementation_map import build_python_implementation_map


ROOT = Path(__file__).resolve().parents[1]


class ReferenceStabilityTests(unittest.TestCase):
    def test_v10_blueprint_digest_remains_frozen(self):
        baseline = json.loads(
            (ROOT / "REFERENCE_BASELINE_v1_0.json").read_text()
        )
        current = build_reference_blueprint()
        self.assertEqual(
            current["blueprint_digest"],
            baseline["reference_blueprint_digest"],
        )

    def test_v10_implementation_map_remains_frozen(self):
        baseline = json.loads(
            (ROOT / "REFERENCE_BASELINE_v1_0.json").read_text()
        )
        current = build_python_implementation_map()
        self.assertEqual(
            current["implementation_digest"],
            baseline["reference_implementation_map_digest"],
        )


if __name__ == "__main__":
    unittest.main()
