import tempfile
import unittest
from pathlib import Path

from axm_python_capability import AuthorityError
from axm_python_capability.sandbox import sandbox_doctor
from axm_python_capability.sandbox_tests import run_sandbox_test_request


class SandboxTests(unittest.TestCase):
    def request(self, root: Path):
        return {
            "schema": "axm.python-sandbox-test-request.v1",
            "request_id": "sandbox-unit",
            "project_root": str(root),
            "framework": "unittest",
            "authorities": ["READ_SPEC", "RUN_SANDBOX_TESTS"],
            "policy": {
                "timeout_seconds": 2,
                "max_output_bytes": 8192,
                "cpu_seconds": 1,
                "memory_bytes": 256 * 1024 * 1024,
                "file_bytes": 1024 * 1024,
                "processes": 8,
            },
        }

    def project(self, root: Path):
        (root / "test_ok.py").write_text(
            "import unittest\n"
            "class T(unittest.TestCase):\n"
            "    def test_ok(self): self.assertEqual(2 + 2, 4)\n"
        )

    def test_doctor_has_evidence_digest(self):
        result = sandbox_doctor()
        self.assertIn("evidence_digest", result)
        self.assertIn("providers", result)

    def test_authority_required(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.project(root)
            req = self.request(root)
            req["authorities"] = ["READ_SPEC"]
            with self.assertRaises(AuthorityError):
                run_sandbox_test_request(req)

    def test_no_hard_provider_holds_instead_of_fallback(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.project(root)
            result = run_sandbox_test_request(self.request(root))
            if not result["sandbox_doctor"]["generated_test_execution_available"]:
                self.assertEqual(result["result"], "HOLD_NO_VERIFIED_HARD_SANDBOX")
                self.assertFalse(result["test_execution"])
            else:
                # On a host that really has a passing hard sandbox, it is legal to execute.
                self.assertIn(result["result"], {"PASS", "TEST_FAILURE", "TIMEOUT", "OUTPUT_LIMIT"})


if __name__ == "__main__":
    unittest.main()
