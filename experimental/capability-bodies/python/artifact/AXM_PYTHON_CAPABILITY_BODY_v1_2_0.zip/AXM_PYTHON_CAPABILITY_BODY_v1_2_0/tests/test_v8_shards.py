import json
import unittest
from pathlib import Path

from axm_python_capability.engineering_bundle import normalize_engineering_bundle
from axm_python_capability.repo_shards import plan_repository_shards


ROOT = Path(__file__).resolve().parents[1]


class ShardTests(unittest.TestCase):
    def test_deterministic(self):
        b = normalize_engineering_bundle(
            json.loads((ROOT / "examples/engineering_bundle.json").read_text())
        )
        a = plan_repository_shards(
            b["files"], b["target_python"], b["package"],
            max_files=2, max_bytes=100000,
        )
        c = plan_repository_shards(
            b["files"], b["target_python"], b["package"],
            max_files=2, max_bytes=100000,
        )
        self.assertEqual(a, c)
        self.assertGreaterEqual(len(a["shards"]), 2)

    def test_cycle_scc_not_split(self):
        b = normalize_engineering_bundle(
            json.loads((ROOT / "examples/cycle_engineering_bundle.json").read_text())
        )
        plan = plan_repository_shards(
            b["files"], b["target_python"], b["package"],
            max_files=1, max_bytes=100000,
        )
        shard_paths = [
            set(shard["paths"]) for shard in plan["shards"]
        ]
        self.assertTrue(any(
            {"src/cyc/a.py", "src/cyc/b.py"} <= paths
            for paths in shard_paths
        ))
        self.assertTrue(plan["oversize_atomic_units"])


if __name__ == "__main__":
    unittest.main()
