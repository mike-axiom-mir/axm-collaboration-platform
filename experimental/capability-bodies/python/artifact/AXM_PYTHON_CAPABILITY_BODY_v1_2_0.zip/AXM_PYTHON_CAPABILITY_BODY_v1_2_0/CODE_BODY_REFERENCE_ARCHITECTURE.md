# AXM Code Body Reference Architecture v1

Python v0.6 is the **mature reference donor** for future language capability
bodies. This document describes the reusable architecture, not Python syntax.

A later JavaScript/TypeScript/Go/Rust/etc. body should copy the contracts and
replace only language-specific analyzers, renderers, package managers and
sandbox/test adapters.

## Layer 0 — Truth / authority

Mandatory:

- explicit capability ID + version
- typed request schema
- explicit authority ceiling
- no automatic install/register/promote/CANON
- deterministic receipt
- no silent authority widening

## Layer 1 — Language representation

Mandatory:

- structured construction path where useful
- whole-source path
- canonical normalization
- bounded staging
- syntax parser
- compile/semantic-front-end check without execution when the language supports it

## Layer 2 — Static understanding

Mandatory:

- symbols
- imports/dependencies
- public API surface
- language features
- static effects/capabilities
- project/module graph
- approximate call graph with an explicit truth boundary

## Layer 3 — Project intelligence

Mandatory:

- project/package layout
- dependency classification
- import graph
- cycles
- fan-in/fan-out hotspots
- tests discovery
- architecture digest

## Layer 4 — Change intelligence

Mandatory:

- before/after impact
- API compatibility passport
- blast radius
- affected tests
- dependency migration plan
- version/grammar compatibility evidence when meaningful

## Layer 5 — Deterministic repair/refactor

Mandatory:

- exact preconditions
- refuse ambiguous replacements
- impact guards
- syntax/static verification after change
- refactor planning must separate exact edits from ambiguous references

## Layer 6 — External verification ring

Optional tools must be adapters, not core dependencies.

Mandatory adapter behavior:

- explicit analyzer authority
- no auto-install
- shadow copy
- original source hash before/after
- timeout
- output cap
- executable/version evidence
- network behavior declaration
- findings != tool failure

## Layer 7 — Hard sandbox execution

Execution is separate authority.

Mandatory:

- provider must pass an actual local containment probe
- no "tool exists therefore sandbox works"
- no unsandboxed fallback
- no-network proof when network is forbidden
- isolated writable working tree
- resource limits
- execution receipt
- HOLD if containment is unavailable

## Layer 8 — Governance return

Output is a candidate/evidence packet.

Never imply:

- installed
- registered
- promoted
- CANON

unless the higher AXM governance/merge gate actually performed that action.

## Language body maturity ladder

Suggested reuse sequence:

1. syntax/body
2. whole-source understanding
3. project graph
4. repair + impact
5. static adapters
6. hard sandbox tests
7. engineering organs
8. language-specific refinements

This allows each code language to grow slowly without re-inventing the roots.


## Reference maturity refinements from Python v0.7

A mature code body SHOULD additionally provide:

- a static reference/name-flow index with explicit unresolved states;
- dead-code **candidates**, never automatic deletion from absence of references;
- architecture boundary policies expressed as data;
- affected-test prioritization distinct from test execution;
- change-risk passports that are deterministic triage, not merge authority;
- exact refactor spans only after binding proof;
- module-move plans that HOLD when relative/import semantics are uncertain;
- a stewardship attention queue with zero automatic restructuring.

These are reusable architecture contracts for other languages even where the
language-specific implementation differs.


## Reference maturity refinements from Python v0.8

A mature code body SHOULD support scale and reversibility:

- content-addressed file evidence so unchanged source is not re-analyzed;
- explicit invalidation of project-level derived evidence after any file change;
- deterministic repository sharding with language dependency cycles kept atomic;
- multi-change conflict analysis before composition;
- deterministic composition order with order-dependency evidence;
- exact rollback packets guarded by current-content hashes;
- class/member/inheritance evidence where the language supports it;
- behavioral API fixtures as data contracts, separated from execution authority.

A rollback packet is evidence and a reversible candidate action. It must refuse
when the current tree no longer matches the expected post-change hashes.


## Reference maturity refinements from Python v0.9

A mature code body SHOULD also provide:

- semantic change-unit contracts with declared `provides` / `requires`;
- deterministic provider resolution and HOLD on ambiguity;
- streaming repository indexing for trees too large to eagerly materialize;
- explicit read-tree authority for filesystem intake;
- consolidated change/release evidence passports without merge authority;
- deeper member/property/super/protocol evidence where language semantics permit;
- behavioral fixture execution plans that refuse host fallback and remain behind
  the verified hard-sandbox gate.

A "complete evidence passport" is never itself release authorization.


## v1.0 reference freeze contract

The prose architecture is mirrored by:

- `REFERENCE_BODY_BLUEPRINT.json`
- `PYTHON_REFERENCE_IMPLEMENTATION_MAP.json`
- `DONOR_INTAKE_CHECKLIST.json`

Future code bodies may mature layer by layer. A body is not required to reach
100% donor maturity before it is useful, but Layer 0 root authority violations
must never be hidden by maturity percentage.

Python v1.0 is a reference freeze candidate, not automatic CANON.
