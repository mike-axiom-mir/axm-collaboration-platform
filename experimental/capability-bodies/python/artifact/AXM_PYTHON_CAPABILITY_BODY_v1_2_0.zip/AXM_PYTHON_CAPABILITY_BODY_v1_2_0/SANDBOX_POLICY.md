# AXM Python Capability — Sandbox Policy v0.5

## No fake sandbox

A sandbox executable being present is not enough.

A provider must pass an actual local probe and report:

- network namespace isolation
- filesystem isolation
- process namespace isolation
- hard-test-ready = true

Only then may `RUN_SANDBOX_TESTS` execute generated project tests.

## Providers

### bubblewrap

Preferred Linux hard provider.

The implementation constructs a fresh bubblewrap root using:

- `--unshare-all`
- no `--share-net`
- `--cap-drop ALL`
- read-only host runtime paths
- a writable temporary project shadow at `/work`
- isolated `/tmp` and `/home`
- PID/proc/dev namespace construction
- no shell

The provider is enabled only if the local probe actually passes.

### Linux unshare

The capability probes a new user + network namespace.

This is useful evidence that no-network namespace isolation is available, but
it does not hide the host filesystem. Therefore it is classified as PARTIAL
and cannot authorize generated test execution by itself.

## Resource limits

Sandboxed tests are additionally bounded with RLIMIT controls for:

- CPU time
- address space
- file size
- process count
- open file count

The outer runner also imposes:

- wall-clock timeout
- captured-output ceiling

## Test framework

v0.5 enables only Python's built-in `unittest` runner.

No third-party test runner is installed automatically.

## Truth boundary

A HOLD is a successful safety outcome when no proven hard provider exists.

The system must never silently fall back to ordinary host execution.
