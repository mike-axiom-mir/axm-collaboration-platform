# AXM Python Capability — Static Adapter Policy

## Principle

The deterministic core does not need to become an execution engine merely to
benefit from mature Python tooling.

Adapters are an **outer verification ring**.

## Required authority

`RUN_STATIC_ANALYZER`

This is separate from `WRITE_STAGING`.

## Never implied

The adapter authority does not grant:

- execution of the generated Python project
- network
- package installation
- writing into the original project
- registration
- promotion
- CANON

## Shadow-copy rule

Every analyzer receives a temporary copy of the project. The original tree is
hashed before and after. Symlinks are refused.

A tool may create caches or temporary files in its shadow copy; this is recorded
as `shadow_mutated`. That does not authorize mutation of the source project.

## External tools

Default offline ring:

- `host_compile`
- `ruff_lint` if already installed
- `ruff_format_check` if already installed
- `mypy` if already installed

Guarded:

- `pyright`: refused in strict offline mode because some Python wrapper installs
  may bootstrap Node/Pyright.
- `pip_audit`: refused because normal vulnerability auditing uses vulnerability
  services and may resolve dependencies.

No adapter is automatically installed.

## Network truth boundary

The current adapter runner performs policy-level blocking and selects tools that
are expected not to need network. It is **not an OS/kernel network sandbox**.

Therefore receipts say:

`POLICY_AND_TOOL_CLASSIFICATION_NOT_KERNEL_SANDBOX`

A later platform-specific sandbox adapter can strengthen this to actual network
namespace/firewall containment.
