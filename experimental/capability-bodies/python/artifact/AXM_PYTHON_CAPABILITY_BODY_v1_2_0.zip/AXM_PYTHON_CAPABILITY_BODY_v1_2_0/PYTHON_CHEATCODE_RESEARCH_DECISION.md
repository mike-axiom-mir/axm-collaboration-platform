# AXM Python v1.2 — Internet/GitHub Cheatcode Decision

This file records the decision boundary behind v1.2.

The v1.0 generic code-body architecture remains frozen.

v1.2 adds Python-specific evidence providers and adapters discovered through
current Python ecosystem research.

## Directly implemented in AXM core

### PackagingTruth

Uses deterministic metadata supplied to AXM:

- `pyproject.toml`
- optional `pylock.toml`
- distribution metadata including `Import-Name`
- distribution metadata including `Import-Namespace`

Unknown import-to-distribution mappings remain UNKNOWN.
No hyphen/underscore guess is promoted to truth.

### SemanticConsensus

Normalizes type evidence from:

- Pyright
- Pyrefly
- mypy
- ty

Agreement becomes corroboration.
Disagreement remains explicit uncertainty.
AXM does not vote one checker into truth.

### FineGrainedInvalidation

Adds symbol-level source digests and conservative dependency invalidation so a
single function change need not automatically invalidate every file-level fact.

### InterfacePolicy

Adds public interface, visibility, ownership and deprecated-boundary evidence
inspired by mature architecture tooling.

### DeepFlowEvidence

Normalizes interprocedural/value-flow evidence from providers such as CodeQL
and Semgrep.

AXM does not attempt to clone their solvers.

### TestStrength

Combines independent execution evidence such as:

- test coverage contexts
- mutation results
- property-based counterexamples
- symbolic behavior differences

No single metric is treated as correctness proof.

## Optional enhanced adapters

### LibCST

Optional lossless CST/metadata evidence.

It is never installed automatically and never replaces Python AST/compile as
the baseline deterministic truth path.

### Pyrefly and ty

Optional static analyzer adapters when already installed.

## Deliberately not absorbed as core implementations

- no homemade CodeQL clone
- no homemade SMT solver / CrossHair clone
- no homemade full Python type checker
- no treating audit hooks as a sandbox
- no treating subinterpreters as a sandbox
- no automatic third-party package installation
- no AGPL direct intake through this package

## Sandbox-only future evidence

CrossHair, Hypothesis, mutation testing, runtime coverage contexts and fuzzing
are execution-capable evidence providers and belong behind the existing hard
sandbox authority boundary.

## Cross-language donor note

Tree-sitter / structural search-rewrite systems remain high-value substrates
for later language bodies, but Python retains its richer Python-native
AST/CST/typing ecosystem.
