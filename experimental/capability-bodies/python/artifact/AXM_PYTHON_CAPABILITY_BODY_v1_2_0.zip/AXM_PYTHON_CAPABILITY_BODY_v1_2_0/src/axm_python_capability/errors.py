class CapabilityError(Exception):
    """Base capability error."""


class ContractError(CapabilityError):
    """Input contract violation."""


class AuthorityError(CapabilityError):
    """Requested authority exceeds this capability's ceiling."""


class VerificationError(CapabilityError):
    """Generated output failed verification."""
