from __future__ import annotations

import hashlib
from pathlib import PurePosixPath
from typing import Any

from .canonical import digest_object, stable_id
from .constants import CAPABILITY_ID, CAPABILITY_VERSION, PATCH_SCHEMA_V1
from .contracts import normalize_target_python, safe_relpath, require_text
from .errors import ContractError
from .analyze import analyze_source
from .impact import analyze_bundle, diff_bundle, enforce_guards


def _sha(text: str) -> str:
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()


def apply_patch_request(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict) or raw.get("schema") != PATCH_SCHEMA_V1:
        raise ContractError(f"schema must be {PATCH_SCHEMA_V1}")

    request_id = require_text(raw.get("request_id"), "request_id")
    target_python = normalize_target_python(raw.get("target_python"))

    files_raw = raw.get("files")
    if not isinstance(files_raw, list) or not files_raw:
        raise ContractError("files must be a non-empty list")
    files: dict[str, str] = {}
    for i, item in enumerate(files_raw):
        if not isinstance(item, dict):
            raise ContractError(f"files[{i}] must be an object")
        path = safe_relpath(item.get("path"), f"files[{i}].path")
        source = item.get("source")
        if not isinstance(source, str):
            raise ContractError(f"files[{i}].source must be a string")
        if path in files:
            raise ContractError(f"duplicate file: {path}")
        files[path] = source.replace("\r\n", "\n").replace("\r", "\n")

    operations = raw.get("operations")
    if not isinstance(operations, list) or not operations:
        raise ContractError("operations must be a non-empty list")

    guards = raw.get("guards", {})
    if not isinstance(guards, dict):
        raise ContractError("guards must be an object")

    before_bundle_files = [
        {"path": path, "source": files[path]} for path in sorted(files)
    ]
    before_analysis = analyze_bundle(before_bundle_files, target_python)

    normalized = {
        "schema": PATCH_SCHEMA_V1,
        "request_id": request_id,
        "target_python": target_python,
        "files": [{"path": k, "source": files[k]} for k in sorted(files)],
        "operations": operations,
        "guards": guards,
    }
    run_id = stable_id("pypatch", {
        "capability": CAPABILITY_ID,
        "version": CAPABILITY_VERSION,
        "request": normalized,
    })

    events = []
    for i, op in enumerate(operations):
        if not isinstance(op, dict):
            raise ContractError(f"operations[{i}] must be an object")
        kind = op.get("op")
        path = safe_relpath(op.get("path"), f"operations[{i}].path")
        before = files.get(path)

        if kind == "replace_exact":
            if before is None:
                raise ContractError(f"patch target missing: {path}")
            old = op.get("old")
            new = op.get("new")
            if not isinstance(old, str) or not isinstance(new, str) or old == "":
                raise ContractError("replace_exact requires non-empty old and string new")
            count = before.count(old)
            expected = int(op.get("expected_count", 1))
            if count != expected:
                raise ContractError(
                    f"PATCH_PRECONDITION_FAILED:{path}:expected={expected}:found={count}"
                )
            after = before.replace(old, new)
            files[path] = after

        elif kind == "append":
            if before is None:
                raise ContractError(f"patch target missing: {path}")
            text = op.get("text")
            if not isinstance(text, str):
                raise ContractError("append requires text")
            after = before + text
            files[path] = after

        elif kind == "prepend":
            if before is None:
                raise ContractError(f"patch target missing: {path}")
            text = op.get("text")
            if not isinstance(text, str):
                raise ContractError("prepend requires text")
            after = text + before
            files[path] = after

        elif kind == "create":
            if before is not None:
                raise ContractError(f"create target already exists: {path}")
            source = op.get("source")
            if not isinstance(source, str):
                raise ContractError("create requires source")
            after = source
            files[path] = after

        elif kind == "delete":
            if before is None:
                raise ContractError(f"delete target missing: {path}")
            expected_sha = op.get("expected_sha256")
            if expected_sha is not None and expected_sha != _sha(before):
                raise ContractError(f"DELETE_HASH_PRECONDITION_FAILED:{path}")
            after = None
            del files[path]

        else:
            raise ContractError(f"unsupported patch op: {kind}")

        events.append({
            "index": i,
            "op": kind,
            "path": path,
            "before_sha256": _sha(before) if before is not None else None,
            "after_sha256": _sha(after) if after is not None else None,
        })

    verification = []
    for path in sorted(files):
        source = files[path]
        item = {
            "path": path,
            "sha256": _sha(source),
            "bytes": len(source.encode("utf-8")),
        }
        if path.endswith(".py"):
            item["python"] = analyze_source(source, path, target_python)
        verification.append(item)

    after_bundle_files = [
        {"path": path, "source": files[path]} for path in sorted(files)
    ]
    after_analysis = analyze_bundle(after_bundle_files, target_python)
    impact = diff_bundle(before_analysis, after_analysis)
    violations = enforce_guards(impact, guards)
    if violations:
        raise ContractError("PATCH_GUARD_FAILED:" + ",".join(sorted(violations)))

    receipt_core = {
        "schema": "axm.python-patch-receipt.v1",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "run_id": run_id,
        "request_id": request_id,
        "target_python": target_python,
        "operations": events,
        "guards": guards,
        "impact": impact,
        "files_after": [
            {"path": path, "sha256": _sha(files[path])} for path in sorted(files)
        ],
        "verification": "PASS",
        "code_executed": False,
        "status": "VERIFIED_PATCH_CANDIDATE",
    }
    receipt = dict(receipt_core)
    receipt["receipt_digest"] = digest_object(receipt_core)

    return {
        "run_id": run_id,
        "files": [{"path": path, "source": files[path]} for path in sorted(files)],
        "verification": verification,
        "before_analysis": before_analysis,
        "after_analysis": after_analysis,
        "impact": impact,
        "receipt": receipt,
    }
