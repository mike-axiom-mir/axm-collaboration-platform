from __future__ import annotations

from typing import Any

from .canonical import digest_object
from .constants import ARCHITECTURE_POLICY_SCHEMA_V1
from .errors import ContractError
from .project_graph import build_module_graph


def _matches_prefix(module: str, prefixes: list[str]) -> bool:
    return any(module == p or module.startswith(p + ".") for p in prefixes)


def check_architecture_policy(
    files: list[dict[str, str]],
    target_python: str,
    policy: dict[str, Any],
    package: str | None = None,
) -> dict[str, Any]:
    if not isinstance(policy, dict) or policy.get("schema") != ARCHITECTURE_POLICY_SCHEMA_V1:
        raise ContractError(f"policy schema must be {ARCHITECTURE_POLICY_SCHEMA_V1}")

    rules = policy.get("rules", [])
    if not isinstance(rules, list):
        raise ContractError("policy.rules must be a list")

    graph = build_module_graph(files, target_python, package)
    violations = []

    for i, rule in enumerate(rules):
        if not isinstance(rule, dict):
            raise ContractError(f"rules[{i}] must be an object")
        rule_id = rule.get("rule_id")
        if not isinstance(rule_id, str) or not rule_id:
            raise ContractError(f"rules[{i}].rule_id must be non-empty")

        from_prefixes = rule.get("from_prefixes", [])
        deny_to = rule.get("deny_to_prefixes", [])
        allow_to = rule.get("allow_to_prefixes")

        if not isinstance(from_prefixes, list) or not all(isinstance(x, str) for x in from_prefixes):
            raise ContractError(f"rules[{i}].from_prefixes must be string list")
        if not isinstance(deny_to, list) or not all(isinstance(x, str) for x in deny_to):
            raise ContractError(f"rules[{i}].deny_to_prefixes must be string list")
        if allow_to is not None and (
            not isinstance(allow_to, list) or not all(isinstance(x, str) for x in allow_to)
        ):
            raise ContractError(f"rules[{i}].allow_to_prefixes must be string list")

        for edge in graph["edges"]:
            source = edge["from"]
            target = edge["target"]
            if not _matches_prefix(source, from_prefixes):
                continue

            reason = None
            if deny_to and _matches_prefix(target, deny_to):
                reason = "DENIED_IMPORT"
            elif allow_to is not None and not _matches_prefix(target, allow_to):
                reason = "IMPORT_OUTSIDE_ALLOWLIST"

            if reason:
                violations.append({
                    "rule_id": rule_id,
                    "reason": reason,
                    "from": source,
                    "to": target,
                    "raw": edge["raw"],
                })

    result = {
        "schema": "axm.python-architecture-policy-result.v1",
        "policy_id": policy.get("policy_id"),
        "violations": sorted(
            violations,
            key=lambda x: (x["rule_id"], x["from"], x["to"], x["reason"]),
        ),
        "status": "PASS" if not violations else "VIOLATIONS",
        "automatic_restructure": False,
        "graph_digest": digest_object(graph["edges"]),
    }
    result["result_digest"] = digest_object(result)
    return result
