from __future__ import annotations

import hashlib
from collections import Counter
from pathlib import PurePosixPath
from typing import Any

from .analyze import analyze_source
from .canonical import digest_object
from .project_graph import (
    build_call_graph,
    build_module_graph,
    cycles,
    reverse_dependency_closure,
)


def _api_surface(analysis: dict[str, Any]) -> list[dict[str, Any]]:
    out = []
    api = analysis.get("api", {})

    for fn in api.get("functions", []):
        if fn.get("public"):
            out.append({
                "kind": "function",
                "name": fn["name"],
                "async": fn.get("async", False),
                "parameters": fn.get("parameters", []),
                "returns": fn.get("returns"),
            })

    for cls in api.get("classes", []):
        if cls.get("public"):
            out.append({
                "kind": "class",
                "name": cls["name"],
                "bases": cls.get("bases", []),
                "methods": [
                    {
                        "name": method["name"],
                        "async": method.get("async", False),
                        "parameters": method.get("parameters", []),
                        "returns": method.get("returns"),
                    }
                    for method in cls.get("methods", [])
                    if method.get("public")
                ],
            })

    for const in api.get("constants", []):
        if const.get("public"):
            out.append({
                "kind": "constant",
                "name": const["name"],
                "annotation": const.get("annotation"),
            })

    return sorted(out, key=lambda x: (x["kind"], x["name"]))


def api_passport(
    files: list[dict[str, str]],
    target_python: str,
) -> dict[str, Any]:
    modules = []
    for item in sorted(files, key=lambda x: x["path"]):
        if not item["path"].endswith(".py"):
            continue
        analysis = analyze_source(item["source"], item["path"], target_python)
        surface = _api_surface(analysis)
        modules.append({
            "path": item["path"],
            "public_api": surface,
            "api_digest": digest_object(surface),
        })

    project_surface = [
        {"path": m["path"], "public_api": m["public_api"]}
        for m in modules
    ]
    return {
        "schema": "axm.python-api-passport.v1",
        "target_python": target_python,
        "modules": modules,
        "project_api_digest": digest_object(project_surface),
        "truth_boundary": (
            "Static declared public API. Dynamic __getattr__, runtime export "
            "mutation, metaprogramming, generated members, and undocumented "
            "behavioral contracts are outside this passport."
        ),
    }


def compare_api_passports(
    before: dict[str, Any],
    after: dict[str, Any],
) -> dict[str, Any]:
    def flatten(passport: dict[str, Any]) -> dict[str, dict[str, Any]]:
        out = {}
        for module in passport.get("modules", []):
            path = module["path"]
            for item in module.get("public_api", []):
                key = f"{path}|{item['kind']}|{item['name']}"
                out[key] = item
        return out

    b = flatten(before)
    a = flatten(after)
    removed = sorted(set(b) - set(a))
    added = sorted(set(a) - set(b))
    changed = sorted(
        key for key in set(a) & set(b)
        if b[key] != a[key]
    )

    if removed or changed:
        compatibility = "BREAKING_OR_CHANGED"
    elif added:
        compatibility = "ADDITIVE"
    else:
        compatibility = "UNCHANGED"

    return {
        "compatibility": compatibility,
        "removed": removed,
        "added": added,
        "changed": changed,
        "before_digest": before.get("project_api_digest"),
        "after_digest": after.get("project_api_digest"),
    }


def architecture_report(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
) -> dict[str, Any]:
    graph = build_module_graph(files, target_python, package)
    call_graph = build_call_graph(files, target_python, package)

    fan_in = Counter()
    fan_out = Counter()
    for edge in graph["edges"]:
        fan_out[edge["from"]] += 1
        fan_in[edge["target"]] += 1

    modules = graph["modules"]
    isolated = sorted(
        m for m in modules
        if fan_in[m] == 0 and fan_out[m] == 0
    )
    roots = sorted(
        m for m in modules
        if fan_in[m] == 0 and fan_out[m] > 0
    )
    leaves = sorted(
        m for m in modules
        if fan_in[m] > 0 and fan_out[m] == 0
    )

    hotspots = sorted(
        (
            {
                "module": module,
                "fan_in": fan_in[module],
                "fan_out": fan_out[module],
                "coupling": fan_in[module] + fan_out[module],
            }
            for module in modules
        ),
        key=lambda x: (-x["coupling"], -x["fan_in"], x["module"]),
    )

    return {
        "schema": "axm.python-architecture-report.v1",
        "module_graph": graph,
        "call_graph": call_graph,
        "cycles": cycles(graph),
        "roots": roots,
        "leaves": leaves,
        "isolated_modules": isolated,
        "hotspots": hotspots,
        "architecture_digest": digest_object({
            "edges": graph["edges"],
            "cycles": cycles(graph),
            "hotspots": hotspots,
        }),
    }


def affected_tests(
    files: list[dict[str, str]],
    target_python: str,
    changed_paths: list[str],
    package: str | None = None,
) -> dict[str, Any]:
    graph = build_module_graph(files, target_python, package)
    path_to_module = graph["path_to_module"]

    unknown_paths = sorted(set(changed_paths) - set(path_to_module))
    changed_modules = sorted(
        {
            path_to_module[path]
            for path in changed_paths
            if path in path_to_module
        }
    )
    impacted_modules = reverse_dependency_closure(graph, changed_modules)

    test_paths = []
    direct_test_modules = []
    for path, module in sorted(path_to_module.items()):
        p = PurePosixPath(path)
        name = p.name
        is_test = (
            "tests" in p.parts
            or name.startswith("test_")
            or name.endswith("_test.py")
        )
        if is_test:
            test_paths.append(path)
            direct_test_modules.append(module)

    impacted_tests = sorted(
        path
        for path, module in path_to_module.items()
        if module in impacted_modules
        and path in test_paths
    )

    # If a changed test file itself is supplied, retain it.
    for path in changed_paths:
        if path in test_paths and path not in impacted_tests:
            impacted_tests.append(path)
    impacted_tests = sorted(impacted_tests)

    return {
        "schema": "axm.python-affected-tests.v1",
        "changed_paths": sorted(set(changed_paths)),
        "unknown_changed_paths": unknown_paths,
        "changed_modules": changed_modules,
        "impacted_modules": impacted_modules,
        "affected_test_paths": impacted_tests,
        "all_test_paths": sorted(test_paths),
        "confidence": (
            "STATIC_IMPORT_GRAPH"
            if not unknown_paths
            else "STATIC_IMPORT_GRAPH_WITH_UNKNOWN_PATHS"
        ),
        "truth_boundary": (
            "Import-graph blast radius is conservative but not complete for "
            "runtime imports, plugin discovery, reflection, data-driven tests, "
            "or tests whose dependency is behavioral rather than imported."
        ),
    }
