from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .errors import AuthorityError


ALLOWED = frozenset({
    "READ_SPEC",
    "READ_PROJECT_TREE",
    "WRITE_STAGING",
    "RUN_STATIC_ANALYZER",
    "RUN_SANDBOX_TESTS",
})

REFUSED = frozenset({
    "EXECUTE_GENERATED_CODE",
    "NETWORK",
    "INSTALL_PACKAGE",
    "WRITE_OUTSIDE_STAGING",
    "REGISTER_CAPABILITY",
    "PROMOTE",
    "CANON",
})


@dataclass(frozen=True)
class AuthorityDecision:
    requested: tuple[str, ...]
    effective: tuple[str, ...]


def evaluate_authority(requested: Iterable[str]) -> AuthorityDecision:
    normalized = tuple(sorted(set(str(x) for x in requested)))
    unknown = tuple(x for x in normalized if x not in ALLOWED and x not in REFUSED)
    forbidden = tuple(x for x in normalized if x in REFUSED)

    if unknown:
        raise AuthorityError("UNKNOWN_AUTHORITY:" + ",".join(unknown))
    if forbidden:
        raise AuthorityError("AUTHORITY_EXCEEDS_CEILING:" + ",".join(forbidden))

    return AuthorityDecision(
        requested=normalized,
        effective=tuple(x for x in normalized if x in ALLOWED),
    )
