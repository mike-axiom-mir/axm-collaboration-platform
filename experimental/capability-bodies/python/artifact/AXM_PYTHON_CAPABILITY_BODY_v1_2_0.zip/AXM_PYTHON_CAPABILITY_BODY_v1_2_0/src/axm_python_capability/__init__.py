"""AXM deterministic modular Python capability."""

from .adapter_runner import run_adapter_request
from .sandbox import sandbox_doctor
from .sandbox_tests import run_sandbox_test_request
from .compatibility import grammar_matrix, project_grammar_matrix
from .engineering import architecture_report, affected_tests, api_passport, compare_api_passports
from .migrations import dependency_migration_plan
from .refactor import plan_public_symbol_rename
from .reference_index import build_reference_index
from .dead_code import dead_code_candidates
from .architecture_policy import check_architecture_policy
from .test_priority import prioritize_affected_tests
from .risk import change_risk_passport
from .proven_refactor import proven_symbol_rename_plan, plan_module_move
from .stewardship import stewardship_report
from .evidence_cache import incremental_evidence_snapshot
from .evidence_store import persist_snapshot, load_snapshot
from .repo_shards import plan_repository_shards
from .change_sets import analyze_change_set_conflicts, compose_change_sets, change_set_order
from .rollback import generate_rollback_packet, apply_rollback_packet
from .member_flow import class_member_flow
from .behavior_fixtures import normalize_behavior_fixtures, validate_behavior_fixtures_against_api
from .semantic_changes import semantic_change_graph
from .stream_index import stream_repository_index
from .advanced_members import advanced_member_flow
from .change_passport import build_change_passport
from .behavior_runner import generate_behavior_unittest_source, behavior_fixture_execution_plan, run_behavior_fixtures_sandboxed
from .builder import build_request
from .project_builder import build_project
from .patch import apply_patch_request
from .constants import CAPABILITY_ID, CAPABILITY_VERSION
from .contracts import BuildRequest, BuildResult
from .errors import CapabilityError, AuthorityError, ContractError, VerificationError

__version__ = CAPABILITY_VERSION

__all__ = [
    "run_adapter_request",
    "sandbox_doctor",
    "run_sandbox_test_request",
    "grammar_matrix",
    "project_grammar_matrix",
    "architecture_report",
    "affected_tests",
    "api_passport",
    "compare_api_passports",
    "dependency_migration_plan",
    "plan_public_symbol_rename",
    "build_reference_index",
    "dead_code_candidates",
    "check_architecture_policy",
    "prioritize_affected_tests",
    "change_risk_passport",
    "proven_symbol_rename_plan",
    "plan_module_move",
    "stewardship_report",
    "incremental_evidence_snapshot",
    "persist_snapshot",
    "load_snapshot",
    "plan_repository_shards",
    "analyze_change_set_conflicts",
    "compose_change_sets",
    "change_set_order",
    "generate_rollback_packet",
    "apply_rollback_packet",
    "class_member_flow",
    "normalize_behavior_fixtures",
    "validate_behavior_fixtures_against_api",
    "semantic_change_graph",
    "stream_repository_index",
    "advanced_member_flow",
    "build_change_passport",
    "generate_behavior_unittest_source",
    "behavior_fixture_execution_plan",
    "run_behavior_fixtures_sandboxed",
    "build_request",
    "build_project",
    "apply_patch_request",
    "CAPABILITY_ID",
    "CAPABILITY_VERSION",
    "BuildRequest",
    "BuildResult",
    "CapabilityError",
    "AuthorityError",
    "ContractError",
    "VerificationError",    "build_reference_blueprint",
    "assess_candidate_body",
    "build_python_implementation_map",
    "audit_package",
    "build_maturity_passport",
    "run_corpus",
    "module_build_reproducibility",
    "project_build_reproducibility",
    "patch_reproducibility",
    "append_regression_record",
    "verify_regression_ledger",
    "run_scale_probe",
    "synthetic_python_files",
    "run_fault_campaign",
    "run_verification_campaign",
    "packaging_truth_passport",
    "semantic_consensus_passport",
    "fine_grained_invalidation",
    "symbol_snapshot",
    "check_interface_policy",
    "normalize_flow_findings",
    "compare_flow_providers",
    "test_strength_passport",
    "analyze_lossless_source",
    "libcst_status",

]

from .reference_blueprint import build_reference_blueprint, assess_candidate_body
from .implementation_map import build_python_implementation_map
from .self_audit import audit_package
from .maturity import build_maturity_passport

from .verification_corpus import run_corpus
from .reproducibility import (
    module_build_reproducibility,
    project_build_reproducibility,
    patch_reproducibility,
)
from .regression_ledger import append_regression_record, verify_regression_ledger
from .scale_probe import run_scale_probe, synthetic_python_files
from .fault_campaign import run_fault_campaign
from .verification_campaign import run_verification_campaign

from .packaging_truth import packaging_truth_passport
from .semantic_consensus import semantic_consensus_passport
from .fine_grained import fine_grained_invalidation, symbol_snapshot
from .interface_policy import check_interface_policy
from .flow_evidence import normalize_flow_findings, compare_flow_providers
from .test_strength import test_strength_passport
from .lossless_cst import analyze_lossless_source, libcst_status
