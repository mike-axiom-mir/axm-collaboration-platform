from __future__ import annotations

import hashlib
from collections import defaultdict
from typing import Any

from .canonical import digest_object
from .errors import ContractError
from .patch import apply_patch_request


def _sha(text: str) -> str:
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()


def _normalize_change_sets(change_sets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    seen_ids = set()
    for i, cs in enumerate(change_sets):
        if not isinstance(cs, dict):
            raise ContractError(f"change_sets[{i}] must be an object")
        change_id = cs.get("change_id")
        if not isinstance(change_id, str) or not change_id:
            raise ContractError(f"change_sets[{i}].change_id required")
        if change_id in seen_ids:
            raise ContractError(f"duplicate change_id: {change_id}")
        seen_ids.add(change_id)
        operations = cs.get("operations")
        if not isinstance(operations, list) or not operations:
            raise ContractError(f"{change_id}.operations must be non-empty")
        depends_on = cs.get("depends_on", [])
        if not isinstance(depends_on, list) or not all(
            isinstance(x, str) and x for x in depends_on
        ):
            raise ContractError(f"{change_id}.depends_on must be a string list")
        if change_id in depends_on:
            raise ContractError(f"{change_id} cannot depend on itself")

        out.append({
            "change_id": change_id,
            "depends_on": sorted(set(depends_on)),
            "operations": operations,
            "metadata": cs.get("metadata", {}),
        })
    return sorted(out, key=lambda x: x["change_id"])


def change_set_order(
    change_sets: list[dict[str, Any]],
) -> dict[str, Any]:
    normalized = _normalize_change_sets(change_sets)
    ids = {x["change_id"] for x in normalized}
    missing = sorted({
        dep
        for item in normalized
        for dep in item["depends_on"]
        if dep not in ids
    })
    if missing:
        result = {
            "status": "MISSING_DEPENDENCIES",
            "missing": missing,
            "order": [],
            "cycles": [],
        }
        result["digest"] = digest_object(result)
        return result

    dependencies = {
        item["change_id"]: set(item["depends_on"])
        for item in normalized
    }
    dependents: dict[str, set[str]] = defaultdict(set)
    for item in normalized:
        for dep in item["depends_on"]:
            dependents[dep].add(item["change_id"])

    ready = sorted(
        change_id
        for change_id, deps in dependencies.items()
        if not deps
    )
    order = []
    while ready:
        current = ready.pop(0)
        order.append(current)
        for child in sorted(dependents.get(current, set())):
            dependencies[child].discard(current)
            if not dependencies[child] and child not in order and child not in ready:
                ready.append(child)
                ready.sort()

    remaining = sorted(
        change_id
        for change_id, deps in dependencies.items()
        if deps
    )
    status = "PASS" if not remaining else "DEPENDENCY_CYCLE"
    result = {
        "status": status,
        "missing": [],
        "order": order if status == "PASS" else [],
        "cycles": remaining,
    }
    result["digest"] = digest_object(result)
    return result


def analyze_change_set_conflicts(
    change_sets: list[dict[str, Any]],
) -> dict[str, Any]:
    normalized = _normalize_change_sets(change_sets)
    dependency_order = change_set_order(change_sets)
    by_path: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for cs in normalized:
        for index, op in enumerate(cs["operations"]):
            if not isinstance(op, dict):
                raise ContractError(
                    f"{cs['change_id']}.operations[{index}] must be object"
                )
            path = op.get("path")
            kind = op.get("op")
            if not isinstance(path, str) or not path:
                raise ContractError("change operation path required")
            if not isinstance(kind, str) or not kind:
                raise ContractError("change operation op required")
            by_path[path].append({
                "change_id": cs["change_id"],
                "index": index,
                "op": op,
            })

    conflicts = []
    order_dependencies = []

    for path in sorted(by_path):
        records = by_path[path]
        if len(records) < 2:
            continue

        deletes = [r for r in records if r["op"]["op"] == "delete"]
        creates = [r for r in records if r["op"]["op"] == "create"]
        replaces = [r for r in records if r["op"]["op"] == "replace_exact"]
        append_prepend = [
            r for r in records
            if r["op"]["op"] in {"append", "prepend"}
        ]

        if deletes and len(records) > 1:
            conflicts.append({
                "path": path,
                "kind": "DELETE_OVERLAPS_OTHER_CHANGE",
                "changes": sorted({r["change_id"] for r in records}),
            })

        if len(creates) > 1:
            sources = {r["op"].get("source") for r in creates}
            if len(sources) > 1:
                conflicts.append({
                    "path": path,
                    "kind": "MULTIPLE_CREATE_DIFFERENT_CONTENT",
                    "changes": sorted({r["change_id"] for r in creates}),
                })

        # Two exact replacements targeting the same old text but producing
        # different new text are directly incompatible.
        replace_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for record in replaces:
            replace_groups[str(record["op"].get("old"))].append(record)
        for old, group in sorted(replace_groups.items()):
            if len(group) > 1:
                news = {str(r["op"].get("new")) for r in group}
                if len(news) > 1:
                    conflicts.append({
                        "path": path,
                        "kind": "SAME_ANCHOR_DIFFERENT_REPLACEMENT",
                        "old": old,
                        "changes": sorted({r["change_id"] for r in group}),
                    })

        # Even non-conflicting edits on one path can be order-dependent.
        if len({r["change_id"] for r in records}) > 1 and (
            append_prepend or replaces
        ):
            order_dependencies.append({
                "path": path,
                "kind": "SAME_FILE_ORDER_DEPENDENCY",
                "changes": sorted({r["change_id"] for r in records}),
            })

    result = {
        "schema": "axm.python-change-set-conflicts.v1",
        "conflicts": sorted(
            conflicts,
            key=lambda x: (x["path"], x["kind"], str(x.get("changes"))),
        ),
        "order_dependencies": sorted(
            order_dependencies,
            key=lambda x: (x["path"], x["kind"]),
        ),
        "dependency_order": dependency_order,
        "status": (
            dependency_order["status"]
            if dependency_order["status"] != "PASS"
            else "CONFLICTS" if conflicts else (
                "ORDER_DEPENDENT" if order_dependencies else "CLEAN"
            )
        ),
        "truth_boundary": (
            "Conflict analysis is deterministic over declared patch operations. "
            "Semantic conflicts between different files may still require project "
            "impact/API/test evidence."
        ),
    }
    result["conflict_digest"] = digest_object(result)
    return result


def compose_change_sets(
    *,
    request_id: str,
    target_python: str,
    base_files: list[dict[str, str]],
    change_sets: list[dict[str, Any]],
    guards: dict[str, Any] | None = None,
) -> dict[str, Any]:
    conflicts = analyze_change_set_conflicts(change_sets)
    if conflicts["dependency_order"]["status"] != "PASS":
        return {
            "schema": "axm.python-composed-change-set.v1",
            "request_id": request_id,
            "status": "HOLD_CHANGE_DEPENDENCIES",
            "conflict_analysis": conflicts,
            "automatic_apply": False,
        }
    if conflicts["conflicts"]:
        return {
            "schema": "axm.python-composed-change-set.v1",
            "request_id": request_id,
            "status": "HOLD_CONFLICTS",
            "conflict_analysis": conflicts,
            "automatic_apply": False,
        }

    normalized = _normalize_change_sets(change_sets)
    by_id = {x["change_id"]: x for x in normalized}
    order = conflicts["dependency_order"]["order"]
    combined_operations = []
    for change_id in order:
        for operation in by_id[change_id]["operations"]:
            combined_operations.append(dict(operation))

    patch_request = {
        "schema": "axm.python-patch-request.v1",
        "request_id": request_id,
        "target_python": target_python,
        "files": base_files,
        "operations": combined_operations,
        "guards": guards or {},
    }
    patched = apply_patch_request(patch_request)

    result = {
        "schema": "axm.python-composed-change-set.v1",
        "request_id": request_id,
        "status": "VERIFIED_COMPOSED_CANDIDATE",
        "change_order": order,
        "conflict_analysis": conflicts,
        "patch_receipt": patched["receipt"],
        "files": patched["files"],
        "impact": patched["impact"],
        "automatic_apply": False,
    }
    result["composition_digest"] = digest_object(result)
    return result
