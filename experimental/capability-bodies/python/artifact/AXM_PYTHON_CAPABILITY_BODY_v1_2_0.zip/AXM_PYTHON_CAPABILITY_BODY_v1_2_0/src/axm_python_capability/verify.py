from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Iterable

from .analyze import analyze_source


def sha256_file(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def verify_files(paths: Iterable[Path], base: Path, *, target_python: str) -> list[dict[str, object]]:
    results = []
    for path in sorted(paths, key=lambda p: p.relative_to(base).as_posix()):
        rel = path.relative_to(base).as_posix()
        data = path.read_bytes()
        item: dict[str, object] = {
            "path": rel,
            "sha256": sha256_file(path),
            "bytes": len(data),
        }
        if path.suffix == ".py":
            item["python"] = analyze_source(data.decode("utf-8"), rel, target_python)
        results.append(item)
    return results
