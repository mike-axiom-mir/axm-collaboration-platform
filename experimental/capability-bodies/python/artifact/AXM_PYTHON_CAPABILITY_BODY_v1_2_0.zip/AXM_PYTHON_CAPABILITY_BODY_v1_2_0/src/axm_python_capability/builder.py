from __future__ import annotations

import json
import shutil
from pathlib import Path, PurePosixPath
from typing import Any

from .authority import evaluate_authority
from .canonical import digest_object, stable_id
from .constants import CAPABILITY_ID, CAPABILITY_VERSION
from .contracts import BuildRequest, BuildResult
from .errors import VerificationError
from .render import render_module
from .verify import verify_files


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    path.write_bytes(normalized.encode("utf-8"))


def _module_source(module: dict[str, Any]) -> str:
    if "source" in module and module["source"] is not None:
        return module["source"].replace("\r\n", "\n").replace("\r", "\n")
    return render_module(module)


def build_request(raw: dict[str, Any], staging_root: str | Path) -> BuildResult:
    request = BuildRequest.from_dict(raw)
    authority = evaluate_authority(request.authorities)
    normalized = request.normalized()

    run_id = stable_id(
        "pybuild",
        {
            "capability_id": CAPABILITY_ID,
            "capability_version": CAPABILITY_VERSION,
            "request": normalized,
        },
    )
    request_digest = digest_object(normalized)

    root = Path(staging_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    run_dir = root / run_id
    if run_dir.exists():
        shutil.rmtree(run_dir)
    run_dir.mkdir(parents=True)

    package_dir = run_dir / request.package
    package_dir.mkdir(parents=True)

    init_source = request.package_init
    if init_source is None:
        init_source = f'"""Generated package for {request.request_id}."""\n'
    init_path = package_dir / "__init__.py"
    write_text(init_path, init_source)
    generated = [init_path]

    for module in request.modules:
        rel = PurePosixPath(module["path"])
        path = package_dir.joinpath(*rel.parts)
        write_text(path, _module_source(module))
        generated.append(path)

        current = path.parent
        while current != package_dir and package_dir in current.parents:
            pkg_init = current / "__init__.py"
            if not pkg_init.exists():
                write_text(pkg_init, '"""Generated package namespace."""\n')
                generated.append(pkg_init)
            current = current.parent

    for resource in request.resources:
        rel = PurePosixPath(resource["path"])
        path = package_dir.joinpath(*rel.parts)
        if "text" in resource:
            content = resource["text"]
        else:
            content = json.dumps(resource["json"], indent=2, sort_keys=True, ensure_ascii=False) + "\n"
        write_text(path, content)
        generated.append(path)

    verification = verify_files(generated, run_dir, target_python=request.target_python)

    effect_signals = sorted({
        signal
        for item in verification
        for signal in (
            item.get("python", {}).get("effect_signals", [])
            if isinstance(item.get("python"), dict)
            else []
        )
    })

    symbols = []
    imports = set()
    for item in verification:
        py = item.get("python")
        if isinstance(py, dict):
            for symbol in py.get("symbols", []):
                symbols.append({"path": item["path"], **symbol})
            imports.update(py.get("imports", []))

    manifest = {
        "schema": "axm.python-build-manifest.v2",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "run_id": run_id,
        "request_id": request.request_id,
        "request_digest": request_digest,
        "goal": request.goal,
        "package": request.package,
        "target_python": request.target_python,
        "provenance": sorted(set(request.provenance)),
        "files": verification,
        "symbol_index": sorted(symbols, key=lambda x: (x["path"], x["kind"], x["name"])),
        "dependency_index": sorted(imports),
        "effect_signals": effect_signals,
        "effect_signals_are_static_only": True,
        "status": "VERIFIED_STAGING_CANDIDATE",
    }
    manifest_path = run_dir / "axm_build_manifest.json"
    write_text(manifest_path, json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n")

    receipt_core = {
        "schema": "axm.python-build-receipt.v1",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "run_id": run_id,
        "request_id": request.request_id,
        "request_digest": request_digest,
        "manifest_digest": digest_object(manifest),
        "target_python": request.target_python,
        "requested_authority": list(authority.requested),
        "effective_authority": list(authority.effective),
        "verification": "PASS",
        "effect_signals": effect_signals,
        "generated_code_executed": False,
        "network_requested_by_builder": False,
        "packages_installed": False,
        "registered": False,
        "promoted": False,
        "canon": False,
        "status": "DETACHED_CANDIDATE",
    }
    receipt = dict(receipt_core)
    receipt["receipt_digest"] = digest_object(receipt_core)

    receipt_path = run_dir / "axm_build_receipt.json"
    write_text(receipt_path, json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False) + "\n")

    reloaded = json.loads(receipt_path.read_text(encoding="utf-8"))
    supplied = reloaded.pop("receipt_digest")
    if supplied != digest_object(reloaded):
        raise VerificationError("RECEIPT_DIGEST_MISMATCH")

    return BuildResult(
        run_id=run_id,
        staging_dir=str(run_dir),
        manifest_path=str(manifest_path),
        receipt_path=str(receipt_path),
        receipt=receipt,
    )
