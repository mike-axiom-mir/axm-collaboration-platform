from __future__ import annotations

import ast
import re
from pathlib import PurePosixPath
from typing import Any

from .analyze import parse_source
from .canonical import digest_object
from .errors import ContractError
from .project_graph import module_name_from_path
from .reference_index import build_reference_index


def _line_offsets(source: str) -> list[int]:
    offsets = [0]
    total = 0
    for line in source.splitlines(keepends=True):
        total += len(line)
        offsets.append(total)
    return offsets


def _span_to_absolute(
    source: str,
    start_line: int,
    start_col: int,
    end_line: int,
    end_col: int,
) -> tuple[int, int]:
    offsets = _line_offsets(source)
    start = offsets[start_line - 1] + start_col
    end = offsets[end_line - 1] + end_col
    return start, end


def _make_span_edit(
    *,
    path: str,
    source: str,
    start_line: int,
    start_col: int,
    end_line: int,
    end_col: int,
    new: str,
    kind: str,
) -> dict[str, Any]:
    start, end = _span_to_absolute(source, start_line, start_col, end_line, end_col)
    old = source[start:end]
    return {
        "path": path,
        "kind": kind,
        "start_line": start_line,
        "start_col": start_col,
        "end_line": end_line,
        "end_col": end_col,
        "old": old,
        "new": new,
    }


def proven_symbol_rename_plan(
    files: list[dict[str, str]],
    target_python: str,
    *,
    module: str,
    old: str,
    new: str,
    package: str | None = None,
) -> dict[str, Any]:
    if not old.isidentifier() or not new.isidentifier() or old == new:
        raise ContractError("old/new must be distinct Python identifiers")

    index = build_reference_index(files, target_python, package)
    target_symbol = f"{module}.{old}"
    definitions = [d for d in index["definitions"] if d["symbol"] == target_symbol]
    if len(definitions) != 1:
        raise ContractError("target symbol must have exactly one top-level definition")

    sources = {x["path"]: x["source"] for x in files}
    edits = []
    holds = []

    # Definition token.
    definition = definitions[0]
    source = sources[definition["path"]]
    line = source.splitlines()[definition["line"] - 1]
    match = re.search(rf"\b(?:async\s+def|def|class)\s+({re.escape(old)})\b", line)
    if not match:
        holds.append({
            "path": definition["path"],
            "line": definition["line"],
            "reason": "DEFINITION_NAME_SPAN_NOT_PROVEN",
        })
    else:
        edits.append(_make_span_edit(
            path=definition["path"],
            source=source,
            start_line=definition["line"],
            start_col=match.start(1),
            end_line=definition["line"],
            end_col=match.end(1),
            new=new,
            kind="DEFINITION_NAME",
        ))

    # From-import binding edits.
    for item in files:
        if not item["path"].endswith(".py"):
            continue
        tree = parse_source(item["source"], item["path"], target_python)
        if not isinstance(tree, ast.Module):
            continue
        source_module = module_name_from_path(item["path"], package)

        for node in tree.body:
            if not isinstance(node, ast.ImportFrom):
                continue

            # Resolve relative base in the same way as the reference index.
            if node.level:
                parts = source_module.split(".")[:-1]
                climb = node.level - 1
                if climb > len(parts):
                    base = None
                else:
                    if climb:
                        parts = parts[:-climb]
                    if node.module:
                        parts += node.module.split(".")
                    base = ".".join(parts) if parts else None
            else:
                base = node.module or None

            if base != module:
                continue

            for alias in node.names:
                if alias.name != old:
                    continue
                segment = ast.get_source_segment(item["source"], node)
                if not segment:
                    holds.append({
                        "path": item["path"],
                        "line": node.lineno,
                        "reason": "IMPORT_SEGMENT_UNAVAILABLE",
                    })
                    continue
                matches = list(re.finditer(rf"\b{re.escape(old)}\b", segment))
                if len(matches) != 1:
                    holds.append({
                        "path": item["path"],
                        "line": node.lineno,
                        "reason": "IMPORT_NAME_SPAN_AMBIGUOUS",
                    })
                    continue
                start_abs, _ = _span_to_absolute(
                    item["source"], node.lineno, node.col_offset,
                    node.end_lineno, node.end_col_offset,
                )
                abs_start = start_abs + matches[0].start()
                abs_end = start_abs + matches[0].end()
                offsets = _line_offsets(item["source"])

                # Convert absolute back to line/col.
                start_line = max(i for i, off in enumerate(offsets) if off <= abs_start) + 1
                end_line = max(i for i, off in enumerate(offsets) if off <= abs_end) + 1
                start_col = abs_start - offsets[start_line - 1]
                end_col = abs_end - offsets[end_line - 1]
                edits.append(_make_span_edit(
                    path=item["path"],
                    source=item["source"],
                    start_line=start_line,
                    start_col=start_col,
                    end_line=end_line,
                    end_col=end_col,
                    new=new,
                    kind="FROM_IMPORT_BINDING",
                ))

    # Proven references from reference index.
    for ref in index["references"]:
        if ref["target"] != target_symbol:
            continue

        if ref["resolution"] in {"RESOLVED_IMPORTED_SYMBOL", "RESOLVED_MODULE_SYMBOL"}:
            # Name node span is exactly the identifier.
            edits.append(_make_span_edit(
                path=ref["path"],
                source=sources[ref["path"]],
                start_line=ref["line"],
                start_col=ref["column"],
                end_line=ref["end_line"],
                end_col=ref["end_column"],
                new=new,
                kind="PROVEN_NAME_REFERENCE",
            ))
        elif ref["resolution"] == "RESOLVED_IMPORTED_ATTRIBUTE":
            old_segment = ref["raw"]
            if old_segment and old_segment.endswith("." + old):
                new_segment = old_segment[:-(len(old))] + new
                edits.append(_make_span_edit(
                    path=ref["path"],
                    source=sources[ref["path"]],
                    start_line=ref["line"],
                    start_col=ref["column"],
                    end_line=ref["end_line"],
                    end_col=ref["end_column"],
                    new=new_segment,
                    kind="PROVEN_ATTRIBUTE_REFERENCE",
                ))
            else:
                holds.append({
                    "path": ref["path"],
                    "line": ref["line"],
                    "reason": "ATTRIBUTE_SEGMENT_NOT_PROVEN",
                })

    # Deduplicate exact spans.
    dedup = {}
    for edit in edits:
        key = (
            edit["path"], edit["start_line"], edit["start_col"],
            edit["end_line"], edit["end_col"],
        )
        existing = dedup.get(key)
        if existing and existing["new"] != edit["new"]:
            holds.append({
                "path": edit["path"],
                "line": edit["start_line"],
                "reason": "CONFLICTING_EDIT_FOR_SAME_SPAN",
            })
        else:
            dedup[key] = edit
    edits = sorted(
        dedup.values(),
        key=lambda x: (
            x["path"], x["start_line"], x["start_col"], x["kind"]
        ),
    )

    result = {
        "schema": "axm.python-proven-refactor-plan.v1",
        "operation": "RENAME_TOP_LEVEL_SYMBOL",
        "target_symbol": target_symbol,
        "new_symbol": f"{module}.{new}",
        "exact_edits": edits,
        "holds": sorted(
            holds,
            key=lambda x: (x["path"], x.get("line") or -1, x["reason"]),
        ),
        "status": "READY_EXACT_EDITS" if not holds else "HOLD_PARTIAL_PROOF",
        "automatic_apply": False,
        "reference_index_digest": index["index_digest"],
        "truth_boundary": (
            "Only spans whose binding is statically proven are included. "
            "Dynamic or unresolved references are never guessed."
        ),
    }
    result["plan_digest"] = digest_object(result)
    return result


def plan_module_move(
    files: list[dict[str, str]],
    target_python: str,
    *,
    old_module: str,
    new_module: str,
    new_path: str,
    package: str | None = None,
) -> dict[str, Any]:
    path_map = {
        item["path"]: module_name_from_path(item["path"], package)
        for item in files
        if item["path"].endswith(".py")
    }
    old_paths = [path for path, module in path_map.items() if module == old_module]
    if len(old_paths) != 1:
        raise ContractError("old_module must resolve to exactly one file")
    if new_module in path_map.values():
        raise ContractError("new_module already exists")
    if new_path in path_map:
        raise ContractError("new_path already exists")

    source_by_path = {x["path"]: x["source"] for x in files}
    old_path = old_paths[0]
    source = source_by_path[old_path]
    old_parent = old_module.rsplit(".", 1)[0] if "." in old_module else ""
    new_parent = new_module.rsplit(".", 1)[0] if "." in new_module else ""

    holds = []
    import_edits = []

    target_tree = parse_source(source, old_path, target_python)
    if isinstance(target_tree, ast.Module) and old_parent != new_parent:
        for node in ast.walk(target_tree):
            if isinstance(node, ast.ImportFrom) and node.level > 0:
                holds.append({
                    "path": old_path,
                    "line": node.lineno,
                    "reason": "MOVED_MODULE_HAS_RELATIVE_IMPORT_AND_PARENT_CHANGES",
                })

    for item in sorted(files, key=lambda x: x["path"]):
        if not item["path"].endswith(".py"):
            continue
        tree = parse_source(item["source"], item["path"], target_python)
        if not isinstance(tree, ast.Module):
            continue
        importer_module = module_name_from_path(item["path"], package)

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == old_module:
                        segment = ast.get_source_segment(item["source"], node)
                        if segment and segment.count(old_module) == 1:
                            import_edits.append({
                                "path": item["path"],
                                "line": node.lineno,
                                "old": segment,
                                "new": segment.replace(old_module, new_module, 1),
                                "kind": "IMPORT_MODULE",
                            })
                        else:
                            holds.append({
                                "path": item["path"],
                                "line": node.lineno,
                                "reason": "MODULE_IMPORT_SEGMENT_AMBIGUOUS",
                            })

            elif isinstance(node, ast.ImportFrom):
                segment = ast.get_source_segment(item["source"], node)
                if not segment:
                    holds.append({
                        "path": item["path"],
                        "line": node.lineno,
                        "reason": "FROM_IMPORT_SEGMENT_UNAVAILABLE",
                    })
                    continue

                # Resolve the import base to an absolute module.
                if node.level == 0:
                    base = node.module or ""
                else:
                    parts = importer_module.split(".")[:-1]
                    climb = node.level - 1
                    if climb > len(parts):
                        base = None
                    else:
                        if climb:
                            parts = parts[:-climb]
                        if node.module:
                            parts += node.module.split(".")
                        base = ".".join(parts) if parts else None

                if base == old_module:
                    # `from .api import X` / `from old.module import X`
                    marker = re.search(r"\bimport\b", segment)
                    if marker:
                        tail = segment[marker.start():]
                        import_edits.append({
                            "path": item["path"],
                            "line": node.lineno,
                            "old": segment,
                            "new": f"from {new_module} {tail}",
                            "kind": "FROM_MODULE_IMPORT",
                        })
                    else:
                        holds.append({
                            "path": item["path"],
                            "line": node.lineno,
                            "reason": "FROM_IMPORT_KEYWORD_NOT_PROVEN",
                        })
                    continue

                # `from . import api` where `.api` is the moved module.
                if node.level > 0 and base:
                    matching = [
                        alias for alias in node.names
                        if f"{base}.{alias.name}" == old_module
                    ]
                    if matching:
                        if len(node.names) != 1 or len(matching) != 1:
                            holds.append({
                                "path": item["path"],
                                "line": node.lineno,
                                "reason": "MULTI_NAME_RELATIVE_IMPORT_NEEDS_SPLIT",
                            })
                            continue
                        alias = matching[0]
                        new_parent, new_leaf = (
                            new_module.rsplit(".", 1)
                            if "." in new_module
                            else ("", new_module)
                        )
                        imported = new_leaf + (f" as {alias.asname}" if alias.asname else "")
                        if new_parent:
                            replacement = f"from {new_parent} import {imported}"
                        else:
                            replacement = f"import {imported}"
                        import_edits.append({
                            "path": item["path"],
                            "line": node.lineno,
                            "old": segment,
                            "new": replacement,
                            "kind": "RELATIVE_MODULE_IMPORT",
                        })

    result = {
        "schema": "axm.python-module-move-plan.v1",
        "operation": "MOVE_MODULE",
        "old_module": old_module,
        "new_module": new_module,
        "file_move": {"from": old_path, "to": new_path},
        "import_edits": sorted(
            import_edits,
            key=lambda x: (x["path"], x["line"], x["kind"]),
        ),
        "holds": sorted(
            holds,
            key=lambda x: (x["path"], x["line"], x["reason"]),
        ),
        "status": "READY_EXACT_PLAN" if not holds else "HOLD_PARTIAL_PROOF",
        "automatic_apply": False,
        "truth_boundary": (
            "Absolute import edits are planned only when exact source segments "
            "are available. Parent-changing moves with relative imports HOLD."
        ),
    }
    result["plan_digest"] = digest_object(result)
    return result
