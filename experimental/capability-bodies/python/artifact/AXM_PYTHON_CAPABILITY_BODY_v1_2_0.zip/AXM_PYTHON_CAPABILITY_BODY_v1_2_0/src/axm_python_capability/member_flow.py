from __future__ import annotations

import ast
from collections import defaultdict
from typing import Any

from .analyze import parse_source, safe_unparse
from .canonical import digest_object
from .project_graph import module_name_from_path


def class_member_flow(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
) -> dict[str, Any]:
    classes = {}
    references = []

    for item in sorted(files, key=lambda x: x["path"]):
        if not item["path"].endswith(".py"):
            continue
        module = module_name_from_path(item["path"], package)
        tree = parse_source(item["source"], item["path"], target_python)
        if not isinstance(tree, ast.Module):
            continue

        for node in tree.body:
            if not isinstance(node, ast.ClassDef):
                continue
            class_symbol = f"{module}.{node.name}"
            methods = {}
            class_attributes = set()
            instance_attributes = set()

            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    methods[child.name] = {
                        "symbol": f"{class_symbol}.{child.name}",
                        "line": child.lineno,
                        "async": isinstance(child, ast.AsyncFunctionDef),
                        "decorators": [
                            safe_unparse(x) for x in child.decorator_list
                        ],
                    }
                    for desc in ast.walk(child):
                        if isinstance(desc, (ast.Assign, ast.AnnAssign)):
                            targets = (
                                desc.targets
                                if isinstance(desc, ast.Assign)
                                else [desc.target]
                            )
                            for target in targets:
                                if (
                                    isinstance(target, ast.Attribute)
                                    and isinstance(target.value, ast.Name)
                                    and target.value.id == "self"
                                ):
                                    instance_attributes.add(target.attr)

                elif isinstance(child, (ast.Assign, ast.AnnAssign)):
                    targets = (
                        child.targets
                        if isinstance(child, ast.Assign)
                        else [child.target]
                    )
                    for target in targets:
                        if isinstance(target, ast.Name):
                            class_attributes.add(target.id)

            classes[class_symbol] = {
                "path": item["path"],
                "module": module,
                "name": node.name,
                "bases": [safe_unparse(x) for x in node.bases],
                "methods": methods,
                "class_attributes": sorted(class_attributes),
                "instance_attributes": sorted(instance_attributes),
            }

            # self.method / self.attr references within methods.
            for child in node.body:
                if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                source_method = f"{class_symbol}.{child.name}"
                for desc in ast.walk(child):
                    if (
                        isinstance(desc, ast.Attribute)
                        and isinstance(desc.value, ast.Name)
                        and desc.value.id == "self"
                    ):
                        member = desc.attr
                        if member in methods:
                            target = methods[member]["symbol"]
                            resolution = "RESOLVED_SELF_METHOD"
                        elif member in instance_attributes:
                            target = f"{class_symbol}.instance:{member}"
                            resolution = "RESOLVED_SELF_ATTRIBUTE"
                        elif member in class_attributes:
                            target = f"{class_symbol}.class:{member}"
                            resolution = "RESOLVED_CLASS_ATTRIBUTE"
                        else:
                            target = None
                            resolution = "UNRESOLVED_SELF_MEMBER"

                        references.append({
                            "from": source_method,
                            "member": member,
                            "target": target,
                            "resolution": resolution,
                            "line": getattr(desc, "lineno", None),
                        })

    # Resolve statically named bases within the project.
    class_names = set(classes)
    simple = defaultdict(list)
    for symbol in class_names:
        simple[symbol.rsplit(".", 1)[-1]].append(symbol)

    inheritance = []
    for symbol, info in sorted(classes.items()):
        for base in info["bases"]:
            target = None
            if base in class_names:
                target = base
            elif base in simple and len(simple[base]) == 1:
                target = simple[base][0]
            inheritance.append({
                "class": symbol,
                "base_raw": base,
                "resolved_base": target,
                "resolution": "RESOLVED_LOCAL_BASE" if target else "EXTERNAL_OR_UNRESOLVED_BASE",
            })

    # Overrides against provable local bases.
    overrides = []
    for edge in inheritance:
        base = edge["resolved_base"]
        if not base:
            continue
        child = edge["class"]
        child_methods = classes[child]["methods"]
        base_methods = classes[base]["methods"]
        for method in sorted(set(child_methods) & set(base_methods)):
            overrides.append({
                "class": child,
                "base": base,
                "method": method,
                "child_symbol": child_methods[method]["symbol"],
                "base_symbol": base_methods[method]["symbol"],
            })

    result = {
        "schema": "axm.python-member-flow.v1",
        "classes": [
            {"symbol": symbol, **classes[symbol]}
            for symbol in sorted(classes)
        ],
        "inheritance": sorted(
            inheritance,
            key=lambda x: (x["class"], x["base_raw"]),
        ),
        "overrides": sorted(
            overrides,
            key=lambda x: (x["class"], x["method"], x["base"]),
        ),
        "member_references": sorted(
            references,
            key=lambda x: (
                x["from"], x["line"] or -1, x["member"], x["resolution"],
            ),
        ),
        "truth_boundary": (
            "Class/member flow resolves syntactic self-members and simple local "
            "inheritance. Descriptors, __getattr__, metaclasses, dynamic base "
            "construction, monkey patching, and runtime instance types remain dynamic."
        ),
    }
    result["flow_digest"] = digest_object(result)
    return result
