from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Any, Iterator

from .authority import evaluate_authority
from .canonical import digest_object
from .constants import STREAM_INDEX_SCHEMA_V1
from .errors import AuthorityError, ContractError


IGNORED_DIRS = frozenset({
    ".git", ".hg", ".svn",
    ".venv", "venv", "env",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "node_modules", ".tox", ".nox",
})


def _sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def _walk(root: Path) -> Iterator[Path]:
    # Iterative deterministic scandir walk: does not materialize all paths.
    stack = [root]
    while stack:
        current = stack.pop()
        try:
            entries = sorted(
                os.scandir(current),
                key=lambda x: x.name,
                reverse=True,
            )
        except OSError as exc:
            raise ContractError(f"STREAM_READ_FAILED:{current}") from exc

        for entry in entries:
            path = Path(entry.path)
            rel_parts = path.relative_to(root).parts
            if any(part in IGNORED_DIRS for part in rel_parts):
                continue
            if entry.is_symlink():
                raise ContractError(
                    f"STREAM_SYMLINK_REFUSED:{path.relative_to(root).as_posix()}"
                )
            if entry.is_dir(follow_symlinks=False):
                stack.append(path)
            elif entry.is_file(follow_symlinks=False):
                yield path
            else:
                raise ContractError(
                    f"STREAM_SPECIAL_FILE_REFUSED:{path.relative_to(root).as_posix()}"
                )


def stream_repository_index(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict) or raw.get("schema") != STREAM_INDEX_SCHEMA_V1:
        raise ContractError(f"schema must be {STREAM_INDEX_SCHEMA_V1}")

    authorities = raw.get("authorities", [])
    if not isinstance(authorities, list):
        raise ContractError("authorities must be a list")
    decision = evaluate_authority(authorities)
    if "READ_PROJECT_TREE" not in decision.effective:
        raise AuthorityError("READ_PROJECT_TREE_REQUIRED")

    root = Path(str(raw.get("root", ""))).expanduser().resolve()
    if not root.is_dir():
        raise ContractError("root must be a directory")

    page_size = int(raw.get("page_size", 500))
    max_files = int(raw.get("max_files", 1_000_000))
    max_total_bytes = int(raw.get("max_total_bytes", 50 * 1024 * 1024 * 1024))

    if not 1 <= page_size <= 10_000:
        raise ContractError("page_size out of bounds")
    if not 1 <= max_files <= 10_000_000:
        raise ContractError("max_files out of bounds")
    if not 1 <= max_total_bytes <= 10 * 1024 * 1024 * 1024 * 1024:
        raise ContractError("max_total_bytes out of bounds")

    pages = []
    page_entries = []
    file_count = 0
    total_bytes = 0

    def flush() -> None:
        nonlocal page_entries
        if not page_entries:
            return
        core = {
            "page": len(pages) + 1,
            "entries": page_entries,
        }
        pages.append({
            **core,
            "page_digest": digest_object(core),
        })
        page_entries = []

    for path in _walk(root):
        stat = path.stat()
        size = stat.st_size
        file_count += 1
        total_bytes += size
        if file_count > max_files:
            raise ContractError(f"STREAM_FILE_LIMIT:{max_files}")
        if total_bytes > max_total_bytes:
            raise ContractError(f"STREAM_BYTE_LIMIT:{max_total_bytes}")

        rel = path.relative_to(root).as_posix()
        page_entries.append({
            "path": rel,
            "bytes": size,
            "sha256": _sha_file(path),
            "suffix": path.suffix.lower(),
        })
        if len(page_entries) >= page_size:
            flush()

    flush()

    root_core = {
        "schema": "axm.python-stream-index.v1",
        "root_name": root.name,
        "file_count": file_count,
        "total_bytes": total_bytes,
        "page_size": page_size,
        "pages": [
            {
                "page": page["page"],
                "page_digest": page["page_digest"],
                "entry_count": len(page["entries"]),
            }
            for page in pages
        ],
        "source_mutation": False,
        "truth_boundary": (
            "Streaming index is a read-only content snapshot. File contents can "
            "change after indexing; downstream consumers should re-check hashes."
        ),
    }
    result = dict(root_core)
    result["root_digest"] = digest_object(root_core)
    result["page_payloads"] = pages
    return result
