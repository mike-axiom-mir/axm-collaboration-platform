from __future__ import annotations

import json
import shutil
from pathlib import Path, PurePosixPath
from typing import Any

from .authority import evaluate_authority
from .canonical import digest_object, stable_id
from .constants import CAPABILITY_ID, CAPABILITY_VERSION, PROJECT_SCHEMA_V1
from .contracts import normalize_target_python, safe_relpath, require_text
from .errors import ContractError, VerificationError
from .intelligence import aggregate_project_metrics, build_import_graph, public_api_index
from .packaging import render_pyproject
from .verify import verify_files


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.replace("\r\n", "\n").replace("\r", "\n").encode("utf-8"))


def _validate_source_list(value: Any, label: str) -> list[dict[str, str]]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ContractError(f"{label} must be a list")
    out = []
    seen = set()
    for i, item in enumerate(value):
        if not isinstance(item, dict):
            raise ContractError(f"{label}[{i}] must be an object")
        path = safe_relpath(item.get("path"), f"{label}[{i}].path", suffix=".py")
        source = item.get("source")
        if not isinstance(source, str):
            raise ContractError(f"{label}[{i}].source must be a string")
        if path in seen:
            raise ContractError(f"duplicate {label} path: {path}")
        seen.add(path)
        out.append({"path": path, "source": source})
    return out


def build_project(raw: dict[str, Any], staging_root: str | Path) -> dict[str, Any]:
    if not isinstance(raw, dict) or raw.get("schema") != PROJECT_SCHEMA_V1:
        raise ContractError(f"schema must be {PROJECT_SCHEMA_V1}")

    request_id = require_text(raw.get("request_id"), "request_id")
    goal = require_text(raw.get("goal"), "goal")
    target_python = normalize_target_python(raw.get("target_python"))
    authorities = raw.get("authorities", ["READ_SPEC", "WRITE_STAGING"])
    if not isinstance(authorities, list):
        raise ContractError("authorities must be a list")
    authority = evaluate_authority(authorities)

    project = raw.get("project")
    if not isinstance(project, dict):
        raise ContractError("project must be an object")
    package = project.get("package")
    if not isinstance(package, str) or not package.isidentifier():
        raise ContractError("project.package must be a Python identifier")

    modules = _validate_source_list(raw.get("modules"), "modules")
    tests = _validate_source_list(raw.get("tests"), "tests")

    files = raw.get("files", [])
    if not isinstance(files, list):
        raise ContractError("files must be a list")

    normalized = {
        "schema": PROJECT_SCHEMA_V1,
        "request_id": request_id,
        "goal": goal,
        "target_python": target_python,
        "authorities": sorted(set(str(x) for x in authorities)),
        "project": project,
        "modules": modules,
        "tests": tests,
        "files": files,
        "provenance": sorted(set(str(x) for x in raw.get("provenance", []))),
        "metadata": raw.get("metadata", {}),
    }

    run_id = stable_id("pyproject", {
        "capability": CAPABILITY_ID,
        "version": CAPABILITY_VERSION,
        "request": normalized,
    })
    request_digest = digest_object(normalized)

    root = Path(staging_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    run_dir = root / run_id
    if run_dir.exists():
        shutil.rmtree(run_dir)
    run_dir.mkdir(parents=True)

    layout = project.get("layout", "src")
    package_dir = (run_dir / "src" / package) if layout == "src" else (run_dir / package)
    package_dir.mkdir(parents=True)
    init_path = package_dir / "__init__.py"
    _write(init_path, str(project.get("package_init", '"""Generated Python package."""\n')))

    generated = [init_path]
    project_python_meta = [{
        "path": init_path.relative_to(run_dir).as_posix(),
        "project_relative_python_path": "__init__.py",
    }]

    for item in modules:
        rel = PurePosixPath(item["path"])
        path = package_dir.joinpath(*rel.parts)
        _write(path, item["source"])
        generated.append(path)
        project_python_meta.append({
            "path": path.relative_to(run_dir).as_posix(),
            "project_relative_python_path": item["path"],
        })

        # Create namespace package inits deterministically.
        current = path.parent
        while current != package_dir and package_dir in current.parents:
            pkg_init = current / "__init__.py"
            if not pkg_init.exists():
                _write(pkg_init, '"""Generated package namespace."""\n')
                generated.append(pkg_init)
                project_python_meta.append({
                    "path": pkg_init.relative_to(run_dir).as_posix(),
                    "project_relative_python_path": pkg_init.relative_to(package_dir).as_posix(),
                })
            current = current.parent

    for item in tests:
        rel = PurePosixPath(item["path"])
        path = run_dir.joinpath(*rel.parts)
        _write(path, item["source"])
        generated.append(path)
        project_python_meta.append({
            "path": path.relative_to(run_dir).as_posix(),
            "project_relative_python_path": item["path"],
        })

    pyproject = run_dir / "pyproject.toml"
    _write(pyproject, render_pyproject(project))
    generated.append(pyproject)

    seen_other = {p.relative_to(run_dir).as_posix() for p in generated}
    for i, item in enumerate(files):
        if not isinstance(item, dict):
            raise ContractError(f"files[{i}] must be an object")
        rel = safe_relpath(item.get("path"), f"files[{i}].path")
        if rel in seen_other:
            raise ContractError(f"duplicate output path: {rel}")
        has_text = "text" in item
        has_json = "json" in item
        if has_text == has_json:
            raise ContractError(f"files[{i}] needs exactly one of text or json")
        content = item["text"] if has_text else json.dumps(
            item["json"], indent=2, sort_keys=True, ensure_ascii=False
        ) + "\n"
        if not isinstance(content, str):
            raise ContractError(f"files[{i}].text must be a string")
        path = run_dir.joinpath(*PurePosixPath(rel).parts)
        _write(path, content)
        generated.append(path)
        seen_other.add(rel)

    verification = verify_files(generated, run_dir, target_python=target_python)
    by_path = {x["path"]: x for x in verification}

    python_files = []
    for meta in project_python_meta:
        verified = by_path[meta["path"]]
        python_files.append({
            **verified,
            "project_relative_python_path": meta["project_relative_python_path"],
        })

    declared = project.get("dependencies", [])
    graph = build_import_graph(package, python_files, declared_dependencies=declared)
    metrics = aggregate_project_metrics(python_files)
    api = public_api_index(python_files)

    manifest = {
        "schema": "axm.python-project-manifest.v1",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "run_id": run_id,
        "request_id": request_id,
        "request_digest": request_digest,
        "goal": goal,
        "target_python": target_python,
        "project": project,
        "files": verification,
        "import_graph": graph,
        "project_metrics": metrics,
        "public_api_index": api,
        "status": "VERIFIED_PROJECT_CANDIDATE",
    }
    manifest_path = run_dir / "axm_project_manifest.json"
    _write(manifest_path, json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n")

    receipt_core = {
        "schema": "axm.python-project-receipt.v1",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "run_id": run_id,
        "request_id": request_id,
        "request_digest": request_digest,
        "manifest_digest": digest_object(manifest),
        "target_python": target_python,
        "requested_authority": list(authority.requested),
        "effective_authority": list(authority.effective),
        "verification": "PASS",
        "generated_code_executed": False,
        "network_requested_by_builder": False,
        "packages_installed": False,
        "registered": False,
        "promoted": False,
        "canon": False,
        "status": "DETACHED_PROJECT_CANDIDATE",
    }
    receipt = dict(receipt_core)
    receipt["receipt_digest"] = digest_object(receipt_core)
    receipt_path = run_dir / "axm_project_receipt.json"
    _write(receipt_path, json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False) + "\n")

    return {
        "run_id": run_id,
        "staging_dir": str(run_dir),
        "manifest_path": str(manifest_path),
        "receipt_path": str(receipt_path),
        "manifest": manifest,
        "receipt": receipt,
    }
