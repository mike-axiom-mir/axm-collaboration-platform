from __future__ import annotations

import json
import tomllib
from pathlib import Path
from typing import Any

from .authority import ALLOWED, REFUSED
from .canonical import digest_object
from .constants import CAPABILITY_VERSION
from .reference_blueprint import build_reference_blueprint
from .implementation_map import build_python_implementation_map


REQUIRED_REFUSED = {
    "EXECUTE_GENERATED_CODE",
    "NETWORK",
    "INSTALL_PACKAGE",
    "WRITE_OUTSIDE_STAGING",
    "REGISTER_CAPABILITY",
    "PROMOTE",
    "CANON",
}


def _check(name: str, passed: bool, detail: Any = None) -> dict[str, Any]:
    return {
        "check": name,
        "status": "PASS" if passed else "FAIL",
        "detail": detail,
    }


def audit_package(root: str | Path) -> dict[str, Any]:
    root = Path(root).resolve()
    checks = []

    manifest_path = root / "manifest.json"
    pyproject_path = root / "pyproject.toml"
    reference_doc = root / "CODE_BODY_REFERENCE_ARCHITECTURE.md"
    readme = root / "README.md"

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        checks.append(_check("manifest_json", True))
    except Exception as exc:
        manifest = {}
        checks.append(_check("manifest_json", False, str(exc)))

    try:
        pyproject = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
        checks.append(_check("pyproject_toml", True))
    except Exception as exc:
        pyproject = {}
        checks.append(_check("pyproject_toml", False, str(exc)))

    manifest_version = manifest.get("version")
    project_version = pyproject.get("project", {}).get("version")
    checks.append(_check(
        "version_alignment",
        manifest_version == CAPABILITY_VERSION == project_version,
        {
            "runtime": CAPABILITY_VERSION,
            "manifest": manifest_version,
            "pyproject": project_version,
        },
    ))

    checks.append(_check(
        "authority_sets_disjoint",
        not (set(ALLOWED) & set(REFUSED)),
        sorted(set(ALLOWED) & set(REFUSED)),
    ))
    checks.append(_check(
        "required_refusals_present",
        REQUIRED_REFUSED <= set(REFUSED),
        sorted(REQUIRED_REFUSED - set(REFUSED)),
    ))

    authority_ceiling = set(manifest.get("authority_ceiling", []))
    checks.append(_check(
        "manifest_authority_matches_allowed",
        authority_ceiling == set(ALLOWED),
        {
            "manifest": sorted(authority_ceiling),
            "runtime": sorted(ALLOWED),
        },
    ))

    schema_dir = root / "schemas"
    ids = {}
    schema_errors = []
    schema_count = 0
    for path in sorted(schema_dir.glob("*.json")):
        schema_count += 1
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            schema_errors.append(f"{path.name}:{exc}")
            continue
        schema_id = value.get("$id")
        if schema_id:
            if schema_id in ids:
                schema_errors.append(
                    f"duplicate-id:{schema_id}:{ids[schema_id]}:{path.name}"
                )
            ids[schema_id] = path.name

    checks.append(_check(
        "schema_registry",
        not schema_errors and schema_count > 0,
        {"count": schema_count, "errors": schema_errors},
    ))

    referenced_paths = []
    for key, value in sorted(manifest.items()):
        if (
            isinstance(value, str)
            and (
                key.endswith("_schema")
                or key in {"input_schema", "receipt_schema", "reference_contract"}
            )
        ):
            referenced_paths.append((key, value))
    missing_refs = [
        {"field": key, "path": value}
        for key, value in referenced_paths
        if not (root / value).exists()
    ]
    checks.append(_check(
        "manifest_references_exist",
        not missing_refs,
        missing_refs,
    ))

    try:
        ref_text = reference_doc.read_text(encoding="utf-8")
    except OSError:
        ref_text = ""
    missing_layers = [
        layer for layer in range(9)
        if f"Layer {layer}" not in ref_text
    ]
    checks.append(_check(
        "reference_layers_0_to_8",
        not missing_layers,
        missing_layers,
    ))
    checks.append(_check(
        "reference_docs_exist",
        reference_doc.exists() and readme.exists(),
        {
            "reference": reference_doc.exists(),
            "readme": readme.exists(),
        },
    ))

    source_errors = []
    source_count = 0
    src_root = root / "src"
    for path in sorted(src_root.rglob("*.py")):
        source_count += 1
        try:
            compile(
                path.read_text(encoding="utf-8"),
                path.as_posix(),
                "exec",
                dont_inherit=True,
            )
        except Exception as exc:
            source_errors.append(f"{path.relative_to(root)}:{exc}")
    checks.append(_check(
        "shipped_python_compiles",
        not source_errors and source_count > 0,
        {"count": source_count, "errors": source_errors},
    ))

    symlinks = [
        p.relative_to(root).as_posix()
        for p in root.rglob("*")
        if p.is_symlink()
    ]
    checks.append(_check(
        "package_contains_no_symlinks",
        not symlinks,
        symlinks,
    ))

    features = manifest.get("features", [])
    checks.append(_check(
        "feature_manifest_unique",
        isinstance(features, list) and len(features) == len(set(features)),
        {"count": len(features) if isinstance(features, list) else None},
    ))

    blueprint = build_reference_blueprint()
    checks.append(_check(
        "reference_blueprint_layers",
        len(blueprint["layers"]) == 9
        and [x["layer"] for x in blueprint["layers"]] == list(range(9)),
        blueprint["blueprint_digest"],
    ))

    static_blueprint_path = root / "REFERENCE_BODY_BLUEPRINT.json"
    try:
        static_blueprint = json.loads(
            static_blueprint_path.read_text(encoding="utf-8")
        )
    except Exception as exc:
        static_blueprint = None
        checks.append(_check(
            "static_reference_blueprint",
            False,
            str(exc),
        ))
    else:
        checks.append(_check(
            "static_reference_blueprint",
            static_blueprint == blueprint,
            {
                "expected": blueprint["blueprint_digest"],
                "actual": static_blueprint.get("blueprint_digest"),
            },
        ))

    implementation = build_python_implementation_map()
    implementation_path = root / "PYTHON_REFERENCE_IMPLEMENTATION_MAP.json"
    try:
        static_implementation = json.loads(
            implementation_path.read_text(encoding="utf-8")
        )
    except Exception as exc:
        static_implementation = None
        checks.append(_check(
            "static_implementation_map",
            False,
            str(exc),
        ))
    else:
        checks.append(_check(
            "static_implementation_map",
            static_implementation == implementation,
            {
                "expected": implementation["implementation_digest"],
                "actual": static_implementation.get("implementation_digest"),
            },
        ))

    missing_impl_modules = []
    for layer in implementation["layers"]:
        for module in layer["modules"]:
            if not (root / "src" / "axm_python_capability" / module).exists():
                missing_impl_modules.append({
                    "layer": layer["layer"],
                    "module": module,
                })
    checks.append(_check(
        "implementation_modules_exist",
        not missing_impl_modules,
        missing_impl_modules,
    ))

    checklist_path = root / "DONOR_INTAKE_CHECKLIST.json"
    try:
        checklist = json.loads(checklist_path.read_text(encoding="utf-8"))
    except Exception as exc:
        checklist = {}
        checks.append(_check(
            "donor_checklist",
            False,
            str(exc),
        ))
    else:
        checks.append(_check(
            "donor_checklist",
            checklist.get("reference_blueprint_digest")
            == blueprint["blueprint_digest"]
            and checklist.get("automatic_install") is False
            and checklist.get("automatic_promotion") is False,
            checklist.get("checklist_digest"),
        ))

    failures = [item for item in checks if item["status"] != "PASS"]
    core = {
        "schema": "axm.python-self-audit.v1",
        "capability_version": CAPABILITY_VERSION,
        "checks": checks,
        "summary": {
            "passed": len(checks) - len(failures),
            "failed": len(failures),
            "total": len(checks),
        },
        "status": "PASS" if not failures else "FAIL",
        "failure_checks": [x["check"] for x in failures],
    }
    result = dict(core)
    result["audit_digest"] = digest_object(core)
    return result
