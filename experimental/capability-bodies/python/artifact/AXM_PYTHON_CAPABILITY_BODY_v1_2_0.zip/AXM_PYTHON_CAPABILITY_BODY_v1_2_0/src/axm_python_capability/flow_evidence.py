from __future__ import annotations

from typing import Any

from .canonical import digest_object
from .errors import ContractError


SUPPORTED_PROVIDERS = {"codeql", "semgrep", "custom"}


def normalize_flow_findings(
    provider: str,
    findings: list[dict[str, Any]],
) -> dict[str, Any]:
    provider = provider.lower()
    if provider not in SUPPORTED_PROVIDERS:
        raise ContractError(f"UNKNOWN_FLOW_PROVIDER:{provider}")
    if not isinstance(findings, list):
        raise ContractError("FLOW_FINDINGS_NOT_LIST")

    rows = []
    for i, finding in enumerate(findings):
        if not isinstance(finding, dict):
            raise ContractError(f"FLOW_FINDING_NOT_OBJECT:{i}")
        finding_id = finding.get("finding_id")
        source = finding.get("source")
        sink = finding.get("sink")
        path = finding.get("path", [])
        if not isinstance(finding_id, str) or not finding_id:
            raise ContractError(f"FLOW_FINDING_ID_REQUIRED:{i}")
        if not isinstance(source, dict) or not isinstance(sink, dict):
            raise ContractError(f"FLOW_ENDPOINTS_REQUIRED:{finding_id}")
        if not isinstance(path, list) or not all(isinstance(x, dict) for x in path):
            raise ContractError(f"FLOW_PATH_NOT_OBJECT_LIST:{finding_id}")

        row = {
            "finding_id": finding_id,
            "provider": provider,
            "rule_id": finding.get("rule_id"),
            "severity": str(finding.get("severity", "unknown")),
            "source": source,
            "sink": sink,
            "path": path,
            "barriers": finding.get("barriers", []),
            "sanitizers": finding.get("sanitizers", []),
            "confidence": finding.get("confidence"),
        }
        rows.append(row)

    core = {
        "schema": "axm.python-deep-flow-evidence.v1",
        "provider": provider,
        "findings": sorted(rows, key=lambda x: x["finding_id"]),
        "finding_count": len(rows),
        "status": "FINDINGS" if rows else "NO_FINDINGS_REPORTED",
        "source_code_executed_by_normalizer": False,
        "truth_boundary": (
            "AXM normalizes provider evidence; it does not claim to reproduce "
            "the provider's interprocedural solver. No findings is provider-scope "
            "evidence, not proof that no unsafe flow exists."
        ),
    }
    result = dict(core)
    result["evidence_digest"] = digest_object(core)
    return result


def compare_flow_providers(
    evidence: list[dict[str, Any]],
) -> dict[str, Any]:
    by_key = {}
    for package in evidence:
        provider = package.get("provider")
        for finding in package.get("findings", []):
            key = (
                str(finding.get("rule_id")),
                str(finding.get("source")),
                str(finding.get("sink")),
            )
            by_key.setdefault(key, []).append({
                "provider": provider,
                "finding_id": finding.get("finding_id"),
            })

    rows = []
    for key in sorted(by_key, key=str):
        providers = sorted(set(x["provider"] for x in by_key[key]))
        rows.append({
            "rule_id": key[0],
            "source": key[1],
            "sink": key[2],
            "providers": providers,
            "status": (
                "MULTI_PROVIDER_CORROBORATION"
                if len(providers) > 1
                else "SINGLE_PROVIDER"
            ),
        })

    core = {
        "schema": "axm.python-flow-provider-comparison.v1",
        "comparisons": rows,
        "truth_boundary": (
            "Provider agreement is corroboration, not proof. Provider disagreement "
            "is retained instead of silently selecting one implementation."
        ),
    }
    result = dict(core)
    result["comparison_digest"] = digest_object(core)
    return result
