from __future__ import annotations

import ast
from typing import Any

from .analyze import parse_source
from .canonical import digest_object
from .errors import ContractError
from .project_graph import module_name_from_path


def _resolve_relative(source_module: str, raw_module: str, level: int) -> str | None:
    if level <= 0:
        return raw_module or None
    parts = source_module.split(".")[:-1]
    climb = level - 1
    if climb > len(parts):
        return None
    if climb:
        parts = parts[:-climb]
    if raw_module:
        parts += raw_module.split(".")
    return ".".join(parts) if parts else None


def check_interface_policy(
    *,
    files: list[dict[str, str]],
    target_python: str,
    package: str | None,
    policy: dict[str, Any],
) -> dict[str, Any]:
    if not isinstance(policy, dict):
        raise ContractError("INTERFACE_POLICY_NOT_OBJECT")

    modules_policy = policy.get("modules", {})
    if not isinstance(modules_policy, dict):
        raise ContractError("INTERFACE_POLICY_MODULES_NOT_OBJECT")

    normalized_policy = {}
    for module, raw in sorted(modules_policy.items()):
        if not isinstance(raw, dict):
            raise ContractError(f"INTERFACE_POLICY_MODULE_NOT_OBJECT:{module}")
        public = raw.get("public", [])
        owners = raw.get("owners", [])
        visible_to = raw.get("visible_to")
        deprecated_for = raw.get("deprecated_for", [])
        for label, value in (
            ("public", public),
            ("owners", owners),
            ("deprecated_for", deprecated_for),
        ):
            if not isinstance(value, list) or not all(isinstance(x, str) for x in value):
                raise ContractError(f"INTERFACE_POLICY_{label.upper()}_INVALID:{module}")
        if visible_to is not None and (
            not isinstance(visible_to, list)
            or not all(isinstance(x, str) for x in visible_to)
        ):
            raise ContractError(f"INTERFACE_POLICY_VISIBLE_TO_INVALID:{module}")
        normalized_policy[module] = {
            "public": sorted(set(public)),
            "owners": sorted(set(owners)),
            "visible_to": sorted(set(visible_to)) if visible_to is not None else None,
            "deprecated_for": sorted(set(deprecated_for)),
        }

    violations = []
    observations = []

    for item in sorted(files, key=lambda x: x["path"]):
        if not item["path"].endswith(".py"):
            continue
        source_module = module_name_from_path(item["path"], package)
        tree = parse_source(item["source"], item["path"], target_python)
        if not isinstance(tree, ast.Module):
            continue

        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom):
                continue
            target_module = _resolve_relative(
                source_module,
                node.module or "",
                node.level,
            )
            if not target_module or target_module not in normalized_policy:
                continue

            target_policy = normalized_policy[target_module]
            visible_to = target_policy["visible_to"]
            if visible_to is not None and not any(
                source_module == prefix
                or source_module.startswith(prefix + ".")
                for prefix in visible_to
            ):
                violations.append({
                    "kind": "MODULE_VISIBILITY_VIOLATION",
                    "source_module": source_module,
                    "target_module": target_module,
                    "path": item["path"],
                    "line": node.lineno,
                })

            for alias in node.names:
                if alias.name == "*":
                    violations.append({
                        "kind": "STAR_IMPORT_CROSSES_INTERFACE",
                        "source_module": source_module,
                        "target_module": target_module,
                        "path": item["path"],
                        "line": node.lineno,
                    })
                    continue

                is_public = alias.name in target_policy["public"]
                deprecated = any(
                    source_module == prefix
                    or source_module.startswith(prefix + ".")
                    for prefix in target_policy["deprecated_for"]
                )
                observations.append({
                    "source_module": source_module,
                    "target_module": target_module,
                    "symbol": alias.name,
                    "public": is_public,
                    "deprecated_dependency": deprecated,
                    "owners": target_policy["owners"],
                    "path": item["path"],
                    "line": node.lineno,
                })
                if not is_public:
                    violations.append({
                        "kind": "PRIVATE_INTERFACE_IMPORT",
                        "source_module": source_module,
                        "target_module": target_module,
                        "symbol": alias.name,
                        "path": item["path"],
                        "line": node.lineno,
                    })

    core = {
        "schema": "axm.python-interface-policy-result.v1",
        "policy": normalized_policy,
        "observations": sorted(
            observations,
            key=lambda x: (
                x["source_module"], x["target_module"],
                x["symbol"], x["path"], x["line"],
            ),
        ),
        "violations": sorted(
            violations,
            key=lambda x: (
                x["kind"], x["source_module"],
                x["target_module"], x.get("symbol", ""),
                x["path"], x["line"],
            ),
        ),
        "status": "PASS" if not violations else "VIOLATIONS",
        "automatic_rewrite": False,
        "truth_boundary": (
            "Interface policy reasons about explicit import-from edges. Runtime "
            "attribute access, re-exports, importlib and reflection can bypass "
            "static interface observations."
        ),
    }
    result = dict(core)
    result["result_digest"] = digest_object(core)
    return result
