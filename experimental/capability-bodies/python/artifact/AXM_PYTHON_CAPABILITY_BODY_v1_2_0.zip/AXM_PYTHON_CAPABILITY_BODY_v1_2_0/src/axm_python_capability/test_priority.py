from __future__ import annotations

from collections import deque
from pathlib import PurePosixPath
from typing import Any

from .project_graph import build_module_graph


def _is_test_path(path: str) -> bool:
    p = PurePosixPath(path)
    return (
        "tests" in p.parts
        or p.name.startswith("test_")
        or p.name.endswith("_test.py")
    )


def prioritize_affected_tests(
    files: list[dict[str, str]],
    target_python: str,
    changed_paths: list[str],
    package: str | None = None,
) -> dict[str, Any]:
    graph = build_module_graph(files, target_python, package)
    path_to_module = graph["path_to_module"]
    module_to_path = {m: p for p, m in path_to_module.items()}

    seeds = sorted({
        path_to_module[p]
        for p in changed_paths
        if p in path_to_module
    })

    distances = {m: 0 for m in seeds}
    queue = deque(seeds)
    reverse = graph["reverse_adjacency"]

    while queue:
        current = queue.popleft()
        for parent in reverse.get(current, []):
            distance = distances[current] + 1
            if parent not in distances or distance < distances[parent]:
                distances[parent] = distance
                queue.append(parent)

    rows = []
    for path, module in sorted(path_to_module.items()):
        if not _is_test_path(path):
            continue
        if module not in distances:
            continue

        distance = distances[module]
        score = max(10, 100 - (distance * 20))
        if path in changed_paths:
            score = 100
            reason = "CHANGED_TEST_FILE"
        elif distance <= 1:
            reason = "DIRECT_OR_NEAR_DEPENDENT"
        elif distance <= 3:
            reason = "TRANSITIVE_DEPENDENT"
        else:
            reason = "DISTANT_TRANSITIVE_DEPENDENT"

        rows.append({
            "path": path,
            "module": module,
            "distance": distance,
            "priority_score": score,
            "reason": reason,
        })

    rows.sort(key=lambda x: (-x["priority_score"], x["distance"], x["path"]))
    return {
        "schema": "axm.python-test-priority.v1",
        "changed_paths": sorted(set(changed_paths)),
        "changed_modules": seeds,
        "prioritized_tests": rows,
        "truth_boundary": (
            "Priority is static dependency distance, not runtime coverage or "
            "historical failure probability."
        ),
    }
