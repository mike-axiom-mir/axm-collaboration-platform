from __future__ import annotations

import sys
from pathlib import PurePosixPath
from typing import Any


def stdlib_modules() -> frozenset[str]:
    names = getattr(sys, "stdlib_module_names", None)
    if names is not None:
        return frozenset(names)
    # Conservative fallback for older/non-CPython implementations.
    return frozenset({
        "abc", "argparse", "asyncio", "collections", "contextlib", "csv",
        "dataclasses", "datetime", "decimal", "enum", "functools", "hashlib",
        "importlib", "inspect", "io", "itertools", "json", "logging", "math",
        "multiprocessing", "os", "pathlib", "queue", "re", "shutil", "socket",
        "sqlite3", "statistics", "subprocess", "tempfile", "threading", "time",
        "tomllib", "traceback", "typing", "unittest", "urllib", "uuid", "venv",
        "xml", "zipfile"
    })


def module_name_for_path(package: str, rel_path: str) -> str:
    p = PurePosixPath(rel_path)
    parts = list(p.with_suffix("").parts)
    if parts and parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join([package] + parts) if parts else package


def build_import_graph(
    package: str,
    python_files: list[dict[str, Any]],
    declared_dependencies: list[str] | None = None,
) -> dict[str, Any]:
    declared_dependencies = declared_dependencies or []
    declared_roots = {
        dep.split("[", 1)[0].split("=", 1)[0].split("<", 1)[0].split(">", 1)[0]
        .split("~", 1)[0].split("!", 1)[0].strip().replace("-", "_")
        for dep in declared_dependencies
    }
    stdlib = stdlib_modules()

    module_by_path = {}
    known_modules = set()
    for item in python_files:
        rel = item["project_relative_python_path"]
        mod = module_name_for_path(package, rel)
        module_by_path[item["path"]] = mod
        known_modules.add(mod)

    edges = []
    third_party = set()
    stdlib_used = set()
    local_used = set()
    unresolved_relative = []

    for item in python_files:
        source_module = module_by_path[item["path"]]
        analysis = item.get("python", {})
        for rec in analysis.get("import_records", []):
            module = rec.get("module", "")
            level = int(rec.get("level", 0))
            root = module.split(".", 1)[0] if module else ""

            if level > 0:
                classification = "local_relative"
                local_used.add(module or ".")
                if not source_module:
                    unresolved_relative.append(rec)
            elif root == package or module in known_modules or any(
                module.startswith(m + ".") for m in known_modules
            ):
                classification = "local"
                local_used.add(module)
            elif root in stdlib:
                classification = "stdlib"
                stdlib_used.add(root)
            else:
                classification = "third_party_or_external"
                if root:
                    third_party.add(root)

            edges.append({
                "from": source_module,
                "import": module,
                "name": rec.get("name"),
                "level": level,
                "classification": classification,
            })

    declared_normalized = {x.replace("-", "_") for x in declared_roots}
    undeclared = sorted(x for x in third_party if x not in declared_normalized)

    return {
        "module_by_path": dict(sorted(module_by_path.items())),
        "edges": sorted(edges, key=lambda x: (
            x["from"], x["classification"], x["import"], x["name"] or ""
        )),
        "stdlib_used": sorted(stdlib_used),
        "local_used": sorted(local_used),
        "third_party_or_external": sorted(third_party),
        "declared_dependency_roots": sorted(declared_normalized),
        "undeclared_external_import_roots": undeclared,
        "unresolved_relative_records": unresolved_relative,
    }


def aggregate_project_metrics(python_files: list[dict[str, Any]]) -> dict[str, Any]:
    total_statements = 0
    total_functions = 0
    total_classes = 0
    total_branches = 0
    max_nesting = 0
    effects = set()
    feature_files: dict[str, list[str]] = {}
    tests = []

    for item in python_files:
        py = item.get("python", {})
        comp = py.get("complexity", {})
        total_statements += int(comp.get("statement_count", 0))
        total_functions += int(comp.get("function_count", 0))
        total_classes += int(comp.get("class_count", 0))
        total_branches += int(comp.get("branch_points", 0))
        max_nesting = max(max_nesting, int(comp.get("max_nesting", 0)))
        effects.update(py.get("effect_signals", []))

        for feature, active in py.get("feature_flags", {}).items():
            if active:
                feature_files.setdefault(feature, []).append(item["path"])

        if py.get("tests", {}).get("is_test_file"):
            tests.append({
                "path": item["path"],
                **py["tests"],
            })

    return {
        "python_file_count": len(python_files),
        "statement_count": total_statements,
        "function_count": total_functions,
        "class_count": total_classes,
        "branch_points": total_branches,
        "max_nesting": max_nesting,
        "effect_signals": sorted(effects),
        "feature_files": {
            key: sorted(value) for key, value in sorted(feature_files.items())
        },
        "test_files": sorted(tests, key=lambda x: x["path"]),
    }


def public_api_index(python_files: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for item in python_files:
        api = item.get("python", {}).get("api", {})
        for fn in api.get("functions", []):
            if fn.get("public"):
                out.append({
                    "path": item["path"],
                    "kind": "function",
                    "name": fn["name"],
                    "async": fn["async"],
                    "parameters": fn["parameters"],
                    "returns": fn["returns"],
                })
        for cls in api.get("classes", []):
            if cls.get("public"):
                out.append({
                    "path": item["path"],
                    "kind": "class",
                    "name": cls["name"],
                    "bases": cls["bases"],
                    "methods": [
                        {
                            "name": m["name"],
                            "async": m["async"],
                            "parameters": m["parameters"],
                            "returns": m["returns"],
                        }
                        for m in cls["methods"] if m.get("public")
                    ],
                })
    return sorted(out, key=lambda x: (x["path"], x["kind"], x["name"]))
