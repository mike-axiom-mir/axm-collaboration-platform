from __future__ import annotations

from typing import Any

from .canonical import digest_object
from .engineering import affected_tests, architecture_report
from .impact import analyze_bundle, diff_bundle


def change_risk_passport(
    before_files: list[dict[str, str]],
    after_files: list[dict[str, str]],
    target_python: str,
    changed_paths: list[str],
    package: str | None = None,
) -> dict[str, Any]:
    before = analyze_bundle(before_files, target_python)
    after = analyze_bundle(after_files, target_python)
    impact = diff_bundle(before, after)

    before_arch = architecture_report(before_files, target_python, package)
    after_arch = architecture_report(after_files, target_python, package)
    tests = affected_tests(before_files, target_python, changed_paths, package)

    dimensions = []

    def add(name: str, points: int, evidence: Any) -> None:
        if points > 0:
            dimensions.append({
                "dimension": name,
                "points": points,
                "evidence": evidence,
            })

    api_count = len(impact["public_api_removed_or_changed"])
    add("PUBLIC_API_CHANGE", min(35, api_count * 15), impact["public_api_removed_or_changed"])

    effect_count = len(impact["effect_signals_added"])
    add("NEW_EFFECT_CAPABILITY", min(20, effect_count * 10), impact["effect_signals_added"])

    import_count = len(impact["import_roots_added"])
    add("NEW_IMPORT_ROOT", min(10, import_count * 5), impact["import_roots_added"])

    removed_files = len(impact["files_removed"])
    add("FILE_REMOVAL", min(15, removed_files * 8), impact["files_removed"])

    before_minor = int(impact["minimum_grammar_before"].split(".")[1])
    after_minor = int(impact["minimum_grammar_after"].split(".")[1])
    if after_minor > before_minor:
        add(
            "MINIMUM_PYTHON_INCREASE",
            15,
            {
                "before": impact["minimum_grammar_before"],
                "after": impact["minimum_grammar_after"],
            },
        )

    branch_delta = int(impact["metric_delta"]["branch_points"])
    if branch_delta > 0:
        add("COMPLEXITY_INCREASE", min(10, branch_delta), branch_delta)

    cycle_delta = len(after_arch["cycles"]) - len(before_arch["cycles"])
    if cycle_delta > 0:
        add("NEW_IMPORT_CYCLE", min(20, cycle_delta * 10), after_arch["cycles"])

    affected_count = len(tests["affected_test_paths"])
    if affected_count:
        add("TEST_BLAST_RADIUS", min(10, max(1, affected_count)), tests["affected_test_paths"])

    if tests["unknown_changed_paths"]:
        add("UNKNOWN_CHANGED_PATH", 10, tests["unknown_changed_paths"])

    score = min(100, sum(x["points"] for x in dimensions))
    if score <= 20:
        level = "LOW"
    elif score <= 40:
        level = "MODERATE"
    elif score <= 70:
        level = "HIGH"
    else:
        level = "VERY_HIGH"

    passport = {
        "schema": "axm.python-change-risk-passport.v1",
        "score": score,
        "level": level,
        "dimensions": sorted(
            dimensions,
            key=lambda x: (-x["points"], x["dimension"]),
        ),
        "impact": impact,
        "affected_tests": tests,
        "before_architecture_digest": before_arch["architecture_digest"],
        "after_architecture_digest": after_arch["architecture_digest"],
        "automatic_approval": False,
        "truth_boundary": (
            "Deterministic static triage score, not probability of failure and "
            "not authorization to merge or deploy."
        ),
    }
    passport["passport_digest"] = digest_object(passport)
    return passport
