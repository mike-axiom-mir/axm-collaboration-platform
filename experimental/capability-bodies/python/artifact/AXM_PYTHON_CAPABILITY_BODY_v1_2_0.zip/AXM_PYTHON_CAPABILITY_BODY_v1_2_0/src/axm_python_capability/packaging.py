from __future__ import annotations

import json
from typing import Any

from .errors import ContractError


def _toml_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def _toml_array(values: list[str]) -> str:
    return "[" + ", ".join(_toml_string(v) for v in values) + "]"


def render_pyproject(project: dict[str, Any]) -> str:
    name = project.get("name")
    version = project.get("version", "0.1.0")
    package = project.get("package")
    if not isinstance(name, str) or not name.strip():
        raise ContractError("project.name is required")
    if not isinstance(package, str) or not package.isidentifier():
        raise ContractError("project.package must be a Python identifier")

    description = str(project.get("description", ""))
    requires_python = str(project.get("requires_python", ">=3.10"))
    dependencies = project.get("dependencies", [])
    if not isinstance(dependencies, list) or not all(isinstance(x, str) for x in dependencies):
        raise ContractError("project.dependencies must be a string list")

    lines = [
        "[build-system]",
        'requires = ["setuptools>=68"]',
        'build-backend = "setuptools.build_meta"',
        "",
        "[project]",
        f"name = {_toml_string(name)}",
        f"version = {_toml_string(str(version))}",
        f"description = {_toml_string(description)}",
        f"requires-python = {_toml_string(requires_python)}",
        f"dependencies = {_toml_array(sorted(dependencies))}",
    ]

    scripts = project.get("scripts", {})
    if scripts:
        if not isinstance(scripts, dict):
            raise ContractError("project.scripts must be an object")
        lines += ["", "[project.scripts]"]
        for key in sorted(scripts):
            lines.append(f"{key} = {_toml_string(str(scripts[key]))}")

    optional = project.get("optional_dependencies", {})
    if optional:
        if not isinstance(optional, dict):
            raise ContractError("project.optional_dependencies must be an object")
        lines += ["", "[project.optional-dependencies]"]
        for group in sorted(optional):
            vals = optional[group]
            if not isinstance(vals, list) or not all(isinstance(x, str) for x in vals):
                raise ContractError(f"optional dependency group {group} must be a string list")
            lines.append(f"{group} = {_toml_array(sorted(vals))}")

    layout = project.get("layout", "src")
    if layout == "src":
        lines += [
            "",
            "[tool.setuptools]",
            'package-dir = {"" = "src"}',
            "",
            "[tool.setuptools.packages.find]",
            'where = ["src"]',
        ]
    elif layout == "flat":
        lines += [
            "",
            "[tool.setuptools.packages.find]",
            'where = ["."]',
        ]
    else:
        raise ContractError("project.layout must be src or flat")

    return "\n".join(lines) + "\n"
