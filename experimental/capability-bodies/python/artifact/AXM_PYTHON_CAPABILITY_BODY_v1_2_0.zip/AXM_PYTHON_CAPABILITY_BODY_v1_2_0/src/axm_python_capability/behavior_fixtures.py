from __future__ import annotations

import json
from typing import Any

from .canonical import digest_object
from .constants import BEHAVIOR_FIXTURE_SCHEMA_V1
from .engineering import api_passport
from .errors import ContractError


def _jsonable(value: Any, label: str) -> None:
    try:
        json.dumps(value, sort_keys=True, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ContractError(f"{label} must be deterministic JSON data") from exc


def normalize_behavior_fixtures(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict) or raw.get("schema") != BEHAVIOR_FIXTURE_SCHEMA_V1:
        raise ContractError(f"schema must be {BEHAVIOR_FIXTURE_SCHEMA_V1}")

    fixtures = raw.get("fixtures")
    if not isinstance(fixtures, list) or not fixtures:
        raise ContractError("fixtures must be a non-empty list")

    out = []
    seen = set()
    for i, fixture in enumerate(fixtures):
        if not isinstance(fixture, dict):
            raise ContractError(f"fixtures[{i}] must be an object")
        fixture_id = fixture.get("fixture_id")
        target = fixture.get("target")
        if not isinstance(fixture_id, str) or not fixture_id:
            raise ContractError(f"fixtures[{i}].fixture_id required")
        if fixture_id in seen:
            raise ContractError(f"duplicate fixture_id: {fixture_id}")
        seen.add(fixture_id)
        if not isinstance(target, str) or not target:
            raise ContractError(f"fixtures[{i}].target required")

        args = fixture.get("args", [])
        kwargs = fixture.get("kwargs", {})
        _jsonable(args, f"fixtures[{i}].args")
        _jsonable(kwargs, f"fixtures[{i}].kwargs")

        expectation_keys = [
            key for key in ("expected_return", "expected_exception")
            if key in fixture
        ]
        if len(expectation_keys) != 1:
            raise ContractError(
                f"fixtures[{i}] requires exactly one expectation"
            )

        normalized = {
            "fixture_id": fixture_id,
            "target": target,
            "args": args,
            "kwargs": kwargs,
        }
        if "expected_return" in fixture:
            _jsonable(
                fixture["expected_return"],
                f"fixtures[{i}].expected_return",
            )
            normalized["expected_return"] = fixture["expected_return"]
        else:
            expected_exception = fixture["expected_exception"]
            if not isinstance(expected_exception, str) or not expected_exception:
                raise ContractError(
                    f"fixtures[{i}].expected_exception must be string"
                )
            normalized["expected_exception"] = expected_exception

        out.append(normalized)

    core = {
        "schema": BEHAVIOR_FIXTURE_SCHEMA_V1,
        "fixtures": sorted(out, key=lambda x: x["fixture_id"]),
        "execution_authorized": False,
    }
    result = dict(core)
    result["fixture_set_digest"] = digest_object(core)
    return result


def validate_behavior_fixtures_against_api(
    fixture_set: dict[str, Any],
    files: list[dict[str, str]],
    target_python: str,
) -> dict[str, Any]:
    normalized = normalize_behavior_fixtures(fixture_set)
    passport = api_passport(files, target_python)

    targets = set()
    for module in passport["modules"]:
        # The passport stores path-local public names. For this fixture contract,
        # target identifiers use path::name so resolution is explicit and
        # independent from uncertain package/module inference.
        path = module["path"]
        for item in module["public_api"]:
            targets.add(f"{path}::{item['name']}")

    rows = []
    for fixture in normalized["fixtures"]:
        rows.append({
            "fixture_id": fixture["fixture_id"],
            "target": fixture["target"],
            "status": (
                "TARGET_PRESENT"
                if fixture["target"] in targets
                else "TARGET_MISSING_OR_CHANGED"
            ),
        })

    result = {
        "schema": "axm.python-behavior-fixture-validation.v1",
        "fixture_set_digest": normalized["fixture_set_digest"],
        "api_passport_digest": passport["project_api_digest"],
        "results": rows,
        "status": (
            "PASS"
            if all(x["status"] == "TARGET_PRESENT" for x in rows)
            else "BROKEN_FIXTURE_TARGETS"
        ),
        "fixtures_executed": False,
        "truth_boundary": (
            "This validates behavioral fixture contracts against structural API "
            "presence only. Expected behavior is not proven until a separately "
            "authorized sandbox execution lane evaluates the fixtures."
        ),
    }
    result["validation_digest"] = digest_object(result)
    return result
