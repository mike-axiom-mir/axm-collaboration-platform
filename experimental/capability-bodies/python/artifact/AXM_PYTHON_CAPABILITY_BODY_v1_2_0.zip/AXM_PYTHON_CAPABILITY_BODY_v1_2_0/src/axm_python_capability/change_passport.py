from __future__ import annotations

from typing import Any

from .architecture_policy import check_architecture_policy
from .behavior_fixtures import validate_behavior_fixtures_against_api
from .canonical import digest_object
from .compatibility import project_grammar_matrix
from .engineering import (
    affected_tests,
    api_passport,
    architecture_report,
    compare_api_passports,
)
from .migrations import dependency_migration_plan
from .risk import change_risk_passport
from .test_priority import prioritize_affected_tests


def build_change_passport(
    *,
    before_files: list[dict[str, str]],
    after_files: list[dict[str, str]],
    target_python: str,
    package: str | None,
    before_dependencies: list[str],
    after_dependencies: list[str],
    changed_paths: list[str],
    architecture_policy: dict[str, Any] | None = None,
    behavior_fixtures: dict[str, Any] | None = None,
    sandbox_test_evidence: dict[str, Any] | None = None,
    static_adapter_evidence: dict[str, Any] | None = None,
) -> dict[str, Any]:
    before_api = api_passport(before_files, target_python)
    after_api = api_passport(after_files, target_python)
    api_diff = compare_api_passports(before_api, after_api)

    risk = change_risk_passport(
        before_files, after_files, target_python,
        changed_paths, package,
    )
    affected = affected_tests(
        before_files, target_python, changed_paths, package
    )
    priority = prioritize_affected_tests(
        before_files, target_python, changed_paths, package
    )
    migration = dependency_migration_plan(
        before_dependencies,
        after_dependencies,
        affected["affected_test_paths"],
    )
    before_arch = architecture_report(
        before_files, target_python, package
    )
    after_arch = architecture_report(
        after_files, target_python, package
    )
    grammar = project_grammar_matrix(
        [x for x in after_files if x["path"].endswith(".py")]
    )

    policy_result = None
    if architecture_policy is not None:
        policy_result = check_architecture_policy(
            after_files, target_python,
            architecture_policy, package,
        )

    behavior_result = None
    if behavior_fixtures is not None:
        behavior_result = validate_behavior_fixtures_against_api(
            behavior_fixtures, after_files, target_python
        )

    gaps = []
    if sandbox_test_evidence is None:
        gaps.append("NO_SANDBOX_TEST_EVIDENCE")
    elif not sandbox_test_evidence.get("test_execution", False):
        gaps.append("SANDBOX_TESTS_NOT_EXECUTED")
    elif sandbox_test_evidence.get("result") != "PASS":
        gaps.append("SANDBOX_TESTS_NOT_PASSING")

    if static_adapter_evidence is None:
        gaps.append("NO_EXTERNAL_STATIC_ADAPTER_EVIDENCE")

    if behavior_fixtures is not None:
        if behavior_result and behavior_result["status"] != "PASS":
            gaps.append("BEHAVIOR_FIXTURE_TARGETS_BROKEN")
        if (
            sandbox_test_evidence is None
            or not sandbox_test_evidence.get("test_execution", False)
        ):
            gaps.append("BEHAVIOR_FIXTURES_NOT_EXECUTED")

    if policy_result is not None and policy_result["status"] != "PASS":
        gaps.append("ARCHITECTURE_POLICY_VIOLATIONS")

    if api_diff["compatibility"] == "BREAKING_OR_CHANGED":
        gaps.append("PUBLIC_API_BREAK_OR_CHANGE")

    if risk["level"] in {"HIGH", "VERY_HIGH"}:
        gaps.append("HIGH_STATIC_CHANGE_RISK")

    evidence_grade = "STATIC_ONLY"
    if static_adapter_evidence is not None:
        evidence_grade = "STATIC_PLUS_ADAPTERS"
    if (
        sandbox_test_evidence is not None
        and sandbox_test_evidence.get("test_execution", False)
        and sandbox_test_evidence.get("result") == "PASS"
    ):
        evidence_grade = (
            "STATIC_ADAPTERS_SANDBOX"
            if static_adapter_evidence is not None
            else "STATIC_PLUS_SANDBOX"
        )

    core = {
        "schema": "axm.python-change-passport.v1",
        "target_python": target_python,
        "package": package,
        "changed_paths": sorted(set(changed_paths)),
        "api": {
            "before_digest": before_api["project_api_digest"],
            "after_digest": after_api["project_api_digest"],
            "compatibility": api_diff,
        },
        "risk": {
            "score": risk["score"],
            "level": risk["level"],
            "passport_digest": risk["passport_digest"],
        },
        "affected_tests": affected,
        "test_priority": priority,
        "dependency_migration": migration,
        "architecture": {
            "before_digest": before_arch["architecture_digest"],
            "after_digest": after_arch["architecture_digest"],
            "cycles_before": before_arch["cycles"],
            "cycles_after": after_arch["cycles"],
        },
        "minimum_tracked_grammar": grammar["project_minimum_tracked_grammar"],
        "architecture_policy": policy_result,
        "behavior_fixture_validation": behavior_result,
        "static_adapter_evidence": static_adapter_evidence,
        "sandbox_test_evidence": sandbox_test_evidence,
        "evidence_grade": evidence_grade,
        "evidence_gaps": sorted(set(gaps)),
        "governance_status": (
            "EVIDENCE_WITH_HOLDS"
            if gaps else "EVIDENCE_COMPLETE_FOR_GOVERNANCE_REVIEW"
        ),
        "automatic_release": False,
        "automatic_merge": False,
        "automatic_promotion": False,
        "automatic_canon": False,
        "truth_boundary": (
            "A complete passport means the requested evidence fields are present, "
            "not that release/merge is approved. Governance remains external."
        ),
    }
    passport = dict(core)
    passport["passport_digest"] = digest_object(core)
    return passport
