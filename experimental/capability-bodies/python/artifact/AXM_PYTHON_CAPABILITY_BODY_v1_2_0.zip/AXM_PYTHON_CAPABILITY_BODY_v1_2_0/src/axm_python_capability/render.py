from __future__ import annotations

from typing import Any

from .contracts import require_identifier
from .errors import ContractError


def text(value: Any, label: str) -> str:
    if not isinstance(value, str):
        raise ContractError(f"{label} must be a string")
    return value


def safe_doc(value: Any) -> str:
    return str(value).replace('"""', "")


def render_import(item: Any) -> str:
    if isinstance(item, str):
        item = item.strip()
        if not item:
            raise ContractError("import cannot be empty")
        return item

    if not isinstance(item, dict):
        raise ContractError("import must be string or object")

    module = text(item.get("module"), "import.module").strip()
    names = item.get("names")
    alias = item.get("alias")

    if names is None:
        return f"import {module}" + (f" as {alias}" if alias else "")

    if not isinstance(names, list) or not names:
        raise ContractError("import.names must be a non-empty list")

    rendered = []
    for entry in names:
        if isinstance(entry, str):
            rendered.append(entry)
        elif isinstance(entry, dict):
            name = text(entry.get("name"), "import.names.name")
            name_alias = entry.get("alias")
            rendered.append(f"{name} as {name_alias}" if name_alias else name)
        else:
            raise ContractError("invalid import.names item")

    return f"from {module} import " + ", ".join(sorted(rendered))


def body_lines(component: dict[str, Any], label: str) -> list[str]:
    body = component.get("body", ["pass"])
    if not isinstance(body, list) or not body:
        raise ContractError(f"{label}.body must be a non-empty list")
    out = []
    for i, line in enumerate(body):
        if not isinstance(line, str):
            raise ContractError(f"{label}.body[{i}] must be a string")
        if "\x00" in line:
            raise ContractError(f"{label}.body[{i}] contains NUL")
        out.append(line)
    return out


def render_constant(c: dict[str, Any], label: str) -> list[str]:
    name = require_identifier(c.get("name"), f"{label}.name")
    value = text(c.get("value"), f"{label}.value")
    annotation = c.get("annotation")
    left = name + (f": {annotation}" if annotation else "")
    return [f"{left} = {value}"]


def render_exception(c: dict[str, Any], label: str) -> list[str]:
    name = require_identifier(c.get("name"), f"{label}.name")
    base = text(c.get("base", "Exception"), f"{label}.base")
    lines = [f"class {name}({base}):"]
    if c.get("doc"):
        lines.append(f'    """{safe_doc(c["doc"])}"""')
    else:
        lines.append("    pass")
    return lines


def render_dataclass(c: dict[str, Any], label: str) -> list[str]:
    name = require_identifier(c.get("name"), f"{label}.name")
    args = []
    if c.get("frozen", True):
        args.append("frozen=True")
    if c.get("slots", True):
        args.append("slots=True")
    lines = [f"@dataclass({', '.join(args)})" if args else "@dataclass", f"class {name}:"]

    if c.get("doc"):
        lines.append(f'    """{safe_doc(c["doc"])}"""')

    fields = c.get("fields", [])
    if not isinstance(fields, list):
        raise ContractError(f"{label}.fields must be a list")
    if not fields and not c.get("doc"):
        lines.append("    pass")

    for i, field in enumerate(fields):
        if not isinstance(field, dict):
            raise ContractError(f"{label}.fields[{i}] must be an object")
        fname = require_identifier(field.get("name"), f"{label}.fields[{i}].name")
        ftype = text(field.get("type", "object"), f"{label}.fields[{i}].type")
        if "default" in field:
            default = text(field["default"], f"{label}.fields[{i}].default")
            lines.append(f"    {fname}: {ftype} = {default}")
        else:
            lines.append(f"    {fname}: {ftype}")
    return lines


def render_function(c: dict[str, Any], label: str, indent: str = "") -> list[str]:
    name = require_identifier(c.get("name"), f"{label}.name")
    args = c.get("args", [])
    if not isinstance(args, list):
        raise ContractError(f"{label}.args must be a list")

    rendered_args = []
    for i, arg in enumerate(args):
        if not isinstance(arg, dict):
            raise ContractError(f"{label}.args[{i}] must be an object")
        aname = require_identifier(arg.get("name"), f"{label}.args[{i}].name")
        part = aname
        if arg.get("type"):
            part += f": {arg['type']}"
        if "default" in arg:
            part += f" = {arg['default']}"
        rendered_args.append(part)

    async_prefix = "async " if c.get("async", False) else ""
    signature = f"{indent}{async_prefix}def {name}({', '.join(rendered_args)})"
    if c.get("returns"):
        signature += f" -> {c['returns']}"
    signature += ":"

    lines = [signature]
    if c.get("doc"):
        lines.append(f'{indent}    """{safe_doc(c["doc"])}"""')
    for line in body_lines(c, label):
        lines.append(indent + "    " + line)
    return lines


def render_class(c: dict[str, Any], label: str) -> list[str]:
    name = require_identifier(c.get("name"), f"{label}.name")
    bases = c.get("bases", [])
    if not isinstance(bases, list):
        raise ContractError(f"{label}.bases must be a list")
    header = f"class {name}" + (f"({', '.join(str(x) for x in bases)})" if bases else "") + ":"
    lines = [header]

    if c.get("doc"):
        lines.append(f'    """{safe_doc(c["doc"])}"""')

    methods = c.get("methods", [])
    if not isinstance(methods, list):
        raise ContractError(f"{label}.methods must be a list")
    if not methods and not c.get("doc"):
        lines.append("    pass")

    for i, method in enumerate(methods):
        if not isinstance(method, dict):
            raise ContractError(f"{label}.methods[{i}] must be an object")
        lines.append("")
        lines.extend(render_function(method, f"{label}.methods[{i}]", indent="    "))
    return lines


RENDERERS = {
    "constant": render_constant,
    "exception": render_exception,
    "dataclass": render_dataclass,
    "function": render_function,
    "class": render_class,
}


def render_module(module: dict[str, Any]) -> str:
    name = require_identifier(module.get("name"), "module.name")
    chunks = [f'"""{safe_doc(module.get("doc", f"Generated module: {name}"))}"""']

    imports = module.get("imports", [])
    if not isinstance(imports, list):
        raise ContractError("module.imports must be a list")

    rendered_imports = {render_import(item) for item in imports}
    components = module.get("components", [])
    if not isinstance(components, list):
        raise ContractError("module.components must be a list")

    if any(isinstance(c, dict) and c.get("type") == "dataclass" for c in components):
        rendered_imports.add("from dataclasses import dataclass")

    if rendered_imports:
        chunks.append("\n".join(sorted(rendered_imports)))

    for i, component in enumerate(components):
        if not isinstance(component, dict):
            raise ContractError(f"module.components[{i}] must be an object")
        ctype = component.get("type")
        renderer = RENDERERS.get(ctype)
        if renderer is None:
            raise ContractError(
                f"unsupported component type {ctype!r}; allowed={','.join(sorted(RENDERERS))}"
            )
        chunks.append("\n".join(renderer(component, f"component[{i}]")))

    return "\n\n\n".join(chunks).rstrip() + "\n"
