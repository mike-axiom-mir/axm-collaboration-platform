from __future__ import annotations

import re
from typing import Any

from .canonical import digest_object


_DEP_RE = re.compile(
    r"^\s*([A-Za-z0-9_.-]+)"
    r"(\[[^\]]+\])?"
    r"\s*(.*?)\s*$"
)


def dependency_record(raw: str) -> dict[str, str | None]:
    # Deterministic lexical split, not a full PEP 508 parser.
    marker = None
    requirement = raw
    if ";" in raw:
        requirement, marker = raw.split(";", 1)
        marker = marker.strip() or None

    match = _DEP_RE.match(requirement)
    if not match:
        return {
            "raw": raw,
            "name": raw.strip().lower().replace("_", "-"),
            "extras": None,
            "specifier": None,
            "marker": marker,
        }

    name, extras, specifier = match.groups()
    return {
        "raw": raw,
        "name": name.lower().replace("_", "-"),
        "extras": extras,
        "specifier": specifier.strip() or None,
        "marker": marker,
    }


def dependency_map(values: list[str]) -> dict[str, dict[str, Any]]:
    out = {}
    for raw in sorted(set(values)):
        record = dependency_record(raw)
        out[str(record["name"])] = record
    return out


def dependency_migration_plan(
    before_dependencies: list[str],
    after_dependencies: list[str],
    affected_test_paths: list[str] | None = None,
) -> dict[str, Any]:
    before = dependency_map(before_dependencies)
    after = dependency_map(after_dependencies)

    added = sorted(set(after) - set(before))
    removed = sorted(set(before) - set(after))
    changed = sorted(
        name for name in set(before) & set(after)
        if before[name] != after[name]
    )

    steps = []
    for name in removed:
        steps.append({
            "kind": "REMOVE_DEPENDENCY",
            "dependency": name,
            "before": before[name],
            "verification": ["scan_imports", "static_analysis", "affected_tests"],
        })
    for name in changed:
        steps.append({
            "kind": "CHANGE_DEPENDENCY_CONSTRAINT",
            "dependency": name,
            "before": before[name],
            "after": after[name],
            "verification": ["static_analysis", "api_compatibility", "affected_tests"],
        })
    for name in added:
        steps.append({
            "kind": "ADD_DEPENDENCY",
            "dependency": name,
            "after": after[name],
            "verification": ["static_analysis", "dependency_policy", "affected_tests"],
        })

    return {
        "schema": "axm.python-dependency-migration-plan.v1",
        "added": added,
        "removed": removed,
        "changed": changed,
        "steps": steps,
        "affected_test_paths": sorted(set(affected_test_paths or [])),
        "automatic_install": False,
        "network_required_by_planner": False,
        "plan_digest": digest_object({
            "before": before,
            "after": after,
            "steps": steps,
            "tests": sorted(set(affected_test_paths or [])),
        }),
        "truth_boundary": (
            "Dependency strings are lexically normalized; this planner does not "
            "claim full PEP 508 resolution or package-index compatibility."
        ),
    }
