from __future__ import annotations

import ast
import hashlib
from collections import defaultdict, deque
from typing import Any

from .analyze import parse_source
from .canonical import digest_object
from .project_graph import module_name_from_path
from .reference_index import build_reference_index


def _source_segment_digest(source: str, node: ast.AST) -> str:
    segment = ast.get_source_segment(source, node) or ""
    return "sha256:" + hashlib.sha256(segment.encode("utf-8")).hexdigest()


def symbol_snapshot(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
) -> dict[str, Any]:
    symbols = {}
    for item in sorted(files, key=lambda x: x["path"]):
        if not item["path"].endswith(".py"):
            continue
        module = module_name_from_path(item["path"], package)
        tree = parse_source(item["source"], item["path"], target_python)
        if not isinstance(tree, ast.Module):
            continue
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                symbol = f"{module}.{node.name}"
                symbols[symbol] = {
                    "path": item["path"],
                    "line": node.lineno,
                    "kind": type(node).__name__,
                    "digest": _source_segment_digest(item["source"], node),
                }
    core = {
        "schema": "axm.python-symbol-snapshot.v1",
        "symbols": dict(sorted(symbols.items())),
    }
    result = dict(core)
    result["snapshot_digest"] = digest_object(core)
    return result


def fine_grained_invalidation(
    *,
    before_files: list[dict[str, str]],
    after_files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
) -> dict[str, Any]:
    before = symbol_snapshot(before_files, target_python, package)
    after = symbol_snapshot(after_files, target_python, package)

    b = before["symbols"]
    a = after["symbols"]
    changed = sorted(
        symbol
        for symbol in set(b) & set(a)
        if b[symbol]["digest"] != a[symbol]["digest"]
    )
    added = sorted(set(a) - set(b))
    removed = sorted(set(b) - set(a))

    # Build a conservative symbol dependency graph from static references in
    # the BEFORE tree. A reference from module/function scope to a target symbol
    # creates an invalidation edge target -> referencing owner.
    refs = build_reference_index(
        before_files, target_python, package
    )
    dependencies: dict[str, set[str]] = defaultdict(set)

    for ref in refs["references"]:
        target = ref.get("target")
        if not target or not ref["resolution"].startswith("RESOLVED_"):
            continue

        owner = ref["module"]
        # When the referencing location is inside a top-level function/class,
        # choose the smallest top-level definition containing that line.
        candidates = [
            definition
            for definition in refs["definitions"]
            if definition["path"] == ref["path"]
            and definition["line"] <= (ref["line"] or 0)
        ]
        if candidates:
            # Static approximation: nearest prior top-level definition.
            owner = sorted(
                candidates,
                key=lambda x: x["line"],
            )[-1]["symbol"]

        if owner != target:
            dependencies[target].add(owner)

    seeds = sorted(set(changed + removed))
    impacted = set(seeds)
    queue = deque(seeds)
    while queue:
        current = queue.popleft()
        for dependent in sorted(dependencies.get(current, set())):
            if dependent not in impacted:
                impacted.add(dependent)
                queue.append(dependent)

    core = {
        "schema": "axm.python-fine-grained-invalidation.v1",
        "before_snapshot": before["snapshot_digest"],
        "after_snapshot": after["snapshot_digest"],
        "changed_symbols": changed,
        "added_symbols": added,
        "removed_symbols": removed,
        "invalidated_symbols": sorted(impacted),
        "dependency_edges": [
            {
                "source_symbol": source,
                "dependent_symbols": sorted(dependents),
            }
            for source, dependents in sorted(dependencies.items())
        ],
        "truth_boundary": (
            "Symbol invalidation is static and conservative. Dynamic imports, "
            "monkey patching, reflection, decorators and hidden framework edges "
            "can require broader invalidation."
        ),
    }
    result = dict(core)
    result["invalidation_digest"] = digest_object(core)
    return result
