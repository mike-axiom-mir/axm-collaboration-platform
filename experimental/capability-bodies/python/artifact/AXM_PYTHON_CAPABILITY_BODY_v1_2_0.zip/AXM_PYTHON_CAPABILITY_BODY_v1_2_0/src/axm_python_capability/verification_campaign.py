from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from .canonical import digest_object
from .fault_campaign import run_fault_campaign
from .maturity import build_maturity_passport
from .reference_blueprint import build_reference_blueprint
from .reproducibility import (
    module_build_reproducibility,
    patch_reproducibility,
    project_build_reproducibility,
)
from .scale_probe import run_scale_probe
from .self_audit import audit_package
from .verification_corpus import run_corpus


def run_verification_campaign(
    *,
    package_root: str | Path,
    module_request: dict[str, Any],
    project_request: dict[str, Any],
    patch_request: dict[str, Any],
    scale_modules: int = 500,
) -> dict[str, Any]:
    root = Path(package_root).resolve()
    target_python = f"{sys.version_info.major}.{sys.version_info.minor}"

    baseline = json.loads(
        (root / "REFERENCE_BASELINE_v1_0.json").read_text(encoding="utf-8")
    )
    blueprint = build_reference_blueprint()
    reference_stable = (
        blueprint["blueprint_digest"]
        == baseline["reference_blueprint_digest"]
    )

    self_audit = audit_package(root)
    corpus = run_corpus(target_python)
    module_repro = module_build_reproducibility(module_request, runs=3)
    project_repro = project_build_reproducibility(project_request, runs=3)
    patch_repro = patch_reproducibility(patch_request, runs=5)
    scale = run_scale_probe(
        count=scale_modules,
        target_python=target_python,
        package="scale",
        shard_max_files=100,
    )
    faults = run_fault_campaign(target_python)

    checks = {
        "reference_blueprint_stable": reference_stable,
        "self_audit": self_audit["status"] == "PASS",
        "syntax_corpus": corpus["status"] == "PASS",
        "module_reproducibility": module_repro["status"] == "PASS",
        "project_reproducibility": project_repro["status"] == "PASS",
        "patch_reproducibility": patch_repro["status"] == "PASS",
        "scale_probe": scale["status"] == "PASS",
        "fault_campaign": faults["status"] == "PASS",
    }
    failed = sorted(key for key, passed in checks.items() if not passed)

    manifest = json.loads(
        (root / "manifest.json").read_text(encoding="utf-8")
    )
    maturity = build_maturity_passport(
        self_audit=self_audit,
        test_count=0,
        feature_count=len(manifest.get("features", [])),
        schema_count=len(list((root / "schemas").glob("*.json"))),
        known_truth_boundaries=[
            "verification campaign is functional evidence, not deployment approval",
            "scale probe is not a wall-clock SLA",
        ],
    )

    core = {
        "schema": "axm.python-verification-campaign.v1",
        "host_python": target_python,
        "reference_baseline": baseline,
        "reference_blueprint_current": blueprint["blueprint_digest"],
        "checks": checks,
        "failed_checks": failed,
        "self_audit": self_audit,
        "syntax_corpus": corpus,
        "module_reproducibility": module_repro,
        "project_reproducibility": project_repro,
        "patch_reproducibility": patch_repro,
        "scale_probe": scale,
        "fault_campaign": faults,
        "maturity": maturity,
        "status": "PASS" if not failed else "FAIL",
        "automatic_promotion": False,
        "automatic_canon": False,
    }
    result = dict(core)
    result["campaign_digest"] = digest_object(core)
    return result
