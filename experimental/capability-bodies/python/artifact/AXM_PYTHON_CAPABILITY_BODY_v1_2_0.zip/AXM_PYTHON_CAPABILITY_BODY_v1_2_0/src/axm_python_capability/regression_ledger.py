from __future__ import annotations

from typing import Any

from .canonical import digest_object
from .errors import ContractError


GENESIS = "GENESIS"


def append_regression_record(
    ledger: dict[str, Any] | None,
    record: dict[str, Any],
) -> dict[str, Any]:
    if ledger is None:
        entries = []
    else:
        verify_regression_ledger(ledger)
        entries = list(ledger["entries"])

    previous = entries[-1]["entry_digest"] if entries else GENESIS
    core = {
        "index": len(entries),
        "previous": previous,
        "record": record,
    }
    entry = dict(core)
    entry["entry_digest"] = digest_object(core)
    entries.append(entry)

    ledger_core = {
        "schema": "axm.python-regression-ledger.v1",
        "entries": entries,
        "entry_count": len(entries),
        "head": entries[-1]["entry_digest"],
    }
    result = dict(ledger_core)
    result["ledger_digest"] = digest_object(ledger_core)
    return result


def verify_regression_ledger(ledger: dict[str, Any]) -> None:
    if not isinstance(ledger, dict):
        raise ContractError("LEDGER_NOT_OBJECT")
    supplied = ledger.get("ledger_digest")
    core = dict(ledger)
    core.pop("ledger_digest", None)
    if digest_object(core) != supplied:
        raise ContractError("LEDGER_DIGEST_MISMATCH")

    entries = ledger.get("entries", [])
    previous = GENESIS
    for expected_index, entry in enumerate(entries):
        if entry.get("index") != expected_index:
            raise ContractError("LEDGER_INDEX_MISMATCH")
        if entry.get("previous") != previous:
            raise ContractError("LEDGER_CHAIN_MISMATCH")
        supplied_entry = entry.get("entry_digest")
        entry_core = dict(entry)
        entry_core.pop("entry_digest", None)
        if digest_object(entry_core) != supplied_entry:
            raise ContractError("LEDGER_ENTRY_DIGEST_MISMATCH")
        previous = supplied_entry

    if ledger.get("head") != previous:
        raise ContractError("LEDGER_HEAD_MISMATCH")
