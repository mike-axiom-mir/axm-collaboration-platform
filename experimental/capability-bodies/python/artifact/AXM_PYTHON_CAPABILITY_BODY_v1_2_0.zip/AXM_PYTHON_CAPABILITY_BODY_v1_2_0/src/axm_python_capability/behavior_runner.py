from __future__ import annotations

import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any

from .authority import evaluate_authority
from .behavior_fixtures import normalize_behavior_fixtures
from .canonical import digest_object, stable_id
from .constants import CAPABILITY_ID, CAPABILITY_VERSION
from .errors import AuthorityError, ContractError
from .project_graph import module_name_from_path
from .sandbox import sandbox_doctor
from .sandbox_tests import _bubblewrap_command, _bounded_run, _copy_shadow, _tree


def generate_behavior_unittest_source(
    fixture_set: dict[str, Any],
    *,
    package: str | None,
) -> str:
    normalized = normalize_behavior_fixtures(fixture_set)
    lines = [
        "import importlib",
        "import unittest",
        "",
        "class AXMBehaviorFixtures(unittest.TestCase):",
    ]

    for index, fixture in enumerate(normalized["fixtures"], start=1):
        target = fixture["target"]
        if "::" not in target:
            raise ContractError(
                f"behavior target must be path::symbol: {target}"
            )
        path, symbol = target.split("::", 1)
        module = module_name_from_path(path, package)
        if not module or not symbol.isidentifier():
            raise ContractError(f"unsupported behavior target: {target}")

        lines += [
            f"    def test_fixture_{index:04d}(self):",
            f"        module = importlib.import_module({module!r})",
            f"        target = getattr(module, {symbol!r})",
            f"        args = {fixture['args']!r}",
            f"        kwargs = {fixture['kwargs']!r}",
        ]
        if "expected_return" in fixture:
            lines += [
                "        result = target(*args, **kwargs)",
                f"        self.assertEqual(result, {fixture['expected_return']!r})",
            ]
        else:
            lines += [
                f"        expected_name = {fixture['expected_exception']!r}",
                "        try:",
                "            target(*args, **kwargs)",
                "        except Exception as exc:",
                "            self.assertEqual(type(exc).__name__, expected_name)",
                "        else:",
                "            self.fail(f'Expected exception {expected_name}')",
            ]
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def behavior_fixture_execution_plan(
    *,
    fixture_set: dict[str, Any],
    package: str | None,
    authorities: list[str],
) -> dict[str, Any]:
    decision = evaluate_authority(authorities)
    if "RUN_SANDBOX_TESTS" not in decision.effective:
        raise AuthorityError("RUN_SANDBOX_TESTS_REQUIRED")

    normalized = normalize_behavior_fixtures(fixture_set)
    source = generate_behavior_unittest_source(
        normalized, package=package
    )
    doctor = sandbox_doctor()

    core = {
        "schema": "axm.python-behavior-execution-plan.v1",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "fixture_set_digest": normalized["fixture_set_digest"],
        "generated_test_source": source,
        "generated_test_source_digest": digest_object({
            "source": source
        }),
        "sandbox_doctor": doctor,
        "execution_authorized": bool(
            doctor["generated_test_execution_available"]
        ),
        "status": (
            "READY_FOR_HARD_SANDBOX"
            if doctor["generated_test_execution_available"]
            else "HOLD_NO_VERIFIED_HARD_SANDBOX"
        ),
        "host_execution_fallback": False,
    }
    plan = dict(core)
    plan["plan_digest"] = digest_object(core)
    return plan


def run_behavior_fixtures_sandboxed(
    *,
    project_root: str | Path,
    fixture_set: dict[str, Any],
    package: str | None,
    authorities: list[str],
    policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    decision = evaluate_authority(authorities)
    if "RUN_SANDBOX_TESTS" not in decision.effective:
        raise AuthorityError("RUN_SANDBOX_TESTS_REQUIRED")

    root = Path(project_root).expanduser().resolve()
    if not root.is_dir():
        raise ContractError("project_root must be a directory")

    normalized = normalize_behavior_fixtures(fixture_set)
    generated_source = generate_behavior_unittest_source(
        normalized, package=package
    )
    doctor = sandbox_doctor()
    before_digest = digest_object(_tree(root))

    run_id = stable_id(
        "pybehavior",
        {
            "capability": CAPABILITY_ID,
            "version": CAPABILITY_VERSION,
            "project_digest": before_digest,
            "fixture_set_digest": normalized["fixture_set_digest"],
            "package": package,
        },
    )

    hard = [
        provider
        for provider in doctor["providers"]
        if provider.get("hard_test_ready")
    ]
    if not hard:
        core = {
            "schema": "axm.python-behavior-execution-receipt.v1",
            "capability_id": CAPABILITY_ID,
            "capability_version": CAPABILITY_VERSION,
            "run_id": run_id,
            "project_digest": before_digest,
            "fixture_set_digest": normalized["fixture_set_digest"],
            "sandbox_doctor": doctor,
            "fixtures_executed": False,
            "result": "HOLD_NO_VERIFIED_HARD_SANDBOX",
            "host_execution_fallback": False,
            "network_authorized": False,
            "packages_installed": False,
            "status": "DETACHED_HOLD",
        }
        receipt = dict(core)
        receipt["receipt_digest"] = digest_object(core)
        return receipt

    provider = hard[0]
    if provider["provider_id"] != "bubblewrap":
        raise ContractError("NO_IMPLEMENTED_HARD_BEHAVIOR_PROVIDER")

    policy = policy or {}
    timeout = float(policy.get("timeout_seconds", 30))
    max_output_bytes = int(policy.get("max_output_bytes", 512_000))
    cpu_seconds = int(policy.get("cpu_seconds", 20))
    memory_bytes = int(policy.get("memory_bytes", 512 * 1024 * 1024))
    file_bytes = int(policy.get("file_bytes", 32 * 1024 * 1024))
    processes = int(policy.get("processes", 32))

    with tempfile.TemporaryDirectory(prefix="axm-python-behavior-") as tmp:
        shadow = Path(tmp) / "project"
        _copy_shadow(root, shadow)
        generated_path = shadow / "test_axm_behavior_fixtures.py"
        generated_path.write_text(
            generated_source,
            encoding="utf-8",
            newline="\n",
        )

        test_command = [
            sys.executable,
            "-B",
            "-m",
            "unittest",
            "discover",
            "-v",
            "-p",
            "test_axm_behavior_fixtures.py",
        ]
        command = _bubblewrap_command(
            provider["executable"],
            shadow,
            test_command,
        )
        env = {
            "PATH": __import__("os").environ.get("PATH", ""),
            "LANG": __import__("os").environ.get("LANG", "C.UTF-8"),
            "LC_ALL": __import__("os").environ.get("LC_ALL", "C.UTF-8"),
            "PYTHONDONTWRITEBYTECODE": "1",
        }
        run = _bounded_run(
            command,
            cwd=shadow,
            env=env,
            timeout=timeout,
            max_output_bytes=max_output_bytes,
            cpu_seconds=cpu_seconds,
            memory_bytes=memory_bytes,
            file_bytes=file_bytes,
            processes=processes,
        )
        shadow_digest = digest_object(_tree(shadow))

    after_digest = digest_object(_tree(root))
    source_unchanged = before_digest == after_digest

    if run["timed_out"]:
        result = "TIMEOUT"
    elif run["output_limit_exceeded"]:
        result = "OUTPUT_LIMIT"
    elif run["returncode"] == 0:
        result = "PASS"
    else:
        result = "BEHAVIOR_FIXTURE_FAILURE"

    core = {
        "schema": "axm.python-behavior-execution-receipt.v1",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "run_id": run_id,
        "project_before_digest": before_digest,
        "project_after_digest": after_digest,
        "source_unchanged": source_unchanged,
        "fixture_set_digest": normalized["fixture_set_digest"],
        "generated_test_source_digest": digest_object({
            "source": generated_source
        }),
        "provider": provider,
        "sandbox_doctor": doctor,
        "fixtures_executed": True,
        "result": result,
        "returncode": run["returncode"],
        "stdout": run["stdout"],
        "stderr": run["stderr"],
        "timed_out": run["timed_out"],
        "output_limit_exceeded": run["output_limit_exceeded"],
        "duration_ms": run["duration_ms"],
        "shadow_digest_after_execution": shadow_digest,
        "host_execution_fallback": False,
        "network_authorized": False,
        "resource_limits": {
            "timeout_seconds": timeout,
            "max_output_bytes": max_output_bytes,
            "cpu_seconds": cpu_seconds,
            "memory_bytes": memory_bytes,
            "file_bytes": file_bytes,
            "processes": processes,
        },
        "packages_installed": False,
        "status": "DETACHED_BEHAVIOR_EVIDENCE",
    }
    receipt = dict(core)
    receipt["receipt_digest"] = digest_object(core)
    return receipt
