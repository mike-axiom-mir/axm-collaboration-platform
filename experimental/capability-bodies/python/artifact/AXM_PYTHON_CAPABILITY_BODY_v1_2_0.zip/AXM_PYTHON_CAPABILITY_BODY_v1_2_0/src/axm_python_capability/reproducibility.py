from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any

from .builder import build_request
from .canonical import digest_object
from .patch import apply_patch_request
from .project_builder import build_project


def _json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def module_build_reproducibility(request: dict[str, Any], runs: int = 3) -> dict[str, Any]:
    if runs < 2:
        raise ValueError("runs must be >= 2")
    evidence = []
    for _ in range(runs):
        with tempfile.TemporaryDirectory() as d:
            result = build_request(request, d)
            evidence.append({
                "run_id": result.run_id,
                "manifest": _json(result.manifest_path),
                "receipt": result.receipt,
            })

    baseline = evidence[0]
    identical = all(item == baseline for item in evidence[1:])
    core = {
        "schema": "axm.python-module-reproducibility.v1",
        "runs": runs,
        "identical": identical,
        "run_ids": [x["run_id"] for x in evidence],
        "manifest_digests": [
            digest_object(x["manifest"]) for x in evidence
        ],
        "receipt_digests": [
            x["receipt"]["receipt_digest"] for x in evidence
        ],
        "status": "PASS" if identical else "FAIL",
    }
    result = dict(core)
    result["probe_digest"] = digest_object(core)
    return result


def project_build_reproducibility(request: dict[str, Any], runs: int = 3) -> dict[str, Any]:
    if runs < 2:
        raise ValueError("runs must be >= 2")
    evidence = []
    for _ in range(runs):
        with tempfile.TemporaryDirectory() as d:
            result = build_project(request, d)
            evidence.append({
                "run_id": result["run_id"],
                "manifest": result["manifest"],
                "receipt": result["receipt"],
            })

    baseline = evidence[0]
    identical = all(item == baseline for item in evidence[1:])
    core = {
        "schema": "axm.python-project-reproducibility.v1",
        "runs": runs,
        "identical": identical,
        "run_ids": [x["run_id"] for x in evidence],
        "manifest_digests": [
            digest_object(x["manifest"]) for x in evidence
        ],
        "receipt_digests": [
            x["receipt"]["receipt_digest"] for x in evidence
        ],
        "status": "PASS" if identical else "FAIL",
    }
    result = dict(core)
    result["probe_digest"] = digest_object(core)
    return result


def patch_reproducibility(request: dict[str, Any], runs: int = 5) -> dict[str, Any]:
    if runs < 2:
        raise ValueError("runs must be >= 2")
    evidence = [apply_patch_request(request) for _ in range(runs)]
    baseline = evidence[0]
    identical = all(item == baseline for item in evidence[1:])
    core = {
        "schema": "axm.python-patch-reproducibility.v1",
        "runs": runs,
        "identical": identical,
        "run_ids": [x["run_id"] for x in evidence],
        "receipt_digests": [
            x["receipt"]["receipt_digest"] for x in evidence
        ],
        "status": "PASS" if identical else "FAIL",
    }
    result = dict(core)
    result["probe_digest"] = digest_object(core)
    return result
