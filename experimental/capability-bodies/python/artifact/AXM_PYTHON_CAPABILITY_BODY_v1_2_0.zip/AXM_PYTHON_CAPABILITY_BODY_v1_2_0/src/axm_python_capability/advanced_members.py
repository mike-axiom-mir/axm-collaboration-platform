from __future__ import annotations

import ast
from typing import Any

from .analyze import parse_source, safe_unparse
from .canonical import digest_object
from .project_graph import module_name_from_path


def _decorator_names(node: ast.FunctionDef | ast.AsyncFunctionDef) -> list[str]:
    return [safe_unparse(x) or "" for x in node.decorator_list]


def advanced_member_flow(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
) -> dict[str, Any]:
    classes: dict[str, dict[str, Any]] = {}

    for item in sorted(files, key=lambda x: x["path"]):
        if not item["path"].endswith(".py"):
            continue
        module = module_name_from_path(item["path"], package)
        tree = parse_source(item["source"], item["path"], target_python)
        if not isinstance(tree, ast.Module):
            continue

        for node in tree.body:
            if not isinstance(node, ast.ClassDef):
                continue
            symbol = f"{module}.{node.name}"
            methods = {}
            properties: dict[str, dict[str, Any]] = {}
            constructor_assignments = []

            for child in node.body:
                if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                decorators = _decorator_names(child)
                method_kind = "INSTANCE"
                if "classmethod" in decorators:
                    method_kind = "CLASSMETHOD"
                elif "staticmethod" in decorators:
                    method_kind = "STATICMETHOD"

                property_name = None
                property_role = None
                if "property" in decorators:
                    property_name = child.name
                    property_role = "GETTER"
                else:
                    for deco in decorators:
                        if deco.endswith(".setter"):
                            property_name = deco.rsplit(".", 1)[0]
                            property_role = "SETTER"
                        elif deco.endswith(".deleter"):
                            property_name = deco.rsplit(".", 1)[0]
                            property_role = "DELETER"

                methods[child.name] = {
                    "symbol": f"{symbol}.{child.name}",
                    "kind": method_kind,
                    "line": child.lineno,
                    "decorators": decorators,
                    "returns": safe_unparse(child.returns),
                }

                if property_name:
                    properties.setdefault(property_name, {
                        "name": property_name,
                        "getter": None,
                        "setter": None,
                        "deleter": None,
                    })
                    properties[property_name][property_role.lower()] = methods[child.name]["symbol"]

                if child.name == "__init__":
                    parameters = {
                        arg.arg
                        for arg in (
                            list(child.args.posonlyargs)
                            + list(child.args.args)
                            + list(child.args.kwonlyargs)
                        )
                    }
                    for desc in ast.walk(child):
                        if not isinstance(desc, (ast.Assign, ast.AnnAssign)):
                            continue
                        targets = (
                            desc.targets
                            if isinstance(desc, ast.Assign)
                            else [desc.target]
                        )
                        value = desc.value
                        if not isinstance(value, ast.Name) or value.id not in parameters:
                            continue
                        for target in targets:
                            if (
                                isinstance(target, ast.Attribute)
                                and isinstance(target.value, ast.Name)
                                and target.value.id == "self"
                            ):
                                constructor_assignments.append({
                                    "attribute": target.attr,
                                    "parameter": value.id,
                                    "line": desc.lineno,
                                })

            bases = [safe_unparse(x) or "" for x in node.bases]
            is_protocol = any(
                base == "Protocol" or base.endswith(".Protocol")
                for base in bases
            )
            classes[symbol] = {
                "path": item["path"],
                "module": module,
                "name": node.name,
                "bases": bases,
                "methods": methods,
                "properties": sorted(
                    properties.values(),
                    key=lambda x: x["name"],
                ),
                "constructor_assignments": sorted(
                    constructor_assignments,
                    key=lambda x: (x["attribute"], x["parameter"], x["line"]),
                ),
                "is_protocol": is_protocol,
            }

    # Simple local base resolution.
    simple = {}
    for symbol in classes:
        simple.setdefault(symbol.rsplit(".", 1)[-1], []).append(symbol)

    inheritance = []
    super_calls = []
    overrides = []

    for symbol, info in sorted(classes.items()):
        local_bases = []
        for base_raw in info["bases"]:
            resolved = None
            if base_raw in classes:
                resolved = base_raw
            elif base_raw in simple and len(simple[base_raw]) == 1:
                resolved = simple[base_raw][0]
            inheritance.append({
                "class": symbol,
                "base_raw": base_raw,
                "resolved_base": resolved,
            })
            if resolved:
                local_bases.append(resolved)

        for base in local_bases:
            for method in sorted(set(info["methods"]) & set(classes[base]["methods"])):
                overrides.append({
                    "class": symbol,
                    "base": base,
                    "method": method,
                    "child_symbol": info["methods"][method]["symbol"],
                    "base_symbol": classes[base]["methods"][method]["symbol"],
                })

        # Re-parse class for super().method() calls.
        source = next(
            item["source"] for item in files
            if item["path"] == info["path"]
        )
        tree = parse_source(source, info["path"], target_python)
        class_node = next(
            n for n in tree.body
            if isinstance(n, ast.ClassDef) and n.name == info["name"]
        )
        for method in class_node.body:
            if not isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for desc in ast.walk(method):
                if not isinstance(desc, ast.Call):
                    continue
                func = desc.func
                if (
                    isinstance(func, ast.Attribute)
                    and isinstance(func.value, ast.Call)
                    and isinstance(func.value.func, ast.Name)
                    and func.value.func.id == "super"
                ):
                    candidates = [
                        classes[base]["methods"][func.attr]["symbol"]
                        for base in local_bases
                        if func.attr in classes[base]["methods"]
                    ]
                    super_calls.append({
                        "from": info["methods"][method.name]["symbol"],
                        "member": func.attr,
                        "targets": sorted(candidates),
                        "resolution": (
                            "RESOLVED_LOCAL_SUPER_METHOD"
                            if len(candidates) == 1
                            else "AMBIGUOUS_OR_EXTERNAL_SUPER_METHOD"
                        ),
                        "line": desc.lineno,
                    })

    # Structural Protocol candidate evidence.
    protocols = {}
    for symbol, info in classes.items():
        if info["is_protocol"]:
            required_methods = sorted(
                name for name in info["methods"]
                if not name.startswith("__")
            )
            required_properties = sorted(
                prop["name"] for prop in info["properties"]
            )
            protocols[symbol] = {
                "methods": required_methods,
                "properties": required_properties,
            }

    conformance = []
    for protocol, req in sorted(protocols.items()):
        for symbol, info in sorted(classes.items()):
            if symbol == protocol or info["is_protocol"]:
                continue
            available_methods = set(info["methods"])
            available_properties = {
                prop["name"] for prop in info["properties"]
            }
            missing_methods = sorted(set(req["methods"]) - available_methods)
            missing_properties = sorted(
                set(req["properties"]) - available_properties
            )
            conformance.append({
                "protocol": protocol,
                "class": symbol,
                "status": (
                    "STRUCTURAL_CANDIDATE"
                    if not missing_methods and not missing_properties
                    else "MISSING_MEMBERS"
                ),
                "missing_methods": missing_methods,
                "missing_properties": missing_properties,
            })

    result = {
        "schema": "axm.python-advanced-member-flow.v1",
        "classes": [
            {"symbol": symbol, **classes[symbol]}
            for symbol in sorted(classes)
        ],
        "inheritance": sorted(
            inheritance,
            key=lambda x: (x["class"], x["base_raw"]),
        ),
        "overrides": sorted(
            overrides,
            key=lambda x: (x["class"], x["method"], x["base"]),
        ),
        "super_calls": sorted(
            super_calls,
            key=lambda x: (x["from"], x["line"], x["member"]),
        ),
        "protocols": [
            {"symbol": symbol, **protocols[symbol]}
            for symbol in sorted(protocols)
        ],
        "protocol_conformance_candidates": sorted(
            conformance,
            key=lambda x: (x["protocol"], x["class"]),
        ),
        "truth_boundary": (
            "Structural member/protocol evidence is not runtime type checking. "
            "Descriptors, generic variance, overload semantics, metaclass effects, "
            "dynamic attributes, and behavioral protocol requirements remain outside."
        ),
    }
    result["flow_digest"] = digest_object(result)
    return result
