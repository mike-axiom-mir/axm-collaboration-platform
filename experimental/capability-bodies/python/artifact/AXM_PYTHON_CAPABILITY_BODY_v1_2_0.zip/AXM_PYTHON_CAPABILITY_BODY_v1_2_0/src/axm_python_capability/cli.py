from __future__ import annotations

import argparse
import json
from pathlib import Path

from .adapter_runner import run_adapter_request
from .adapters import adapter_catalog
from .analyze import HOST_PYTHON, analyze_source
from .builder import build_request
from .catalog import CATALOG, RECIPE_NAMES
from .constants import CAPABILITY_ID, CAPABILITY_VERSION
from .errors import CapabilityError
from .intelligence import stdlib_modules
from .patch import apply_patch_request
from .project_builder import build_project
from .recipes import get_recipe
from .compatibility import grammar_matrix
from .sandbox import sandbox_doctor
from .sandbox_tests import run_sandbox_test_request
from .engineering_bundle import normalize_engineering_bundle
from .engineering import architecture_report, affected_tests, api_passport, compare_api_passports
from .migrations import dependency_migration_plan
from .refactor import plan_public_symbol_rename
from .reference_index import build_reference_index
from .dead_code import dead_code_candidates
from .architecture_policy import check_architecture_policy
from .test_priority import prioritize_affected_tests
from .risk import change_risk_passport
from .proven_refactor import proven_symbol_rename_plan, plan_module_move
from .stewardship import stewardship_report
from .evidence_cache import incremental_evidence_snapshot
from .repo_shards import plan_repository_shards
from .change_sets import analyze_change_set_conflicts, compose_change_sets
from .rollback import generate_rollback_packet, apply_rollback_packet
from .member_flow import class_member_flow
from .behavior_fixtures import validate_behavior_fixtures_against_api
from .semantic_changes import semantic_change_graph
from .stream_index import stream_repository_index
from .advanced_members import advanced_member_flow
from .change_passport import build_change_passport
from .behavior_runner import behavior_fixture_execution_plan, run_behavior_fixtures_sandboxed
from .reference_blueprint import build_reference_blueprint, assess_candidate_body
from .implementation_map import build_python_implementation_map
from .self_audit import audit_package
from .maturity import build_maturity_passport
from .verification_corpus import run_corpus
from .scale_probe import run_scale_probe
from .fault_campaign import run_fault_campaign
from .verification_campaign import run_verification_campaign
from .packaging_truth import packaging_truth_passport
from .semantic_consensus import semantic_consensus_passport
from .fine_grained import fine_grained_invalidation
from .interface_policy import check_interface_policy
from .flow_evidence import normalize_flow_findings
from .test_strength import test_strength_passport
from .lossless_cst import analyze_lossless_source


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="AXM deterministic Python capability")
    sub = parser.add_subparsers(dest="command", required=True)

    build = sub.add_parser("build")
    build.add_argument("request")
    build.add_argument("--staging", required=True)

    pbuild = sub.add_parser("project-build")
    pbuild.add_argument("request")
    pbuild.add_argument("--staging", required=True)

    patch = sub.add_parser("patch")
    patch.add_argument("request")
    patch.add_argument("--output", required=False)

    adapters = sub.add_parser("adapters")
    adapters_sub = adapters.add_subparsers(dest="adapter_command", required=True)
    adapters_sub.add_parser("catalog")
    adapters_sub.add_parser("discover")
    arun = adapters_sub.add_parser("run")
    arun.add_argument("request")
    arun.add_argument("--output", required=False)

    analyze = sub.add_parser("analyze")
    analyze.add_argument("file")
    analyze.add_argument("--target-python", default=HOST_PYTHON)

    sub.add_parser("catalog")
    sub.add_parser("stdlib")

    recipe = sub.add_parser("recipe")
    recipe.add_argument("name", choices=RECIPE_NAMES)

    compat = sub.add_parser("compat")
    compat.add_argument("file")

    sandbox = sub.add_parser("sandbox")
    sandbox_sub = sandbox.add_subparsers(dest="sandbox_command", required=True)
    sandbox_sub.add_parser("doctor")
    stest = sandbox_sub.add_parser("test")
    stest.add_argument("request")
    stest.add_argument("--output", required=False)

    engineering = sub.add_parser("engineering")
    engineering_sub = engineering.add_subparsers(dest="engineering_command", required=True)

    ereport = engineering_sub.add_parser("report")
    ereport.add_argument("bundle")

    eimpact = engineering_sub.add_parser("affected-tests")
    eimpact.add_argument("bundle")
    eimpact.add_argument("--changed", action="append", required=True)

    epassport = engineering_sub.add_parser("api-passport")
    epassport.add_argument("bundle")

    ecompare = engineering_sub.add_parser("compare-api")
    ecompare.add_argument("before_passport")
    ecompare.add_argument("after_passport")

    emigrate = engineering_sub.add_parser("migration")
    emigrate.add_argument("before_bundle")
    emigrate.add_argument("after_bundle")
    emigrate.add_argument("--changed", action="append", default=[])

    erename = engineering_sub.add_parser("rename-plan")
    erename.add_argument("bundle")
    erename.add_argument("--module", required=True)
    erename.add_argument("--old", required=True)
    erename.add_argument("--new", required=True)

    eref = engineering_sub.add_parser("reference-index")
    eref.add_argument("bundle")

    edead = engineering_sub.add_parser("dead-code")
    edead.add_argument("bundle")

    epolicy = engineering_sub.add_parser("policy-check")
    epolicy.add_argument("bundle")
    epolicy.add_argument("policy")

    etests = engineering_sub.add_parser("test-priority")
    etests.add_argument("bundle")
    etests.add_argument("--changed", action="append", required=True)

    erisk = engineering_sub.add_parser("risk")
    erisk.add_argument("before_bundle")
    erisk.add_argument("after_bundle")
    erisk.add_argument("--changed", action="append", required=True)

    eproven = engineering_sub.add_parser("proven-rename")
    eproven.add_argument("bundle")
    eproven.add_argument("--module", required=True)
    eproven.add_argument("--old", required=True)
    eproven.add_argument("--new", required=True)

    emove = engineering_sub.add_parser("module-move")
    emove.add_argument("bundle")
    emove.add_argument("--old-module", required=True)
    emove.add_argument("--new-module", required=True)
    emove.add_argument("--new-path", required=True)

    esteward = engineering_sub.add_parser("steward")
    esteward.add_argument("bundle")
    esteward.add_argument("--policy", required=False)

    ecache = engineering_sub.add_parser("cache")
    ecache.add_argument("bundle")
    ecache.add_argument("--previous", required=False)

    eshards = engineering_sub.add_parser("shards")
    eshards.add_argument("bundle")
    eshards.add_argument("--max-files", type=int, default=250)
    eshards.add_argument("--max-bytes", type=int, default=4 * 1024 * 1024)

    econflict = engineering_sub.add_parser("change-conflicts")
    econflict.add_argument("change_sets")

    ecompose = engineering_sub.add_parser("compose")
    ecompose.add_argument("bundle")
    ecompose.add_argument("change_sets")
    ecompose.add_argument("--request-id", required=True)

    erollgen = engineering_sub.add_parser("rollback-generate")
    erollgen.add_argument("before_bundle")
    erollgen.add_argument("after_bundle")
    erollgen.add_argument("--change-id", required=True)

    erollapply = engineering_sub.add_parser("rollback-apply")
    erollapply.add_argument("current_bundle")
    erollapply.add_argument("packet")

    emember = engineering_sub.add_parser("member-flow")
    emember.add_argument("bundle")

    ebehavior = engineering_sub.add_parser("behavior-validate")
    ebehavior.add_argument("bundle")
    ebehavior.add_argument("fixtures")

    esemantic = engineering_sub.add_parser("semantic-changes")
    esemantic.add_argument("change_units")

    emembers2 = engineering_sub.add_parser("advanced-members")
    emembers2.add_argument("bundle")

    epass = engineering_sub.add_parser("change-passport")
    epass.add_argument("before_bundle")
    epass.add_argument("after_bundle")
    epass.add_argument("--changed", action="append", required=True)
    epass.add_argument("--policy", required=False)
    epass.add_argument("--fixtures", required=False)
    epass.add_argument("--sandbox-evidence", required=False)
    epass.add_argument("--adapter-evidence", required=False)

    ebehaviorplan = engineering_sub.add_parser("behavior-plan")
    ebehaviorplan.add_argument("bundle")
    ebehaviorplan.add_argument("fixtures")

    ebehaviorrun = engineering_sub.add_parser("behavior-run")
    ebehaviorrun.add_argument("project_root")
    ebehaviorrun.add_argument("bundle")
    ebehaviorrun.add_argument("fixtures")

    stream = sub.add_parser("stream-index")
    stream.add_argument("request")

    sub.add_parser("reference-blueprint")
    sub.add_parser("implementation-map")

    assess = sub.add_parser("assess-body")
    assess.add_argument("candidate")

    audit = sub.add_parser("self-audit")
    audit.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))

    maturity = sub.add_parser("maturity-passport")
    maturity.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    maturity.add_argument("--tests", type=int, required=True)

    sub.add_parser("syntax-corpus")

    scale = sub.add_parser("scale-probe")
    scale.add_argument("--modules", type=int, default=500)

    sub.add_parser("fault-campaign")

    campaign = sub.add_parser("verification-campaign")
    campaign.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    campaign.add_argument("--modules", type=int, default=500)

    ptruth = sub.add_parser("packaging-truth")
    ptruth.add_argument("input")

    scons = sub.add_parser("semantic-consensus")
    scons.add_argument("input")

    fgi = sub.add_parser("fine-grained-invalidation")
    fgi.add_argument("before_bundle")
    fgi.add_argument("after_bundle")

    ipol = sub.add_parser("interface-policy")
    ipol.add_argument("bundle")
    ipol.add_argument("policy")

    flow = sub.add_parser("flow-evidence")
    flow.add_argument("provider")
    flow.add_argument("findings")

    strength = sub.add_parser("test-strength")
    strength.add_argument("input")

    lcst = sub.add_parser("lossless-cst")
    lcst.add_argument("file")

    sub.add_parser("doctor")

    args = parser.parse_args(argv)

    try:
        if args.command == "build":
            raw = json.loads(Path(args.request).read_text(encoding="utf-8"))
            result = build_request(raw, args.staging)
            print(json.dumps({
                "status": "PASS",
                "run_id": result.run_id,
                "staging_dir": result.staging_dir,
                "receipt_path": result.receipt_path,
            }, sort_keys=True))
            return 0

        if args.command == "project-build":
            raw = json.loads(Path(args.request).read_text(encoding="utf-8"))
            result = build_project(raw, args.staging)
            print(json.dumps({
                "status": "PASS",
                "run_id": result["run_id"],
                "staging_dir": result["staging_dir"],
                "receipt_path": result["receipt_path"],
            }, sort_keys=True))
            return 0

        if args.command == "patch":
            raw = json.loads(Path(args.request).read_text(encoding="utf-8"))
            result = apply_patch_request(raw)
            text = json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
            if args.output:
                Path(args.output).write_text(text, encoding="utf-8")
            else:
                print(text, end="")
            return 0

        if args.command == "adapters":
            if args.adapter_command == "catalog":
                print(json.dumps(adapter_catalog(), indent=2, sort_keys=True))
                return 0
            if args.adapter_command == "discover":
                # Discovery is intentionally non-executing: only PATH lookup.
                import shutil
                data = []
                for item in adapter_catalog():
                    found = None
                    for executable in item["executables"]:
                        candidate = Path(executable)
                        if candidate.is_absolute() and candidate.exists():
                            found = str(candidate)
                            break
                        value = shutil.which(executable)
                        if value:
                            found = value
                            break
                    data.append({
                        "adapter_id": item["adapter_id"],
                        "path": found,
                        "discovered": found is not None,
                        "network_behavior": item["network_behavior"],
                    })
                print(json.dumps(data, indent=2, sort_keys=True))
                return 0
            if args.adapter_command == "run":
                raw = json.loads(Path(args.request).read_text(encoding="utf-8"))
                result = run_adapter_request(raw)
                text = json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
                if args.output:
                    Path(args.output).write_text(text, encoding="utf-8")
                else:
                    print(text, end="")
                return 0

        if args.command == "stream-index":
            raw = json.loads(Path(args.request).read_text(encoding="utf-8"))
            result = stream_repository_index(raw)
            print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
            return 0

        if args.command == "analyze":
            source = Path(args.file).read_text(encoding="utf-8")
            print(json.dumps(analyze_source(source, args.file, args.target_python), indent=2, sort_keys=True))
            return 0

        if args.command == "catalog":
            print(json.dumps({"catalog": CATALOG, "recipes": RECIPE_NAMES}, indent=2, sort_keys=True))
            return 0

        if args.command == "stdlib":
            print(json.dumps({"host_python": HOST_PYTHON, "modules": sorted(stdlib_modules())}, indent=2))
            return 0

        if args.command == "recipe":
            print(get_recipe(args.name), end="")
            return 0

        if args.command == "compat":
            source = Path(args.file).read_text(encoding="utf-8")
            print(json.dumps(grammar_matrix(source, args.file), indent=2, sort_keys=True))
            return 0

        if args.command == "sandbox":
            if args.sandbox_command == "doctor":
                print(json.dumps(sandbox_doctor(), indent=2, sort_keys=True))
                return 0
            if args.sandbox_command == "test":
                raw = json.loads(Path(args.request).read_text(encoding="utf-8"))
                result = run_sandbox_test_request(raw)
                text = json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
                if args.output:
                    Path(args.output).write_text(text, encoding="utf-8")
                else:
                    print(text, end="")
                return 0

        if args.command == "engineering":
            if args.engineering_command == "report":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = architecture_report(
                    bundle["files"],
                    bundle["target_python"],
                    bundle["package"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "affected-tests":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = affected_tests(
                    bundle["files"],
                    bundle["target_python"],
                    args.changed,
                    bundle["package"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "api-passport":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = api_passport(bundle["files"], bundle["target_python"])
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "compare-api":
                before = json.loads(Path(args.before_passport).read_text(encoding="utf-8"))
                after = json.loads(Path(args.after_passport).read_text(encoding="utf-8"))
                print(json.dumps(
                    compare_api_passports(before, after),
                    indent=2,
                    sort_keys=True,
                    ensure_ascii=False,
                ))
                return 0

            if args.engineering_command == "migration":
                before = normalize_engineering_bundle(
                    json.loads(Path(args.before_bundle).read_text(encoding="utf-8"))
                )
                after = normalize_engineering_bundle(
                    json.loads(Path(args.after_bundle).read_text(encoding="utf-8"))
                )
                tests = affected_tests(
                    before["files"],
                    before["target_python"],
                    args.changed,
                    before["package"],
                ) if args.changed else {"affected_test_paths": []}
                result = dependency_migration_plan(
                    before["dependencies"],
                    after["dependencies"],
                    tests["affected_test_paths"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "rename-plan":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = plan_public_symbol_rename(
                    bundle["files"],
                    bundle["target_python"],
                    module=args.module,
                    old=args.old,
                    new=args.new,
                    package=bundle["package"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "reference-index":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = build_reference_index(
                    bundle["files"], bundle["target_python"], bundle["package"]
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "dead-code":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = dead_code_candidates(
                    bundle["files"], bundle["target_python"], bundle["package"]
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "policy-check":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                policy = json.loads(Path(args.policy).read_text(encoding="utf-8"))
                result = check_architecture_policy(
                    bundle["files"], bundle["target_python"], policy, bundle["package"]
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "test-priority":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = prioritize_affected_tests(
                    bundle["files"], bundle["target_python"],
                    args.changed, bundle["package"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "risk":
                before = normalize_engineering_bundle(
                    json.loads(Path(args.before_bundle).read_text(encoding="utf-8"))
                )
                after = normalize_engineering_bundle(
                    json.loads(Path(args.after_bundle).read_text(encoding="utf-8"))
                )
                result = change_risk_passport(
                    before["files"], after["files"], before["target_python"],
                    args.changed, before["package"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "proven-rename":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = proven_symbol_rename_plan(
                    bundle["files"], bundle["target_python"],
                    module=args.module, old=args.old, new=args.new,
                    package=bundle["package"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "module-move":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = plan_module_move(
                    bundle["files"], bundle["target_python"],
                    old_module=args.old_module, new_module=args.new_module,
                    new_path=args.new_path, package=bundle["package"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "steward":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                policy = (
                    json.loads(Path(args.policy).read_text(encoding="utf-8"))
                    if args.policy else None
                )
                result = stewardship_report(
                    bundle["files"], bundle["target_python"],
                    bundle["package"], policy,
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "cache":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                previous = (
                    json.loads(Path(args.previous).read_text(encoding="utf-8"))
                    if args.previous else None
                )
                result = incremental_evidence_snapshot(
                    bundle["files"], bundle["target_python"],
                    bundle["package"], previous,
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "shards":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = plan_repository_shards(
                    bundle["files"], bundle["target_python"],
                    bundle["package"],
                    max_files=args.max_files,
                    max_bytes=args.max_bytes,
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "change-conflicts":
                raw = json.loads(Path(args.change_sets).read_text(encoding="utf-8"))
                change_sets = raw.get("change_sets", raw)
                result = analyze_change_set_conflicts(change_sets)
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "compose":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                raw = json.loads(Path(args.change_sets).read_text(encoding="utf-8"))
                change_sets = raw.get("change_sets", raw)
                result = compose_change_sets(
                    request_id=args.request_id,
                    target_python=bundle["target_python"],
                    base_files=bundle["files"],
                    change_sets=change_sets,
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "rollback-generate":
                before = normalize_engineering_bundle(
                    json.loads(Path(args.before_bundle).read_text(encoding="utf-8"))
                )
                after = normalize_engineering_bundle(
                    json.loads(Path(args.after_bundle).read_text(encoding="utf-8"))
                )
                result = generate_rollback_packet(
                    change_id=args.change_id,
                    before_files=before["files"],
                    after_files=after["files"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "rollback-apply":
                current = normalize_engineering_bundle(
                    json.loads(Path(args.current_bundle).read_text(encoding="utf-8"))
                )
                packet = json.loads(Path(args.packet).read_text(encoding="utf-8"))
                result = apply_rollback_packet(current["files"], packet)
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "member-flow":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = class_member_flow(
                    bundle["files"], bundle["target_python"], bundle["package"]
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "behavior-validate":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                fixtures = json.loads(Path(args.fixtures).read_text(encoding="utf-8"))
                result = validate_behavior_fixtures_against_api(
                    fixtures, bundle["files"], bundle["target_python"]
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "semantic-changes":
                raw = json.loads(Path(args.change_units).read_text(encoding="utf-8"))
                units = raw.get("change_units", raw)
                result = semantic_change_graph(units)
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "advanced-members":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                result = advanced_member_flow(
                    bundle["files"], bundle["target_python"], bundle["package"]
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "change-passport":
                before = normalize_engineering_bundle(
                    json.loads(Path(args.before_bundle).read_text(encoding="utf-8"))
                )
                after = normalize_engineering_bundle(
                    json.loads(Path(args.after_bundle).read_text(encoding="utf-8"))
                )
                policy = (
                    json.loads(Path(args.policy).read_text(encoding="utf-8"))
                    if args.policy else None
                )
                fixtures = (
                    json.loads(Path(args.fixtures).read_text(encoding="utf-8"))
                    if args.fixtures else None
                )
                sandbox_evidence = (
                    json.loads(Path(args.sandbox_evidence).read_text(encoding="utf-8"))
                    if args.sandbox_evidence else None
                )
                adapter_evidence = (
                    json.loads(Path(args.adapter_evidence).read_text(encoding="utf-8"))
                    if args.adapter_evidence else None
                )
                result = build_change_passport(
                    before_files=before["files"],
                    after_files=after["files"],
                    target_python=before["target_python"],
                    package=before["package"],
                    before_dependencies=before["dependencies"],
                    after_dependencies=after["dependencies"],
                    changed_paths=args.changed,
                    architecture_policy=policy,
                    behavior_fixtures=fixtures,
                    sandbox_test_evidence=sandbox_evidence,
                    static_adapter_evidence=adapter_evidence,
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "behavior-plan":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                fixtures = json.loads(Path(args.fixtures).read_text(encoding="utf-8"))
                result = behavior_fixture_execution_plan(
                    fixture_set=fixtures,
                    package=bundle["package"],
                    authorities=["READ_SPEC", "RUN_SANDBOX_TESTS"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

            if args.engineering_command == "behavior-run":
                bundle = normalize_engineering_bundle(
                    json.loads(Path(args.bundle).read_text(encoding="utf-8"))
                )
                fixtures = json.loads(Path(args.fixtures).read_text(encoding="utf-8"))
                result = run_behavior_fixtures_sandboxed(
                    project_root=args.project_root,
                    fixture_set=fixtures,
                    package=bundle["package"],
                    authorities=["READ_SPEC", "RUN_SANDBOX_TESTS"],
                )
                print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
                return 0

        if args.command == "reference-blueprint":
            print(json.dumps(
                build_reference_blueprint(),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "implementation-map":
            print(json.dumps(
                build_python_implementation_map(),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "assess-body":
            candidate = json.loads(
                Path(args.candidate).read_text(encoding="utf-8")
            )
            print(json.dumps(
                assess_candidate_body(candidate),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "self-audit":
            print(json.dumps(
                audit_package(args.root),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "maturity-passport":
            audit_result = audit_package(args.root)
            manifest = json.loads(
                (Path(args.root) / "manifest.json").read_text(encoding="utf-8")
            )
            schema_count = len(list((Path(args.root) / "schemas").glob("*.json")))
            result = build_maturity_passport(
                self_audit=audit_result,
                test_count=args.tests,
                feature_count=len(manifest.get("features", [])),
                schema_count=schema_count,
            )
            print(json.dumps(
                result,
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "syntax-corpus":
            print(json.dumps(
                run_corpus(HOST_PYTHON),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "scale-probe":
            print(json.dumps(
                run_scale_probe(
                    count=args.modules,
                    target_python=HOST_PYTHON,
                ),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "fault-campaign":
            print(json.dumps(
                run_fault_campaign(HOST_PYTHON),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "verification-campaign":
            root = Path(args.root)
            module_request = json.loads(
                (root / "examples" / "example_request.json").read_text(encoding="utf-8")
            )
            project_request = json.loads(
                (root / "examples" / "project_request.json").read_text(encoding="utf-8")
            )
            patch_request = json.loads(
                (root / "examples" / "guarded_patch_request.json").read_text(encoding="utf-8")
            )
            print(json.dumps(
                run_verification_campaign(
                    package_root=root,
                    module_request=module_request,
                    project_request=project_request,
                    patch_request=patch_request,
                    scale_modules=args.modules,
                ),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "packaging-truth":
            raw = json.loads(Path(args.input).read_text(encoding="utf-8"))
            print(json.dumps(
                packaging_truth_passport(**raw),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "semantic-consensus":
            raw = json.loads(Path(args.input).read_text(encoding="utf-8"))
            print(json.dumps(
                semantic_consensus_passport(raw),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "fine-grained-invalidation":
            before = normalize_engineering_bundle(
                json.loads(Path(args.before_bundle).read_text(encoding="utf-8"))
            )
            after = normalize_engineering_bundle(
                json.loads(Path(args.after_bundle).read_text(encoding="utf-8"))
            )
            print(json.dumps(
                fine_grained_invalidation(
                    before_files=before["files"],
                    after_files=after["files"],
                    target_python=before["target_python"],
                    package=before["package"],
                ),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "interface-policy":
            bundle = normalize_engineering_bundle(
                json.loads(Path(args.bundle).read_text(encoding="utf-8"))
            )
            policy = json.loads(Path(args.policy).read_text(encoding="utf-8"))
            print(json.dumps(
                check_interface_policy(
                    files=bundle["files"],
                    target_python=bundle["target_python"],
                    package=bundle["package"],
                    policy=policy,
                ),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "flow-evidence":
            findings = json.loads(
                Path(args.findings).read_text(encoding="utf-8")
            )
            print(json.dumps(
                normalize_flow_findings(args.provider, findings),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "test-strength":
            raw = json.loads(Path(args.input).read_text(encoding="utf-8"))
            print(json.dumps(
                test_strength_passport(**raw),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "lossless-cst":
            source = Path(args.file).read_text(encoding="utf-8")
            print(json.dumps(
                analyze_lossless_source(source),
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ))
            return 0

        if args.command == "doctor":
            print(json.dumps({
                "capability_id": CAPABILITY_ID,
                "version": CAPABILITY_VERSION,
                "host_python": HOST_PYTHON,
                "stdlib_module_count": len(stdlib_modules()),
                "generated_code_execution": False,
                "network_required": False,
                "package_installation": False,
                "project_intelligence": True,
                "deterministic_patch_engine": True,
                "bounded_static_adapters": True,
                "compatibility_matrix": True,
                "patch_impact_guards": True,
                "sandbox_provider_layer": True,
                "engineering_organs": True,
                "reference_index": True,
                "dead_code_candidates": True,
                "architecture_policy": True,
                "change_risk_passport": True,
                "proven_refactor_plans": True,
                "module_move_plans": True,
                "stewardship_report": True,
                "incremental_evidence_cache": True,
                "repository_sharding": True,
                "change_set_composition": True,
                "rollback_packets": True,
                "class_member_flow": True,
                "behavior_fixture_contracts": True,
                "semantic_change_graph": True,
                "streaming_repository_index": True,
                "advanced_member_flow": True,
                "change_passport": True,
                "behavior_fixture_sandbox_plan": True,
                "api_passports": True,
                "affected_test_mapping": True,
                "architecture_diagnosis": True,
                "adapter_network_enforcement": "POLICY_NOT_KERNEL_SANDBOX",
                "status": "READY_FOR_DETACHED_LOCAL_USE",
            }, indent=2, sort_keys=True))
            return 0

    except (CapabilityError, KeyError) as exc:
        print(json.dumps({
            "status": "REFUSED_OR_FAILED",
            "error": type(exc).__name__,
            "reason": str(exc),
        }, sort_keys=True))
        return 2

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
