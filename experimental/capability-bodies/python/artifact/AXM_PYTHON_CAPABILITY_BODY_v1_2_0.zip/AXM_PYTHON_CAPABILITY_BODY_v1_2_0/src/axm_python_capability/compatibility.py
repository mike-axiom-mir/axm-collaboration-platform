from __future__ import annotations

import ast
import sys
from pathlib import Path
from typing import Any

from .analyze import compile_without_execute
from .errors import VerificationError


HOST = (sys.version_info.major, sys.version_info.minor)
LOWEST_TRACKED_MINOR = 10


def grammar_matrix(source: str, filename: str = "<memory>") -> dict[str, Any]:
    """
    Best-effort grammar compatibility matrix using ast.parse(feature_version).
    This is syntax/grammar evidence, not a guarantee that every runtime/library
    behavior is identical on that historical Python release.
    """
    if HOST[0] != 3:
        raise VerificationError("UNSUPPORTED_HOST_MAJOR")

    compile_without_execute(source, filename)

    rows = []
    first_pass = None
    for minor in range(LOWEST_TRACKED_MINOR, HOST[1] + 1):
        version = f"3.{minor}"
        try:
            ast.parse(
                source,
                filename=filename,
                mode="exec",
                feature_version=(3, minor),
            )
            status = "PASS"
            if first_pass is None:
                first_pass = version
        except SyntaxError as exc:
            status = "FAIL"
            detail = {
                "line": exc.lineno,
                "offset": exc.offset,
                "message": exc.msg,
            }
        else:
            detail = None

        rows.append({
            "python": version,
            "grammar": status,
            "detail": detail,
        })

    if first_pass is None:
        raise VerificationError("NO_TRACKED_GRAMMAR_VERSION_ACCEPTED")

    return {
        "host_python": f"{HOST[0]}.{HOST[1]}",
        "minimum_tracked_grammar": first_pass,
        "matrix": rows,
        "truth_boundary": (
            "ast.parse(feature_version) is best-effort grammar evidence, "
            "not a full historical-runtime equivalence proof"
        ),
    }


def project_grammar_matrix(files: list[dict[str, str]]) -> dict[str, Any]:
    per_file = []
    minimum = f"3.{LOWEST_TRACKED_MINOR}"
    minimum_minor = LOWEST_TRACKED_MINOR

    for item in sorted(files, key=lambda x: x["path"]):
        if not item["path"].endswith(".py"):
            continue
        result = grammar_matrix(item["source"], item["path"])
        file_minor = int(result["minimum_tracked_grammar"].split(".")[1])
        minimum_minor = max(minimum_minor, file_minor)
        per_file.append({
            "path": item["path"],
            "minimum_tracked_grammar": result["minimum_tracked_grammar"],
        })

    minimum = f"3.{minimum_minor}"
    return {
        "project_minimum_tracked_grammar": minimum,
        "files": per_file,
        "host_python": f"{HOST[0]}.{HOST[1]}",
    }
