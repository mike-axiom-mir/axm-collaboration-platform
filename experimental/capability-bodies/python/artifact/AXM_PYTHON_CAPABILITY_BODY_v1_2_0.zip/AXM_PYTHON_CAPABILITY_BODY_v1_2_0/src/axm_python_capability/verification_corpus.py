from __future__ import annotations

from typing import Any

from .analyze import analyze_source
from .canonical import digest_object


CORPUS: tuple[dict[str, str], ...] = (
    {"id": "assignments", "source": "a, *b = [1, 2, 3]\nx = (y := 4)\n"},
    {"id": "functions", "source": "def f(a, /, b: int = 2, *, c: str = 'x') -> str:\n    return f'{a}:{b}:{c}'\n"},
    {"id": "async", "source": "async def f(x):\n    await x\n    return 1\n"},
    {"id": "async_gen", "source": "async def g(xs):\n    for x in xs:\n        yield x\n"},
    {"id": "generator", "source": "def g(xs):\n    yield from (x * 2 for x in xs)\n"},
    {"id": "comprehensions", "source": "a=[x for x in range(4) if x%2]\nb={x:x*x for x in a}\nc={*a}\n"},
    {"id": "lambda_closure", "source": "def outer(x):\n    return lambda y: x + y\n"},
    {"id": "class", "source": "class A:\n    @classmethod\n    def c(cls): return cls\n    @staticmethod\n    def s(): return 1\n"},
    {"id": "property", "source": "class A:\n    @property\n    def x(self): return self._x\n    @x.setter\n    def x(self,v): self._x=v\n"},
    {"id": "descriptor", "source": "class D:\n    def __get__(self,obj,owner): return 1\nclass A:\n    x=D()\n"},
    {"id": "metaclass", "source": "class M(type): pass\nclass A(metaclass=M): pass\n"},
    {"id": "exceptions", "source": "try:\n    raise ValueError('x')\nexcept ValueError as e:\n    x=str(e)\nfinally:\n    pass\n"},
    {"id": "exception_group", "source": "try:\n    raise ExceptionGroup('x',[ValueError('v')])\nexcept* ValueError:\n    pass\n"},
    {"id": "context", "source": "from contextlib import nullcontext\nwith nullcontext(1) as x:\n    y=x\n"},
    {"id": "async_context", "source": "async def f(cm):\n    async with cm as x:\n        return x\n"},
    {"id": "pattern_match", "source": "def f(x):\n    match x:\n        case {'a': int(v)} if v>0: return v\n        case [a,*rest]: return a\n        case _: return None\n"},
    {"id": "annotations", "source": "from __future__ import annotations\nx: list[int] | None = None\n"},
    {"id": "protocol", "source": "from typing import Protocol\nclass P(Protocol):\n    def f(self) -> str: ...\n"},
    {"id": "generic", "source": "from typing import Generic,TypeVar\nT=TypeVar('T')\nclass Box(Generic[T]):\n    def __init__(self,v:T): self.v=v\n"},
    {"id": "enum", "source": "from enum import Enum,auto\nclass E(Enum):\n    A=auto()\n"},
    {"id": "dataclass", "source": "from dataclasses import dataclass\n@dataclass(frozen=True,slots=True)\nclass A:\n    x:int\n"},
    {"id": "relative_import", "source": "from .sub import value\n"},
    {"id": "imports", "source": "import json as j\nfrom pathlib import Path as P\n"},
    {"id": "dunders", "source": "class A:\n    def __iter__(self): return iter(())\n    def __enter__(self): return self\n    def __exit__(self,*a): return False\n"},
    {"id": "nested_scopes", "source": "x=1\ndef f():\n    x=2\n    def g():\n        nonlocal x\n        x+=1\n    g()\n    return x\n"},
    {"id": "global", "source": "x=0\ndef f():\n    global x\n    x=1\n"},
    {"id": "bytes_unicode", "source": "a=b'abc'\nb='héllo 🌍'\n"},
    {"id": "slices", "source": "x=[1,2,3][::-1]\n"},
    {"id": "star_calls", "source": "def f(*a,**k): return a,k\nx=f(*[1,2],**{'x':3})\n"},
    {"id": "raise_from", "source": "try:\n    1/0\nexcept ZeroDivisionError as e:\n    raise RuntimeError('x') from e\n"},
)


def run_corpus(target_python: str) -> dict[str, Any]:
    results = []
    failures = []
    for case in CORPUS:
        try:
            analysis = analyze_source(
                case["source"],
                f"<corpus:{case['id']}>",
                target_python,
            )
        except Exception as exc:
            failures.append({
                "id": case["id"],
                "error": type(exc).__name__,
                "reason": str(exc),
            })
            continue
        results.append({
            "id": case["id"],
            "syntax": analysis["syntax"],
            "compile_without_execute": analysis["compile_without_execute"],
            "feature_flags": analysis["feature_flags"],
            "effect_signals": analysis["effect_signals"],
        })

    core = {
        "schema": "axm.python-verification-corpus-result.v1",
        "target_python": target_python,
        "case_count": len(CORPUS),
        "pass_count": len(results),
        "failure_count": len(failures),
        "results": results,
        "failures": failures,
        "status": "PASS" if not failures else "FAIL",
    }
    result = dict(core)
    result["corpus_digest"] = digest_object(core)
    return result
