from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any

from .constants import REQUEST_SCHEMA_V1, REQUEST_SCHEMA_V2
from .errors import ContractError


def require_identifier(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.isidentifier():
        raise ContractError(f"{label} must be a valid Python identifier")
    return value


def require_text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ContractError(f"{label} must be a non-empty string")
    return value


def safe_relpath(value: Any, label: str, *, suffix: str | None = None) -> str:
    value = require_text(value, label).replace("\\", "/")
    p = PurePosixPath(value)
    if p.is_absolute() or ".." in p.parts or "." in p.parts:
        raise ContractError(f"{label} must stay inside staging")
    if suffix is not None and not value.endswith(suffix):
        raise ContractError(f"{label} must end with {suffix}")
    return p.as_posix()


def normalize_target_python(value: Any) -> str:
    import sys
    if value is None:
        return f"{sys.version_info.major}.{sys.version_info.minor}"
    value = require_text(value, "target_python")
    parts = value.split(".")
    if len(parts) != 2 or not all(x.isdigit() for x in parts):
        raise ContractError("target_python must look like 3.10, 3.14, etc.")
    major, minor = map(int, parts)
    if major != 3 or minor < 10:
        raise ContractError("target_python must be Python 3.10 or newer")
    return f"{major}.{minor}"


@dataclass(frozen=True)
class BuildRequest:
    schema: str
    request_id: str
    package: str
    goal: str
    target_python: str
    authorities: tuple[str, ...]
    modules: tuple[dict[str, Any], ...]
    resources: tuple[dict[str, Any], ...]
    package_init: str | None
    provenance: tuple[str, ...]
    metadata: dict[str, Any]

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "BuildRequest":
        if not isinstance(raw, dict):
            raise ContractError("request must be an object")

        schema = raw.get("schema")
        if schema not in {REQUEST_SCHEMA_V1, REQUEST_SCHEMA_V2}:
            raise ContractError(
                f"schema must be {REQUEST_SCHEMA_V1} or {REQUEST_SCHEMA_V2}"
            )

        request_id = require_text(raw.get("request_id"), "request_id")
        package = require_identifier(raw.get("package"), "package")
        goal = require_text(raw.get("goal"), "goal")
        target_python = normalize_target_python(raw.get("target_python"))

        authorities_raw = raw.get("authorities", ["READ_SPEC", "WRITE_STAGING"])
        if not isinstance(authorities_raw, list):
            raise ContractError("authorities must be a list")

        provenance_raw = raw.get("provenance", [])
        if not isinstance(provenance_raw, list):
            raise ContractError("provenance must be a list")

        metadata = raw.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ContractError("metadata must be an object")

        modules_raw = raw.get("modules")
        if not isinstance(modules_raw, list) or not modules_raw:
            raise ContractError("modules must be a non-empty list")

        modules = []
        seen_paths = set()
        for i, module in enumerate(modules_raw):
            if not isinstance(module, dict):
                raise ContractError(f"modules[{i}] must be an object")

            name = module.get("name")
            path = module.get("path")
            if path is None:
                name = require_identifier(name, f"modules[{i}].name")
                path = f"{name}.py"
            path = safe_relpath(path, f"modules[{i}].path", suffix=".py")
            if path in seen_paths:
                raise ContractError(f"duplicate module path: {path}")
            seen_paths.add(path)

            source = module.get("source")
            components = module.get("components")
            if source is not None and components is not None:
                raise ContractError(f"modules[{i}] must use source OR components, not both")
            if source is not None and not isinstance(source, str):
                raise ContractError(f"modules[{i}].source must be a string")
            if source is None:
                if components is None:
                    components = []
                if not isinstance(components, list):
                    raise ContractError(f"modules[{i}].components must be a list")

            item = dict(module)
            item["path"] = path
            if name is None:
                stem = PurePosixPath(path).stem
                if stem.isidentifier():
                    item["name"] = stem
            modules.append(item)

        resources_raw = raw.get("resources", [])
        if not isinstance(resources_raw, list):
            raise ContractError("resources must be a list")
        resources = []
        resource_paths = set()
        for i, resource in enumerate(resources_raw):
            if not isinstance(resource, dict):
                raise ContractError(f"resources[{i}] must be an object")
            path = safe_relpath(resource.get("path"), f"resources[{i}].path")
            if path.endswith(".py"):
                raise ContractError("Python source belongs in modules, not resources")
            if path in resource_paths or path in seen_paths:
                raise ContractError(f"duplicate output path: {path}")
            resource_paths.add(path)
            has_text = "text" in resource
            has_json = "json" in resource
            if has_text == has_json:
                raise ContractError(f"resources[{i}] must contain exactly one of text or json")
            if has_text and not isinstance(resource["text"], str):
                raise ContractError(f"resources[{i}].text must be a string")
            resources.append(dict(resource, path=path))

        package_init = raw.get("package_init")
        if package_init is not None and not isinstance(package_init, str):
            raise ContractError("package_init must be a string")

        return cls(
            schema=schema,
            request_id=request_id,
            package=package,
            goal=goal,
            target_python=target_python,
            authorities=tuple(str(x) for x in authorities_raw),
            modules=tuple(modules),
            resources=tuple(resources),
            package_init=package_init,
            provenance=tuple(str(x) for x in provenance_raw),
            metadata=dict(metadata),
        )

    def normalized(self) -> dict[str, Any]:
        return {
            "schema": REQUEST_SCHEMA_V2,
            "request_id": self.request_id,
            "package": self.package,
            "goal": self.goal,
            "target_python": self.target_python,
            "authorities": sorted(set(self.authorities)),
            "modules": [dict(x) for x in self.modules],
            "resources": [dict(x) for x in self.resources],
            "package_init": self.package_init,
            "provenance": sorted(set(self.provenance)),
            "metadata": self.metadata,
        }


@dataclass(frozen=True)
class BuildResult:
    run_id: str
    staging_dir: str
    manifest_path: str
    receipt_path: str
    receipt: dict[str, Any]
