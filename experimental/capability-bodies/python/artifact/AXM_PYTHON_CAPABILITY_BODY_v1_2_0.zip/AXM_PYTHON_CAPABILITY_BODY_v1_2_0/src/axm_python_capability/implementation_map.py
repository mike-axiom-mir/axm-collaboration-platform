from __future__ import annotations

from .canonical import digest_object


IMPLEMENTATION = [
    {
        "layer": 0,
        "modules": [
            "authority.py",
            "canonical.py",
            "constants.py",
            "contracts.py",
            "errors.py",
        ],
        "evidence": [
            "manifest.json",
            "schemas/",
        ],
    },
    {
        "layer": 1,
        "modules": [
            "builder.py",
            "render.py",
            "analyze.py",
            "verify.py",
            "compatibility.py",
        ],
        "evidence": [
            "examples/example_request.json",
            "examples/almost_all_python_request.json",
        ],
    },
    {
        "layer": 2,
        "modules": [
            "analyze.py",
            "reference_index.py",
            "member_flow.py",
            "advanced_members.py",
            "dead_code.py",
        ],
        "evidence": [
            "example_output/",
        ],
    },
    {
        "layer": 3,
        "modules": [
            "project_builder.py",
            "project_graph.py",
            "intelligence.py",
            "architecture_policy.py",
            "stewardship.py",
            "stream_index.py",
            "repo_shards.py",
        ],
        "evidence": [
            "examples/project_request.json",
            "examples/engineering_bundle.json",
        ],
    },
    {
        "layer": 4,
        "modules": [
            "impact.py",
            "risk.py",
            "engineering.py",
            "test_priority.py",
            "migrations.py",
            "change_passport.py",
            "semantic_changes.py",
        ],
        "evidence": [
            "examples/architecture_policy.json",
            "examples/semantic_change_units.json",
        ],
    },
    {
        "layer": 5,
        "modules": [
            "patch.py",
            "refactor.py",
            "proven_refactor.py",
            "change_sets.py",
            "rollback.py",
            "evidence_cache.py",
            "evidence_store.py",
        ],
        "evidence": [
            "examples/patch_request.json",
            "examples/guarded_patch_request.json",
            "examples/change_sets_clean.json",
        ],
    },
    {
        "layer": 6,
        "modules": [
            "adapters.py",
            "adapter_runner.py",
        ],
        "evidence": [
            "ADAPTER_POLICY.md",
        ],
    },
    {
        "layer": 7,
        "modules": [
            "sandbox.py",
            "sandbox_tests.py",
            "behavior_runner.py",
        ],
        "evidence": [
            "SANDBOX_POLICY.md",
        ],
    },
    {
        "layer": 8,
        "modules": [
            "change_passport.py",
            "maturity.py",
            "self_audit.py",
            "reference_blueprint.py",
        ],
        "evidence": [
            "CODE_BODY_REFERENCE_ARCHITECTURE.md",
            "REFERENCE_BODY_BLUEPRINT.json",
            "DONOR_INTAKE_CHECKLIST.json",
        ],
    },
]


def build_python_implementation_map() -> dict:
    core = {
        "schema": "axm.python-reference-implementation-map.v1",
        "language": "python",
        "layers": IMPLEMENTATION,
        "truth_boundary": (
            "This map says where the Python donor implements reference contracts. "
            "It does not require future languages to use the same filenames or tools."
        ),
    }
    result = dict(core)
    result["implementation_digest"] = digest_object(core)
    return result
