from __future__ import annotations

import ast
from collections import defaultdict, deque
from pathlib import PurePosixPath
from typing import Any

from .analyze import parse_source, safe_unparse


def _strip_layout(parts: list[str]) -> list[str]:
    if parts and parts[0] == "src":
        return parts[1:]
    return parts


def module_name_from_path(path: str, package: str | None = None) -> str:
    p = PurePosixPath(path)
    parts = _strip_layout(list(p.with_suffix("").parts))
    if parts and parts[0] == "tests":
        return ".".join(parts)
    if package and package in parts:
        idx = parts.index(package)
        parts = parts[idx:]
    if parts and parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def _resolve_relative(source_module: str, module: str, level: int) -> str | None:
    if level <= 0:
        return module or None

    source_parts = source_module.split(".")
    # Imports resolve from the containing package. __init__ paths are already
    # represented as package names, so always drop the module leaf if present.
    base = source_parts[:-1]
    climb = level - 1
    if climb > len(base):
        return None
    if climb:
        base = base[:-climb]
    if module:
        base += module.split(".")
    return ".".join(base) if base else None


def _known_match(name: str | None, known: set[str]) -> str | None:
    if not name:
        return None
    if name in known:
        return name
    # `from pkg import sub` may point at pkg.sub.
    candidates = sorted(
        (m for m in known if m == name or m.startswith(name + ".")),
        key=lambda x: (len(x), x),
    )
    return candidates[0] if candidates else None


def build_module_graph(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
) -> dict[str, Any]:
    py_files = [x for x in files if x["path"].endswith(".py")]
    path_to_module = {
        item["path"]: module_name_from_path(item["path"], package)
        for item in py_files
    }
    known = {m for m in path_to_module.values() if m}

    edges = []
    external = []
    trees: dict[str, ast.Module] = {}

    for item in py_files:
        module = path_to_module[item["path"]]
        tree = parse_source(item["source"], item["path"], target_python)
        if not isinstance(tree, ast.Module):
            continue
        trees[module] = tree

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    target = _known_match(alias.name, known)
                    record = {
                        "from": module,
                        "raw": alias.name,
                        "target": target,
                        "kind": "import",
                    }
                    if target:
                        edges.append(record)
                    else:
                        external.append(record)

            elif isinstance(node, ast.ImportFrom):
                base = _resolve_relative(module, node.module or "", node.level)
                base_match = _known_match(base, known)
                matched_any = False

                for alias in node.names:
                    if alias.name == "*":
                        candidate = base_match
                    else:
                        candidate_name = f"{base}.{alias.name}" if base else alias.name
                        candidate = _known_match(candidate_name, known) or base_match

                    record = {
                        "from": module,
                        "raw": (
                            "." * node.level
                            + (node.module or "")
                            + (f":{alias.name}" if alias.name else "")
                        ),
                        "target": candidate,
                        "kind": "from",
                    }
                    if candidate:
                        edges.append(record)
                        matched_any = True
                    else:
                        external.append(record)

                if not node.names and base_match and not matched_any:
                    edges.append({
                        "from": module,
                        "raw": "." * node.level + (node.module or ""),
                        "target": base_match,
                        "kind": "from",
                    })

    # Deduplicate deterministic edges.
    edge_key = lambda x: (x["from"], x["target"] or "", x["kind"], x["raw"])
    edges = [
        {"from": a, "raw": b, "target": c, "kind": d}
        for a, b, c, d in sorted(
            ((e["from"], e["raw"], e["target"], e["kind"]) for e in edges),
            key=lambda x: (x[0], x[2] or "", x[3], x[1]),
        )
    ]
    dedup = []
    seen = set()
    for e in edges:
        k = edge_key(e)
        if k not in seen:
            seen.add(k)
            dedup.append(e)
    edges = dedup

    adjacency = {m: [] for m in sorted(known)}
    reverse = {m: [] for m in sorted(known)}
    for edge in edges:
        source = edge["from"]
        target = edge["target"]
        if source in adjacency and target in adjacency and target not in adjacency[source]:
            adjacency[source].append(target)
            reverse[target].append(source)

    for d in (adjacency, reverse):
        for key in d:
            d[key] = sorted(d[key])

    return {
        "path_to_module": dict(sorted(path_to_module.items())),
        "modules": sorted(known),
        "edges": edges,
        "external_import_records": sorted(
            external,
            key=lambda x: (x["from"], x["raw"], x["kind"]),
        ),
        "adjacency": adjacency,
        "reverse_adjacency": reverse,
    }


def strongly_connected_components(graph: dict[str, Any]) -> list[list[str]]:
    adjacency = graph["adjacency"]
    index = 0
    indices: dict[str, int] = {}
    low: dict[str, int] = {}
    stack: list[str] = []
    on_stack: set[str] = set()
    components: list[list[str]] = []

    def visit(v: str) -> None:
        nonlocal index
        indices[v] = index
        low[v] = index
        index += 1
        stack.append(v)
        on_stack.add(v)

        for w in adjacency.get(v, []):
            if w not in indices:
                visit(w)
                low[v] = min(low[v], low[w])
            elif w in on_stack:
                low[v] = min(low[v], indices[w])

        if low[v] == indices[v]:
            comp = []
            while True:
                w = stack.pop()
                on_stack.remove(w)
                comp.append(w)
                if w == v:
                    break
            components.append(sorted(comp))

    for module in sorted(adjacency):
        if module not in indices:
            visit(module)

    return sorted(components, key=lambda x: (len(x), x))


def cycles(graph: dict[str, Any]) -> list[list[str]]:
    out = []
    for comp in strongly_connected_components(graph):
        if len(comp) > 1:
            out.append(comp)
        elif comp:
            node = comp[0]
            if node in graph["adjacency"].get(node, []):
                out.append(comp)
    return sorted(out, key=lambda x: (len(x), x))


def reverse_dependency_closure(
    graph: dict[str, Any],
    seed_modules: list[str],
) -> list[str]:
    reverse = graph["reverse_adjacency"]
    seen = set(seed_modules)
    queue = deque(sorted(seed_modules))
    while queue:
        current = queue.popleft()
        for parent in reverse.get(current, []):
            if parent not in seen:
                seen.add(parent)
                queue.append(parent)
    return sorted(seen)


class _CallVisitor(ast.NodeVisitor):
    def __init__(
        self,
        module: str,
        known_defs: set[str],
        import_aliases: dict[str, str],
    ) -> None:
        self.module = module
        self.known_defs = known_defs
        self.import_aliases = import_aliases
        self.scope: list[str] = []
        self.class_scope: list[str] = []
        self.calls: list[dict[str, Any]] = []

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.class_scope.append(node.name)
        self.generic_visit(node)
        self.class_scope.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.scope.append(node.name)
        self.generic_visit(node)
        self.scope.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.scope.append(node.name)
        self.generic_visit(node)
        self.scope.pop()

    def visit_Call(self, node: ast.Call) -> None:
        source = self.module
        if self.class_scope and self.scope:
            source += f".{self.class_scope[-1]}.{self.scope[-1]}"
        elif self.scope:
            source += f".{self.scope[-1]}"

        target = None
        resolution = "external_or_unresolved"
        raw = safe_unparse(node.func)

        if isinstance(node.func, ast.Name):
            candidate = f"{self.module}.{node.func.id}"
            if candidate in self.known_defs:
                target = candidate
                resolution = "resolved_local"
            elif node.func.id in self.import_aliases:
                target = self.import_aliases[node.func.id]
                resolution = (
                    "resolved_import_reference"
                    if target in self.known_defs
                    else "external_import_reference"
                )

        elif isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name):
                root = node.func.value.id
                if root == "self" and self.class_scope:
                    candidate = f"{self.module}.{self.class_scope[-1]}.{node.func.attr}"
                    if candidate in self.known_defs:
                        target = candidate
                        resolution = "resolved_local"
                elif root in self.import_aliases:
                    candidate = f"{self.import_aliases[root]}.{node.func.attr}"
                    target = candidate
                    resolution = (
                        "resolved_import_reference"
                        if candidate in self.known_defs
                        else "external_import_reference"
                    )

        self.calls.append({
            "from": source,
            "raw": raw,
            "target": target,
            "resolution": resolution,
            "line": getattr(node, "lineno", None),
        })
        self.generic_visit(node)


def _definitions(module: str, tree: ast.Module) -> set[str]:
    defs = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            defs.add(f"{module}.{node.name}")
        elif isinstance(node, ast.ClassDef):
            defs.add(f"{module}.{node.name}")
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    defs.add(f"{module}.{node.name}.{child.name}")
    return defs


def _import_aliases(
    module: str,
    tree: ast.Module,
    known_modules: set[str],
    known_defs: set[str],
) -> dict[str, str]:
    aliases: dict[str, str] = {}
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                target = _known_match(alias.name, known_modules)
                if target:
                    aliases[alias.asname or alias.name.split(".")[0]] = target

        elif isinstance(node, ast.ImportFrom):
            base = _resolve_relative(module, node.module or "", node.level)
            for alias in node.names:
                candidate = f"{base}.{alias.name}" if base else alias.name
                if candidate in known_defs:
                    aliases[alias.asname or alias.name] = candidate
                    continue
                target = _known_match(candidate, known_modules)
                if target:
                    aliases[alias.asname or alias.name] = target
    return aliases


def build_call_graph(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
) -> dict[str, Any]:
    module_graph = build_module_graph(files, target_python, package)
    path_to_module = module_graph["path_to_module"]
    known_modules = set(module_graph["modules"])

    trees: dict[str, ast.Module] = {}
    all_defs: set[str] = set()

    for item in files:
        if not item["path"].endswith(".py"):
            continue
        module = path_to_module[item["path"]]
        tree = parse_source(item["source"], item["path"], target_python)
        if isinstance(tree, ast.Module):
            trees[module] = tree
            all_defs.update(_definitions(module, tree))

    calls = []
    for module in sorted(trees):
        tree = trees[module]
        aliases = _import_aliases(module, tree, known_modules, all_defs)
        visitor = _CallVisitor(module, all_defs, aliases)
        visitor.visit(tree)
        calls.extend(visitor.calls)

    return {
        "definitions": sorted(all_defs),
        "calls": sorted(
            calls,
            key=lambda x: (
                x["from"],
                x["line"] if x["line"] is not None else -1,
                x["raw"] or "",
            ),
        ),
        "truth_boundary": (
            "Static approximate call graph. Dynamic dispatch, monkey patching, "
            "reflection, decorators, descriptors, and runtime import behavior "
            "can create edges not provable from syntax alone."
        ),
    }
