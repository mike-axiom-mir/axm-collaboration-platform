from __future__ import annotations

import ast
import sys
from collections import Counter
from typing import Any

from .errors import VerificationError


HOST_PYTHON = f"{sys.version_info.major}.{sys.version_info.minor}"

NETWORK_MODULES = {
    "socket", "ssl", "http", "urllib", "ftplib", "smtplib", "imaplib",
    "poplib", "telnetlib", "xmlrpc", "webbrowser", "requests", "httpx", "aiohttp"
}
PROCESS_MODULES = {"subprocess", "multiprocessing", "pty"}
SYSTEM_MODULES = {"os", "pathlib", "shutil", "tempfile", "glob"}
DYNAMIC_MODULES = {"importlib", "runpy"}
PACKAGE_MODULES = {"pip", "ensurepip"}

CALL_SIGNALS = {
    "exec": "dynamic_execution",
    "eval": "dynamic_execution",
    "__import__": "dynamic_import",
    "open": "filesystem_access",
    "breakpoint": "interactive_debug",
    "compile": "dynamic_compile",
    "os.system": "shell_execution",
    "os.remove": "destructive_filesystem",
    "os.unlink": "destructive_filesystem",
    "shutil.rmtree": "destructive_filesystem",
    "subprocess.run": "process_control",
    "subprocess.Popen": "process_control",
}


def _version_tuple(value: str) -> tuple[int, int]:
    major, minor = value.split(".")
    return int(major), int(minor)


def grammar_relation(target: str) -> str:
    target_v = _version_tuple(target)
    host_v = (sys.version_info.major, sys.version_info.minor)
    if target_v > host_v:
        return "TARGET_NEWER_THAN_HOST"
    if target_v == host_v:
        return "HOST_NATIVE"
    return "HOST_CAN_VALIDATE_OLDER_GRAMMAR"


def parse_source(source: str, filename: str, target_python: str) -> ast.AST:
    relation = grammar_relation(target_python)
    if relation == "TARGET_NEWER_THAN_HOST":
        raise VerificationError(f"GRAMMAR_HOLD:target={target_python}:host={HOST_PYTHON}")

    _, target_minor = _version_tuple(target_python)
    try:
        return ast.parse(source, filename=filename, mode="exec", feature_version=target_minor)
    except SyntaxError as exc:
        raise VerificationError(
            f"SYNTAX_ERROR:{filename}:{exc.lineno}:{exc.offset}:{exc.msg}"
        ) from exc


def dotted_name(node: ast.AST | None) -> str | None:
    if node is None:
        return None
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        left = dotted_name(node.value)
        return f"{left}.{node.attr}" if left else node.attr
    return None


def safe_unparse(node: ast.AST | None) -> str | None:
    if node is None:
        return None
    try:
        return ast.unparse(node)
    except Exception:
        return None


def function_signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> dict[str, Any]:
    args = node.args
    positional = list(args.posonlyargs) + list(args.args)
    defaults_offset = len(positional) - len(args.defaults)
    params: list[dict[str, Any]] = []

    for i, arg in enumerate(positional):
        kind = "positional_only" if i < len(args.posonlyargs) else "positional_or_keyword"
        default = None
        if i >= defaults_offset:
            default = safe_unparse(args.defaults[i - defaults_offset])
        params.append({
            "name": arg.arg,
            "kind": kind,
            "annotation": safe_unparse(arg.annotation),
            "default": default,
        })

    if args.vararg:
        params.append({
            "name": args.vararg.arg,
            "kind": "var_positional",
            "annotation": safe_unparse(args.vararg.annotation),
            "default": None,
        })

    for arg, default_node in zip(args.kwonlyargs, args.kw_defaults):
        params.append({
            "name": arg.arg,
            "kind": "keyword_only",
            "annotation": safe_unparse(arg.annotation),
            "default": safe_unparse(default_node),
        })

    if args.kwarg:
        params.append({
            "name": args.kwarg.arg,
            "kind": "var_keyword",
            "annotation": safe_unparse(args.kwarg.annotation),
            "default": None,
        })

    return {
        "name": node.name,
        "async": isinstance(node, ast.AsyncFunctionDef),
        "parameters": params,
        "returns": safe_unparse(node.returns),
        "decorators": [safe_unparse(x) for x in node.decorator_list],
    }


def extract_api(tree: ast.Module) -> dict[str, Any]:
    functions = []
    classes = []
    constants = []
    explicit_all: list[str] | None = None

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            item = function_signature(node)
            item["public"] = not node.name.startswith("_")
            functions.append(item)

        elif isinstance(node, ast.ClassDef):
            methods = []
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    method = function_signature(child)
                    method["public"] = not child.name.startswith("_") or child.name.startswith("__")
                    methods.append(method)
            classes.append({
                "name": node.name,
                "public": not node.name.startswith("_"),
                "bases": [safe_unparse(x) for x in node.bases],
                "decorators": [safe_unparse(x) for x in node.decorator_list],
                "methods": methods,
            })

        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            constants.append({
                "name": node.target.id,
                "annotation": safe_unparse(node.annotation),
                "value": safe_unparse(node.value),
                "public": not node.target.id.startswith("_"),
            })

        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    constants.append({
                        "name": target.id,
                        "annotation": None,
                        "value": safe_unparse(node.value),
                        "public": not target.id.startswith("_"),
                    })
                    if target.id == "__all__" and isinstance(node.value, (ast.List, ast.Tuple)):
                        names = []
                        ok = True
                        for elt in node.value.elts:
                            if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                                names.append(elt.value)
                            else:
                                ok = False
                                break
                        if ok:
                            explicit_all = names

    return {
        "functions": functions,
        "classes": classes,
        "constants": constants,
        "explicit___all__": explicit_all,
    }


class _Nesting(ast.NodeVisitor):
    def __init__(self) -> None:
        self.depth = 0
        self.max_depth = 0

    def generic_visit(self, node: ast.AST) -> None:
        nesting = isinstance(node, (
            ast.If, ast.For, ast.AsyncFor, ast.While, ast.Try, ast.With,
            ast.AsyncWith, ast.Match, ast.FunctionDef, ast.AsyncFunctionDef,
            ast.ClassDef
        ))
        if nesting:
            self.depth += 1
            self.max_depth = max(self.max_depth, self.depth)
        super().generic_visit(node)
        if nesting:
            self.depth -= 1


def complexity_metrics(tree: ast.AST) -> dict[str, int]:
    counts = Counter(type(node).__name__ for node in ast.walk(tree))
    branches = (
        counts["If"] + counts["For"] + counts["AsyncFor"] + counts["While"] +
        counts["IfExp"] + counts["ExceptHandler"] + counts["MatchCase"] +
        counts["comprehension"] + counts["BoolOp"]
    )
    nesting = _Nesting()
    nesting.visit(tree)
    return {
        "approx_cyclomatic": 1 + branches,
        "branch_points": branches,
        "max_nesting": nesting.max_depth,
        "function_count": counts["FunctionDef"] + counts["AsyncFunctionDef"],
        "class_count": counts["ClassDef"],
        "statement_count": sum(
            1 for node in ast.walk(tree) if isinstance(node, ast.stmt)
        ),
    }


def extract_import_records(tree: ast.AST) -> list[dict[str, Any]]:
    records = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                records.append({
                    "kind": "import",
                    "module": alias.name,
                    "level": 0,
                    "name": None,
                    "alias": alias.asname,
                })
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                records.append({
                    "kind": "from",
                    "module": node.module or "",
                    "level": node.level,
                    "name": alias.name,
                    "alias": alias.asname,
                })
    return sorted(records, key=lambda x: (
        x["level"], x["module"], x["name"] or "", x["alias"] or ""
    ))


def test_signals(filename: str, tree: ast.Module) -> dict[str, Any]:
    path = filename.replace("\\", "/")
    basename = path.rsplit("/", 1)[-1]
    imports = {r["module"].split(".", 1)[0] for r in extract_import_records(tree) if r["module"]}
    functions = [
        node.name for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_")
    ]
    classes = [
        node.name for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name.startswith("Test")
    ]
    is_test_path = (
        basename.startswith("test_") or basename.endswith("_test.py") or
        "/tests/" in f"/{path}"
    )
    return {
        "is_test_file": is_test_path or bool(functions) or bool(classes),
        "framework_signals": sorted(imports & {"unittest", "pytest", "hypothesis"}),
        "test_functions": sorted(functions),
        "test_classes": sorted(classes),
    }


def analyze_tree(tree: ast.Module, filename: str) -> dict[str, Any]:
    counts: Counter[str] = Counter()
    imports: set[str] = set()
    symbols: list[dict[str, str]] = []
    effect_signals: set[str] = set()
    decorators: set[str] = set()
    calls: set[str] = set()

    for node in ast.walk(tree):
        counts[type(node).__name__] += 1

        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            symbols.append({"kind": type(node).__name__, "name": node.name})
            for deco in getattr(node, "decorator_list", []):
                name = dotted_name(deco)
                if name:
                    decorators.add(name)

        if isinstance(node, ast.Import):
            imports.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.add(node.module or "")

        if isinstance(node, ast.Call):
            name = dotted_name(node.func)
            if name:
                calls.add(name)
                root = name.split(".", 1)[0]
                if name in CALL_SIGNALS:
                    effect_signals.add(CALL_SIGNALS[name])
                if root in PROCESS_MODULES:
                    effect_signals.add("process_control")
                if root in NETWORK_MODULES:
                    effect_signals.add("network_capable_code")
                if root in PACKAGE_MODULES:
                    effect_signals.add("package_management")
                if root in SYSTEM_MODULES:
                    effect_signals.add("filesystem_or_system_capable_code")
                if root in DYNAMIC_MODULES:
                    effect_signals.add("dynamic_import_or_execution")

                # shell=True is a stronger subprocess signal.
                if root == "subprocess":
                    for kw in node.keywords:
                        if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                            effect_signals.add("shell_execution")

        if isinstance(node, ast.Attribute):
            full = dotted_name(node)
            if full in {"os.environ", "os.getenv"}:
                effect_signals.add("environment_access")

    roots = {x.split(".", 1)[0] for x in imports if x}
    if roots & NETWORK_MODULES:
        effect_signals.add("network_capable_code")
    if roots & PROCESS_MODULES:
        effect_signals.add("process_control")
    if roots & SYSTEM_MODULES:
        effect_signals.add("filesystem_or_system_capable_code")
    if roots & PACKAGE_MODULES:
        effect_signals.add("package_management")
    if roots & DYNAMIC_MODULES:
        effect_signals.add("dynamic_import_or_execution")

    feature_flags = {
        "async": counts["AsyncFunctionDef"] > 0 or counts["Await"] > 0,
        "generators": counts["Yield"] > 0 or counts["YieldFrom"] > 0,
        "comprehensions": sum(counts[x] for x in ("ListComp", "SetComp", "DictComp", "GeneratorExp")) > 0,
        "pattern_matching": counts["Match"] > 0,
        "context_managers": counts["With"] > 0 or counts["AsyncWith"] > 0,
        "exceptions": counts["Try"] > 0 or counts["TryStar"] > 0 or counts["Raise"] > 0,
        "lambdas": counts["Lambda"] > 0,
        "decorators": bool(decorators),
        "walrus": counts["NamedExpr"] > 0,
        "type_alias_nodes": counts["TypeAlias"] > 0,
        "template_strings": counts["TemplateStr"] > 0,
        "exception_groups": counts["TryStar"] > 0,
    }

    return {
        "imports": sorted(imports),
        "import_records": extract_import_records(tree),
        "symbols": sorted(symbols, key=lambda x: (x["kind"], x["name"])),
        "api": extract_api(tree),
        "decorators": sorted(decorators),
        "calls": sorted(calls),
        "feature_flags": feature_flags,
        "complexity": complexity_metrics(tree),
        "tests": test_signals(filename, tree),
        "ast_node_counts": dict(sorted(counts.items())),
        "effect_signals": sorted(effect_signals),
    }


def compile_without_execute(source: str, filename: str) -> None:
    """Compile to a code object for scope/symbol checks, but never execute it."""
    try:
        compile(source, filename, "exec", dont_inherit=True, optimize=0)
    except (SyntaxError, ValueError, OverflowError) as exc:
        lineno = getattr(exc, "lineno", None)
        offset = getattr(exc, "offset", None)
        msg = getattr(exc, "msg", str(exc))
        raise VerificationError(
            f"COMPILE_ERROR:{filename}:{lineno}:{offset}:{msg}"
        ) from exc


def analyze_source(source: str, filename: str, target_python: str) -> dict[str, Any]:
    tree = parse_source(source, filename, target_python)
    if not isinstance(tree, ast.Module):
        raise VerificationError("EXPECTED_MODULE_AST")
    compile_without_execute(source, filename)
    result = analyze_tree(tree, filename)
    result.update({
        "syntax": "PASS",
        "compile_without_execute": "PASS",
        "target_python": target_python,
        "host_python": HOST_PYTHON,
        "grammar_relation": grammar_relation(target_python),
    })
    return result
