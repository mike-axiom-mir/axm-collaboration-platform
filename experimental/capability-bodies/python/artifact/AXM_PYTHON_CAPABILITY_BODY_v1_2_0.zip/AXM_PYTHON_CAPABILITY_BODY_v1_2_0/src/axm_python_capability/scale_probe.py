from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

from .canonical import digest_object
from .evidence_cache import incremental_evidence_snapshot
from .repo_shards import plan_repository_shards
from .stream_index import stream_repository_index


def synthetic_python_files(count: int, package: str = "scale") -> list[dict[str, str]]:
    if count < 1:
        raise ValueError("count must be positive")
    files = []
    for i in range(count):
        name = f"m{i:05d}"
        if i == 0:
            source = f"VALUE = {i}\n\ndef value() -> int:\n    return VALUE\n"
        else:
            prev = f"m{i-1:05d}"
            source = (
                f"from .{prev} import value as previous_value\n\n"
                f"VALUE = {i}\n\n"
                "def value() -> int:\n"
                "    return previous_value() + 1\n"
            )
        files.append({
            "path": f"src/{package}/{name}.py",
            "source": source,
        })
    files.append({
        "path": f"tests/test_{package}.py",
        "source": (
            "import unittest\n"
            f"from {package}.m{count-1:05d} import value\n\n"
            "class ScaleTest(unittest.TestCase):\n"
            "    def test_value(self):\n"
            f"        self.assertEqual(value(), {count-1})\n"
        ),
    })
    return files


def run_scale_probe(
    *,
    count: int,
    target_python: str,
    package: str = "scale",
    shard_max_files: int = 250,
) -> dict[str, Any]:
    files = synthetic_python_files(count, package)
    first = incremental_evidence_snapshot(
        files, target_python, package
    )
    second = incremental_evidence_snapshot(
        files, target_python, package, first
    )
    shards = plan_repository_shards(
        files,
        target_python,
        package,
        max_files=shard_max_files,
        max_bytes=100 * 1024 * 1024,
    )

    # Exercise actual streaming filesystem index as a separate lane.
    with tempfile.TemporaryDirectory() as d:
        root = Path(d)
        for item in files:
            path = root / item["path"]
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(item["source"], encoding="utf-8", newline="\n")
        stream = stream_repository_index({
            "schema": "axm.python-stream-index-request.v1",
            "root": str(root),
            "authorities": ["READ_PROJECT_TREE"],
            "page_size": 200,
            "max_files": count + 100,
            "max_total_bytes": 512 * 1024 * 1024,
        })

    core = {
        "schema": "axm.python-scale-probe.v1",
        "generated_python_modules": count,
        "total_files": len(files),
        "first_pass_misses": first["cache_summary"]["miss_count"],
        "second_pass_hits": second["cache_summary"]["hit_count"],
        "second_pass_misses": second["cache_summary"]["miss_count"],
        "project_cache_reusable": second["project_derived_evidence_reusable"],
        "shard_count": len(shards["shards"]),
        "shard_plan_digest": shards["plan_digest"],
        "stream_file_count": stream["file_count"],
        "stream_page_count": len(stream["page_payloads"]),
        "stream_root_digest": stream["root_digest"],
        "status": (
            "PASS"
            if second["cache_summary"]["miss_count"] == 0
            and stream["file_count"] == len(files)
            else "FAIL"
        ),
        "truth_boundary": (
            "This is a deterministic functional scale probe, not a performance "
            "SLA. Wall-clock speed is intentionally not part of the receipt."
        ),
    }
    result = dict(core)
    result["probe_digest"] = digest_object(core)
    return result
