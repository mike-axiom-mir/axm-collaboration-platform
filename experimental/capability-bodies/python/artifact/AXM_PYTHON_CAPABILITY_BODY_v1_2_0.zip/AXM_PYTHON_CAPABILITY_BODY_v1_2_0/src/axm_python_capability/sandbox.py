from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from .canonical import digest_object


def _which(name: str) -> str | None:
    return shutil.which(name)


def _short_run(command: list[str], timeout: float = 5.0) -> dict[str, Any]:
    try:
        proc = subprocess.run(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            shell=False,
            env={
                "PATH": os.environ.get("PATH", ""),
                "LANG": os.environ.get("LANG", "C.UTF-8"),
                "LC_ALL": os.environ.get("LC_ALL", "C.UTF-8"),
                "PYTHONDONTWRITEBYTECODE": "1",
            },
        )
        return {
            "returncode": proc.returncode,
            "stdout": proc.stdout[:8192],
            "stderr": proc.stderr[:8192],
            "timeout": False,
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "returncode": None,
            "stdout": (exc.stdout or "")[:8192] if isinstance(exc.stdout, str) else "",
            "stderr": (exc.stderr or "")[:8192] if isinstance(exc.stderr, str) else "",
            "timeout": True,
        }


def probe_linux_unshare() -> dict[str, Any]:
    executable = _which("unshare")
    if not executable:
        return {
            "provider_id": "linux_unshare_net",
            "installed": False,
            "probe": "NOT_INSTALLED",
            "network_namespace": False,
            "filesystem_isolation": False,
            "process_namespace": False,
            "hard_test_ready": False,
        }

    if not sys.platform.startswith("linux"):
        return {
            "provider_id": "linux_unshare_net",
            "installed": True,
            "probe": "UNSUPPORTED_PLATFORM",
            "network_namespace": False,
            "filesystem_isolation": False,
            "process_namespace": False,
            "hard_test_ready": False,
        }

    host_ns = None
    try:
        host_ns = os.readlink("/proc/self/ns/net")
    except OSError:
        pass

    script = (
        "import json,os;"
        "print(json.dumps({'netns':os.readlink('/proc/self/ns/net')}))"
    )
    run = _short_run([
        executable,
        "--user",
        "--map-root-user",
        "--net",
        sys.executable,
        "-B",
        "-c",
        script,
    ])

    child_ns = None
    if run["returncode"] == 0:
        try:
            child_ns = json.loads(run["stdout"].strip())["netns"]
        except Exception:
            child_ns = None

    network_isolated = bool(host_ns and child_ns and host_ns != child_ns)
    return {
        "provider_id": "linux_unshare_net",
        "installed": True,
        "executable": executable,
        "probe": "PASS" if network_isolated else "FAIL",
        "host_network_namespace": host_ns,
        "child_network_namespace": child_ns,
        "network_namespace": network_isolated,
        "filesystem_isolation": False,
        "process_namespace": False,
        "hard_test_ready": False,
        "truth_boundary": (
            "Network namespace isolation only. Host filesystem remains visible; "
            "therefore this provider alone is not accepted for generated test execution."
        ),
    }


def probe_bubblewrap() -> dict[str, Any]:
    executable = _which("bwrap") or _which("bubblewrap")
    if not executable:
        return {
            "provider_id": "bubblewrap",
            "installed": False,
            "probe": "NOT_INSTALLED",
            "network_namespace": False,
            "filesystem_isolation": False,
            "process_namespace": False,
            "hard_test_ready": False,
        }

    version = _short_run([executable, "--version"])
    # A minimal mount/network/pid namespace probe. We do not execute user code.
    command = [
        executable,
        "--die-with-parent",
        "--new-session",
        "--unshare-all",
        "--cap-drop", "ALL",
        "--ro-bind", "/usr", "/usr",
        "--proc", "/proc",
        "--dev", "/dev",
        "--tmpfs", "/tmp",
        "--dir", "/work",
        "--chdir", "/work",
    ]

    for link, target in (
        ("/bin", "usr/bin"),
        ("/sbin", "usr/sbin"),
        ("/lib", "usr/lib"),
        ("/lib64", "usr/lib64"),
    ):
        if Path(link).is_symlink():
            command += ["--symlink", target, link]
        elif Path(link).exists():
            command += ["--ro-bind", link, link]

    if Path("/usr/local").exists():
        command += ["--ro-bind", "/usr/local", "/usr/local"]

    command += [
        sys.executable,
        "-B",
        "-c",
        "import os;print(os.readlink('/proc/self/ns/net'))",
    ]
    run = _short_run(command, timeout=8.0)

    ready = run["returncode"] == 0
    return {
        "provider_id": "bubblewrap",
        "installed": True,
        "executable": executable,
        "version": (version["stdout"] or version["stderr"]).strip()[:1000],
        "probe": "PASS" if ready else "FAIL",
        "probe_returncode": run["returncode"],
        "probe_stderr": run["stderr"],
        "network_namespace": ready,
        "filesystem_isolation": ready,
        "process_namespace": ready,
        "hard_test_ready": ready,
        "truth_boundary": (
            "Hard-ready only if the actual local probe succeeds. "
            "No provider is trusted merely because an executable exists."
        ),
    }


def sandbox_doctor() -> dict[str, Any]:
    providers = [
        probe_bubblewrap(),
        probe_linux_unshare(),
    ]
    hard = [x["provider_id"] for x in providers if x.get("hard_test_ready")]
    result = {
        "platform": sys.platform,
        "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "providers": providers,
        "hard_test_ready_providers": hard,
        "generated_test_execution_available": bool(hard),
    }
    result["evidence_digest"] = digest_object(result)
    return result
