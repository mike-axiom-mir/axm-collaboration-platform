from __future__ import annotations

import copy
import tempfile
from pathlib import Path
from typing import Any, Callable

from .authority import evaluate_authority
from .canonical import digest_object
from .evidence_cache import incremental_evidence_snapshot
from .evidence_store import load_snapshot, persist_snapshot
from .errors import CapabilityError, ContractError
from .reference_blueprint import assess_candidate_body, build_reference_blueprint
from .regression_ledger import append_regression_record, verify_regression_ledger
from .rollback import apply_rollback_packet, generate_rollback_packet


def _expect_exception(
    name: str,
    fn: Callable[[], Any],
    expected: tuple[type[BaseException], ...],
) -> dict[str, Any]:
    try:
        fn()
    except expected as exc:
        return {
            "case": name,
            "status": "PASS",
            "observed": type(exc).__name__,
            "reason": str(exc),
        }
    except Exception as exc:
        return {
            "case": name,
            "status": "FAIL_WRONG_EXCEPTION",
            "observed": type(exc).__name__,
            "reason": str(exc),
        }
    return {
        "case": name,
        "status": "FAIL_NO_EXCEPTION",
        "observed": None,
        "reason": None,
    }


def run_fault_campaign(target_python: str) -> dict[str, Any]:
    cases = []

    # Authority escalation.
    cases.append(_expect_exception(
        "authority_network_refusal",
        lambda: evaluate_authority(["READ_SPEC", "NETWORK"]),
        (CapabilityError,),
    ))
    cases.append(_expect_exception(
        "unknown_authority_refusal",
        lambda: evaluate_authority(["MAGIC_UNDECLARED_AUTHORITY"]),
        (CapabilityError,),
    ))

    # Cache snapshot tamper.
    files = [{"path": "a.py", "source": "x = 1\n"}]
    snapshot = incremental_evidence_snapshot(
        files, target_python, package=None
    )
    tampered_snapshot = copy.deepcopy(snapshot)
    tampered_snapshot["entries"][0]["analysis"]["syntax"] = "FAKE"
    cases.append(_expect_exception(
        "supplied_cache_snapshot_tamper",
        lambda: incremental_evidence_snapshot(
            files, target_python, None, tampered_snapshot
        ),
        (ContractError,),
    ))

    with tempfile.TemporaryDirectory() as d:
        receipt = persist_snapshot(d, snapshot)
        path = Path(receipt["path"])
        original = path.read_text(encoding="utf-8")
        path.write_text(
            original.replace('"syntax": "PASS"', '"syntax": "FAKE"', 1),
            encoding="utf-8",
        )
        cases.append(_expect_exception(
            "persisted_cache_snapshot_tamper",
            lambda: load_snapshot(path),
            (ContractError,),
        ))

    # Rollback packet tamper.
    before = [{"path": "a.py", "source": "x = 1\n"}]
    after = [{"path": "a.py", "source": "x = 2\n"}]
    rollback = generate_rollback_packet(
        change_id="fault",
        before_files=before,
        after_files=after,
    )
    tampered_rollback = copy.deepcopy(rollback)
    tampered_rollback["actions"][0]["source"] = "x = 999\n"
    cases.append(_expect_exception(
        "rollback_packet_tamper",
        lambda: apply_rollback_packet(after, tampered_rollback),
        (ContractError,),
    ))

    # Regression ledger chain tamper.
    ledger = append_regression_record(None, {"event": "a"})
    ledger = append_regression_record(ledger, {"event": "b"})
    tampered_ledger = copy.deepcopy(ledger)
    tampered_ledger["entries"][0]["record"]["event"] = "tampered"
    cases.append(_expect_exception(
        "regression_ledger_tamper",
        lambda: verify_regression_ledger(tampered_ledger),
        (ContractError,),
    ))

    # Root violation must dominate a complete layer score.
    blueprint = build_reference_blueprint()
    bad_candidate = {
        "body_id": "fault-candidate",
        "language": "example",
        "authority": {
            "automatic_install": False,
            "automatic_register": False,
            "automatic_promote": False,
            "automatic_canon": True,
        },
        "unsandboxed_execution_fallback": False,
        "layers": {
            str(layer["layer"]): {
                "contracts": layer["required_contracts"],
            }
            for layer in blueprint["layers"]
        },
    }
    assessment = assess_candidate_body(bad_candidate)
    cases.append({
        "case": "root_violation_overrides_100_percent_layers",
        "status": (
            "PASS"
            if assessment["status"] == "ROOT_VIOLATIONS"
            and assessment["maturity_percent"] == 100
            and assessment["root_violations"]
            else "FAIL"
        ),
        "observed": assessment["status"],
        "reason": assessment["root_violations"],
    })

    failures = [case for case in cases if case["status"] != "PASS"]
    core = {
        "schema": "axm.python-fault-campaign.v1",
        "target_python": target_python,
        "cases": cases,
        "summary": {
            "total": len(cases),
            "passed": len(cases) - len(failures),
            "failed": len(failures),
        },
        "status": "PASS" if not failures else "FAIL",
    }
    result = dict(core)
    result["campaign_digest"] = digest_object(core)
    return result
