from __future__ import annotations

from typing import Any

from .canonical import digest_object
from .errors import ContractError


def test_strength_passport(
    *,
    coverage_contexts: list[dict[str, Any]] | None = None,
    mutation_summary: dict[str, Any] | None = None,
    property_summary: dict[str, Any] | None = None,
    symbolic_summary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    contexts = coverage_contexts or []
    if not isinstance(contexts, list):
        raise ContractError("COVERAGE_CONTEXTS_NOT_LIST")

    observed_test_to_files: dict[str, set[str]] = {}
    for i, row in enumerate(contexts):
        if not isinstance(row, dict):
            raise ContractError(f"COVERAGE_CONTEXT_NOT_OBJECT:{i}")
        test = row.get("test")
        path = row.get("path")
        if not isinstance(test, str) or not test:
            raise ContractError(f"COVERAGE_TEST_REQUIRED:{i}")
        if not isinstance(path, str) or not path:
            raise ContractError(f"COVERAGE_PATH_REQUIRED:{i}")
        observed_test_to_files.setdefault(test, set()).add(path)

    mutation = mutation_summary or {}
    killed = int(mutation.get("killed", 0))
    survived = int(mutation.get("survived", 0))
    invalid = int(mutation.get("invalid", 0))
    total_valid = killed + survived
    mutation_score = (
        round((killed / total_valid) * 100, 2)
        if total_valid > 0 else None
    )

    property_summary = property_summary or {}
    symbolic_summary = symbolic_summary or {}

    weaknesses = []
    if survived > 0:
        weaknesses.append("SURVIVING_MUTANTS")
    if property_summary.get("counterexamples", 0):
        weaknesses.append("PROPERTY_COUNTEREXAMPLES")
    if symbolic_summary.get("behavior_differences", 0):
        weaknesses.append("SYMBOLIC_BEHAVIOR_DIFFERENCES")

    core = {
        "schema": "axm.python-test-strength-passport.v1",
        "observed_test_to_files": {
            test: sorted(paths)
            for test, paths in sorted(observed_test_to_files.items())
        },
        "mutation": {
            "killed": killed,
            "survived": survived,
            "invalid": invalid,
            "score_percent": mutation_score,
        },
        "property_testing": property_summary,
        "symbolic_behavior": symbolic_summary,
        "weaknesses": sorted(set(weaknesses)),
        "status": "WEAKNESSES_FOUND" if weaknesses else "NO_REPORTED_WEAKNESSES",
        "execution_evidence_only": True,
        "automatic_merge": False,
        "truth_boundary": (
            "Coverage contexts, mutation testing, property testing and symbolic "
            "comparison measure different things. No individual score is treated "
            "as proof of correctness; absence of reported weaknesses is not proof "
            "of correctness either."
        ),
    }
    result = dict(core)
    result["passport_digest"] = digest_object(core)
    return result
