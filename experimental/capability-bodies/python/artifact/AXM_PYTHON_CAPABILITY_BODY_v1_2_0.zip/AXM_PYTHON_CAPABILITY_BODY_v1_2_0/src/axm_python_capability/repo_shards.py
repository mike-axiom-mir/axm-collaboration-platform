from __future__ import annotations

from collections import defaultdict
from typing import Any

from .canonical import digest_object
from .project_graph import build_module_graph, strongly_connected_components


def _file_bytes(item: dict[str, str]) -> int:
    return len(item["source"].encode("utf-8"))


def plan_repository_shards(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
    *,
    max_files: int = 250,
    max_bytes: int = 4 * 1024 * 1024,
) -> dict[str, Any]:
    if max_files < 1 or max_bytes < 1:
        raise ValueError("max_files and max_bytes must be positive")

    py_files = [x for x in files if x["path"].endswith(".py")]
    other_files = [x for x in files if not x["path"].endswith(".py")]
    graph = build_module_graph(files, target_python, package)
    module_to_path = {m: p for p, m in graph["path_to_module"].items()}
    item_by_path = {x["path"]: x for x in files}

    # SCCs are atomic units: never split an import cycle across shards.
    units = []
    assigned_paths = set()
    for component in strongly_connected_components(graph):
        paths = sorted(
            module_to_path[m]
            for m in component
            if m in module_to_path
        )
        if not paths:
            continue
        assigned_paths.update(paths)
        units.append({
            "kind": "PYTHON_SCC",
            "paths": paths,
            "bytes": sum(_file_bytes(item_by_path[p]) for p in paths),
            "modules": component,
        })

    # Any Python file not represented (defensive) is its own unit.
    for item in sorted(py_files, key=lambda x: x["path"]):
        if item["path"] not in assigned_paths:
            units.append({
                "kind": "PYTHON_FILE",
                "paths": [item["path"]],
                "bytes": _file_bytes(item),
                "modules": [graph["path_to_module"].get(item["path"])],
            })

    # Resources are deterministic standalone units. Keeping them independent
    # avoids inventing runtime coupling that static Python imports don't prove.
    for item in sorted(other_files, key=lambda x: x["path"]):
        units.append({
            "kind": "RESOURCE",
            "paths": [item["path"]],
            "bytes": _file_bytes(item),
            "modules": [],
        })

    units.sort(key=lambda x: (x["paths"][0], x["kind"]))

    shards = []
    current = {"paths": [], "bytes": 0, "unit_count": 0}
    oversize_units = []

    def flush() -> None:
        nonlocal current
        if current["paths"]:
            shard_id = f"shard-{len(shards)+1:04d}"
            core = {
                "shard_id": shard_id,
                "paths": sorted(current["paths"]),
                "bytes": current["bytes"],
                "unit_count": current["unit_count"],
            }
            shards.append({**core, "digest": digest_object(core)})
        current = {"paths": [], "bytes": 0, "unit_count": 0}

    for unit in units:
        unit_files = len(unit["paths"])
        unit_bytes = unit["bytes"]
        if unit_files > max_files or unit_bytes > max_bytes:
            flush()
            core = {
                "shard_id": f"shard-{len(shards)+1:04d}",
                "paths": sorted(unit["paths"]),
                "bytes": unit_bytes,
                "unit_count": 1,
            }
            shards.append({**core, "digest": digest_object(core)})
            oversize_units.append({
                "paths": unit["paths"],
                "bytes": unit_bytes,
                "files": unit_files,
                "reason": "ATOMIC_UNIT_EXCEEDS_TARGET",
            })
            continue

        would_files = len(current["paths"]) + unit_files
        would_bytes = current["bytes"] + unit_bytes
        if current["paths"] and (
            would_files > max_files or would_bytes > max_bytes
        ):
            flush()

        current["paths"].extend(unit["paths"])
        current["bytes"] += unit_bytes
        current["unit_count"] += 1

    flush()

    path_to_shard = {}
    for shard in shards:
        for path in shard["paths"]:
            path_to_shard[path] = shard["shard_id"]

    cross_shard_edges = []
    for edge in graph["edges"]:
        source_path = module_to_path.get(edge["from"])
        target_path = module_to_path.get(edge["target"])
        if not source_path or not target_path:
            continue
        a = path_to_shard.get(source_path)
        b = path_to_shard.get(target_path)
        if a and b and a != b:
            cross_shard_edges.append({
                "from_module": edge["from"],
                "to_module": edge["target"],
                "from_shard": a,
                "to_shard": b,
            })

    result = {
        "schema": "axm.python-repository-shards.v1",
        "limits": {
            "max_files": max_files,
            "max_bytes": max_bytes,
        },
        "shards": shards,
        "oversize_atomic_units": oversize_units,
        "cross_shard_import_edges": sorted(
            cross_shard_edges,
            key=lambda x: (
                x["from_shard"], x["to_shard"],
                x["from_module"], x["to_module"],
            ),
        ),
        "truth_boundary": (
            "Shards are analysis/work partitions, not architectural boundaries. "
            "Import SCCs are kept atomic; other runtime coupling may cross shards."
        ),
    }
    result["plan_digest"] = digest_object(result)
    return result
