from __future__ import annotations

from typing import Any

from .analyze import analyze_source
from .compatibility import project_grammar_matrix


def _public_api_keys(path: str, analysis: dict[str, Any]) -> set[str]:
    out: set[str] = set()
    api = analysis.get("api", {})

    for fn in api.get("functions", []):
        if fn.get("public"):
            signature = ",".join(
                f"{p['kind']}:{p['name']}:{p.get('annotation')}:{p.get('default')}"
                for p in fn.get("parameters", [])
            )
            out.add(
                f"{path}|function|{fn['name']}|{signature}|returns={fn.get('returns')}|async={fn.get('async')}"
            )

    for cls in api.get("classes", []):
        if cls.get("public"):
            out.add(f"{path}|class|{cls['name']}|bases={','.join(str(x) for x in cls.get('bases', []))}")
            for method in cls.get("methods", []):
                if method.get("public"):
                    signature = ",".join(
                        f"{p['kind']}:{p['name']}:{p.get('annotation')}:{p.get('default')}"
                        for p in method.get("parameters", [])
                    )
                    out.add(
                        f"{path}|method|{cls['name']}.{method['name']}|{signature}|returns={method.get('returns')}|async={method.get('async')}"
                    )
    return out


def analyze_bundle(files: list[dict[str, str]], target_python: str) -> dict[str, Any]:
    py_files = [x for x in files if x["path"].endswith(".py")]
    api_keys: set[str] = set()
    import_roots: set[str] = set()
    effects: set[str] = set()
    branches = 0
    statements = 0
    functions = 0
    classes = 0

    per_file = []
    for item in sorted(py_files, key=lambda x: x["path"]):
        analysis = analyze_source(item["source"], item["path"], target_python)
        api_keys.update(_public_api_keys(item["path"], analysis))
        for imp in analysis.get("imports", []):
            if imp:
                import_roots.add(imp.split(".", 1)[0])
        effects.update(analysis.get("effect_signals", []))
        comp = analysis.get("complexity", {})
        branches += int(comp.get("branch_points", 0))
        statements += int(comp.get("statement_count", 0))
        functions += int(comp.get("function_count", 0))
        classes += int(comp.get("class_count", 0))
        per_file.append({
            "path": item["path"],
            "analysis": analysis,
        })

    grammar = project_grammar_matrix(py_files)

    return {
        "files": sorted(x["path"] for x in files),
        "python_files": sorted(x["path"] for x in py_files),
        "public_api_keys": sorted(api_keys),
        "import_roots": sorted(import_roots),
        "effect_signals": sorted(effects),
        "metrics": {
            "branch_points": branches,
            "statement_count": statements,
            "function_count": functions,
            "class_count": classes,
        },
        "compatibility": grammar,
        "per_file": per_file,
    }


def diff_bundle(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_files = set(before["files"])
    after_files = set(after["files"])
    before_api = set(before["public_api_keys"])
    after_api = set(after["public_api_keys"])
    before_imports = set(before["import_roots"])
    after_imports = set(after["import_roots"])
    before_effects = set(before["effect_signals"])
    after_effects = set(after["effect_signals"])

    bm = before["metrics"]
    am = after["metrics"]

    return {
        "files_added": sorted(after_files - before_files),
        "files_removed": sorted(before_files - after_files),
        "public_api_added": sorted(after_api - before_api),
        "public_api_removed_or_changed": sorted(before_api - after_api),
        "import_roots_added": sorted(after_imports - before_imports),
        "import_roots_removed": sorted(before_imports - after_imports),
        "effect_signals_added": sorted(after_effects - before_effects),
        "effect_signals_removed": sorted(before_effects - after_effects),
        "metric_delta": {
            key: int(am.get(key, 0)) - int(bm.get(key, 0))
            for key in sorted(set(bm) | set(am))
        },
        "minimum_grammar_before": before["compatibility"]["project_minimum_tracked_grammar"],
        "minimum_grammar_after": after["compatibility"]["project_minimum_tracked_grammar"],
    }


def enforce_guards(impact: dict[str, Any], guards: dict[str, Any]) -> list[str]:
    violations: list[str] = []

    if guards.get("preserve_public_api", False) and impact["public_api_removed_or_changed"]:
        violations.append("PUBLIC_API_CHANGED")

    if guards.get("no_new_import_roots", False) and impact["import_roots_added"]:
        violations.append("NEW_IMPORT_ROOTS")

    if guards.get("no_new_effect_signals", False) and impact["effect_signals_added"]:
        violations.append("NEW_EFFECT_SIGNALS")

    if guards.get("no_file_deletions", False) and impact["files_removed"]:
        violations.append("FILES_REMOVED")

    if guards.get("preserve_minimum_python", False):
        before_minor = int(impact["minimum_grammar_before"].split(".")[1])
        after_minor = int(impact["minimum_grammar_after"].split(".")[1])
        if after_minor > before_minor:
            violations.append("MINIMUM_PYTHON_INCREASED")

    if "max_branch_delta" in guards:
        limit = int(guards["max_branch_delta"])
        if impact["metric_delta"]["branch_points"] > limit:
            violations.append("BRANCH_DELTA_EXCEEDED")

    return violations
