from __future__ import annotations

RECIPES = {
    "dataclass_model": '''from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class Item:
    name: str
    value: int
''',
    "async_worker": '''import asyncio

async def worker(queue: asyncio.Queue[str]) -> None:
    while True:
        item = await queue.get()
        try:
            _ = item
        finally:
            queue.task_done()
''',
    "context_manager": '''from contextlib import contextmanager
from collections.abc import Iterator

@contextmanager
def managed_value(value: str) -> Iterator[str]:
    try:
        yield value
    finally:
        pass
''',
    "argparse_cli": '''import argparse

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("value")
    return parser

def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    print(args.value)
    return 0
''',
    "protocol_adapter": '''from typing import Protocol

class Reader(Protocol):
    def read(self) -> str: ...

class StaticReader:
    def __init__(self, value: str) -> None:
        self.value = value

    def read(self) -> str:
        return self.value
''',
    "enum_state": '''from enum import Enum, auto

class State(Enum):
    READY = auto()
    RUNNING = auto()
    DONE = auto()
''',
    "generator_pipeline": '''from collections.abc import Iterable, Iterator

def cleaned(values: Iterable[str]) -> Iterator[str]:
    for value in values:
        item = value.strip()
        if item:
            yield item
''',
    "unittest_case": '''import unittest

class ExampleTests(unittest.TestCase):
    def test_example(self) -> None:
        self.assertEqual(2 + 2, 4)
''',
}


def get_recipe(name: str) -> str:
    try:
        return RECIPES[name]
    except KeyError as exc:
        raise KeyError(f"unknown recipe: {name}") from exc
