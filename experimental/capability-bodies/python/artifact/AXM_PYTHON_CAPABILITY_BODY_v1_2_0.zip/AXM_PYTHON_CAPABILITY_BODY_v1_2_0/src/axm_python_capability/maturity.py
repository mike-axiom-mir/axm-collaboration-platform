from __future__ import annotations

from typing import Any

from .canonical import digest_object
from .reference_blueprint import build_reference_blueprint
from .sandbox import sandbox_doctor


def build_maturity_passport(
    *,
    self_audit: dict[str, Any],
    test_count: int,
    feature_count: int,
    schema_count: int,
    known_truth_boundaries: list[str] | None = None,
) -> dict[str, Any]:
    blueprint = build_reference_blueprint()
    doctor = sandbox_doctor()

    holds = []
    if self_audit.get("status") != "PASS":
        holds.append("SELF_AUDIT_FAILURE")
    if not doctor.get("generated_test_execution_available", False):
        holds.append("NO_VERIFIED_HARD_SANDBOX_ON_THIS_HOST")

    core = {
        "schema": "axm.python-maturity-passport.v1",
        "reference_blueprint_digest": blueprint["blueprint_digest"],
        "self_audit_digest": self_audit.get("audit_digest"),
        "self_audit_status": self_audit.get("status"),
        "test_count": int(test_count),
        "feature_count": int(feature_count),
        "schema_count": int(schema_count),
        "sandbox_host_evidence": doctor,
        "known_holds": sorted(holds),
        "known_truth_boundaries": sorted(set(known_truth_boundaries or [])),
        "maturity_state": (
            "REFERENCE_FREEZE_CANDIDATE"
            if self_audit.get("status") == "PASS"
            else "HOLD_SELF_AUDIT"
        ),
        "automatic_canon": False,
        "automatic_promotion": False,
        "automatic_cross_language_install": False,
        "truth_boundary": (
            "Reference freeze means the donor architecture is coherent and "
            "self-audited. It does not make every language-specific problem solved."
        ),
    }
    result = dict(core)
    result["passport_digest"] = digest_object(core)
    return result
