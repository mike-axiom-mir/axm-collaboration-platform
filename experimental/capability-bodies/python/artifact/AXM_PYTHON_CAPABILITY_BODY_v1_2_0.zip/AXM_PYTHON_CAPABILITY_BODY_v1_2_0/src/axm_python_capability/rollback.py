from __future__ import annotations

import hashlib
from typing import Any

from .canonical import digest_object
from .errors import ContractError


def _sha(source: str) -> str:
    return "sha256:" + hashlib.sha256(source.encode("utf-8")).hexdigest()


def _map(files: list[dict[str, str]]) -> dict[str, str]:
    out = {}
    for item in files:
        path = item["path"]
        if path in out:
            raise ContractError(f"duplicate path: {path}")
        out[path] = item["source"]
    return out


def generate_rollback_packet(
    *,
    change_id: str,
    before_files: list[dict[str, str]],
    after_files: list[dict[str, str]],
) -> dict[str, Any]:
    before = _map(before_files)
    after = _map(after_files)
    actions = []

    for path in sorted(set(before) | set(after)):
        b = before.get(path)
        a = after.get(path)
        if b == a:
            continue

        if b is None:
            actions.append({
                "action": "DELETE_CREATED_FILE",
                "path": path,
                "expected_current_sha256": _sha(a),
            })
        elif a is None:
            actions.append({
                "action": "RESTORE_DELETED_FILE",
                "path": path,
                "source": b,
                "source_sha256": _sha(b),
                "expected_current_absent": True,
            })
        else:
            actions.append({
                "action": "RESTORE_MODIFIED_FILE",
                "path": path,
                "source": b,
                "source_sha256": _sha(b),
                "expected_current_sha256": _sha(a),
            })

    core = {
        "schema": "axm.python-rollback-packet.v1",
        "change_id": change_id,
        "before_digest": digest_object([
            {"path": p, "sha256": _sha(before[p])} for p in sorted(before)
        ]),
        "after_digest": digest_object([
            {"path": p, "sha256": _sha(after[p])} for p in sorted(after)
        ]),
        "actions": actions,
        "automatic_apply": False,
    }
    packet = dict(core)
    packet["packet_digest"] = digest_object(core)
    return packet


def apply_rollback_packet(
    current_files: list[dict[str, str]],
    packet: dict[str, Any],
) -> dict[str, Any]:
    if not isinstance(packet, dict):
        raise ContractError("ROLLBACK_PACKET_MUST_BE_OBJECT")
    supplied = packet.get("packet_digest")
    if not isinstance(supplied, str):
        raise ContractError("ROLLBACK_PACKET_DIGEST_REQUIRED")
    packet_core = dict(packet)
    packet_core.pop("packet_digest", None)
    if digest_object(packet_core) != supplied:
        raise ContractError("ROLLBACK_PACKET_DIGEST_MISMATCH")

    current = _map(current_files)

    for action in packet.get("actions", []):
        path = action["path"]
        kind = action["action"]

        if kind == "DELETE_CREATED_FILE":
            if path not in current:
                raise ContractError(f"ROLLBACK_PRECONDITION_MISSING:{path}")
            if _sha(current[path]) != action["expected_current_sha256"]:
                raise ContractError(f"ROLLBACK_HASH_MISMATCH:{path}")
            del current[path]

        elif kind == "RESTORE_DELETED_FILE":
            if path in current:
                raise ContractError(f"ROLLBACK_EXPECTED_ABSENT:{path}")
            source = action["source"]
            if _sha(source) != action["source_sha256"]:
                raise ContractError(f"ROLLBACK_PACKET_SOURCE_MISMATCH:{path}")
            current[path] = source

        elif kind == "RESTORE_MODIFIED_FILE":
            if path not in current:
                raise ContractError(f"ROLLBACK_PRECONDITION_MISSING:{path}")
            if _sha(current[path]) != action["expected_current_sha256"]:
                raise ContractError(f"ROLLBACK_HASH_MISMATCH:{path}")
            source = action["source"]
            if _sha(source) != action["source_sha256"]:
                raise ContractError(f"ROLLBACK_PACKET_SOURCE_MISMATCH:{path}")
            current[path] = source

        else:
            raise ContractError(f"UNKNOWN_ROLLBACK_ACTION:{kind}")

    files = [
        {"path": path, "source": current[path]}
        for path in sorted(current)
    ]
    result = {
        "schema": "axm.python-rollback-result.v1",
        "change_id": packet.get("change_id"),
        "files": files,
        "result_digest": digest_object([
            {"path": x["path"], "sha256": _sha(x["source"])}
            for x in files
        ]),
        "status": "ROLLED_BACK_CANDIDATE",
    }
    return result
