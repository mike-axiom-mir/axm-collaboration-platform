from __future__ import annotations

import hashlib
from typing import Any

from .analyze import analyze_source
from .canonical import digest_object
from .constants import CAPABILITY_ID, CAPABILITY_VERSION
from .project_graph import module_name_from_path
from .errors import ContractError


def source_digest(source: str) -> str:
    return "sha256:" + hashlib.sha256(source.encode("utf-8")).hexdigest()


def evidence_key(
    *,
    path: str,
    source: str,
    target_python: str,
    package: str | None,
) -> str:
    return digest_object({
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "kind": "python_file_static_evidence",
        "path": path,
        "source_digest": source_digest(source),
        "target_python": target_python,
        "package": package,
    })


def incremental_evidence_snapshot(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
    previous: dict[str, Any] | None = None,
) -> dict[str, Any]:
    previous = previous or {}
    if previous:
        supplied = previous.get("snapshot_digest")
        if not isinstance(supplied, str):
            raise ContractError("PREVIOUS_SNAPSHOT_DIGEST_REQUIRED")
        core = dict(previous)
        core.pop("snapshot_digest", None)
        if digest_object(core) != supplied:
            raise ContractError("PREVIOUS_SNAPSHOT_DIGEST_MISMATCH")

    previous_entries = {
        item["path"]: item
        for item in previous.get("entries", [])
        if isinstance(item, dict) and "path" in item
    }

    entries = []
    hits = []
    misses = []

    for item in sorted(files, key=lambda x: x["path"]):
        path = item["path"]
        source = item["source"]
        key = evidence_key(
            path=path,
            source=source,
            target_python=target_python,
            package=package,
        )
        old = previous_entries.get(path)

        if (
            old is not None
            and old.get("evidence_key") == key
            and old.get("analysis") is not None
        ):
            analysis = old["analysis"]
            state = "HIT"
            hits.append(path)
        else:
            if path.endswith(".py"):
                analysis = analyze_source(source, path, target_python)
            else:
                analysis = {
                    "kind": "NON_PYTHON_RESOURCE",
                    "bytes": len(source.encode("utf-8")),
                }
            state = "MISS"
            misses.append(path)

        entries.append({
            "path": path,
            "module": (
                module_name_from_path(path, package)
                if path.endswith(".py")
                else None
            ),
            "source_digest": source_digest(source),
            "evidence_key": key,
            "cache_state": state,
            "analysis": analysis,
        })

    current_paths = {x["path"] for x in entries}
    removed = sorted(set(previous_entries) - current_paths)
    changed = bool(misses or removed)

    snapshot_core = {
        "schema": "axm.python-incremental-evidence.v1",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "target_python": target_python,
        "package": package,
        "entries": entries,
        "cache_summary": {
            "hits": sorted(hits),
            "misses": sorted(misses),
            "removed": removed,
            "hit_count": len(hits),
            "miss_count": len(misses),
            "removed_count": len(removed),
        },
        "project_derived_evidence_reusable": not changed,
        "truth_boundary": (
            "A file-level cache HIT means the exact content-addressed static "
            "evidence is reusable for this capability version and target. "
            "Project-level graph evidence is invalidated by any file change."
        ),
    }
    snapshot = dict(snapshot_core)
    snapshot["snapshot_digest"] = digest_object(snapshot_core)
    return snapshot
