from __future__ import annotations

from collections import defaultdict
from typing import Any

from .canonical import digest_object
from .errors import ContractError


KNOWN_ENGINES = {"pyright", "pyrefly", "mypy", "ty"}


def normalize_semantic_evidence(
    engine: str,
    evidence: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    engine = engine.lower()
    if engine not in KNOWN_ENGINES:
        raise ContractError(f"UNKNOWN_SEMANTIC_ENGINE:{engine}")
    if not isinstance(evidence, list):
        raise ContractError("SEMANTIC_EVIDENCE_NOT_LIST")

    rows = []
    for i, item in enumerate(evidence):
        if not isinstance(item, dict):
            raise ContractError(f"SEMANTIC_ITEM_NOT_OBJECT:{engine}:{i}")
        path = item.get("path")
        line = item.get("line")
        expression = item.get("expression")
        semantic_type = item.get("type")
        if not isinstance(path, str) or not path:
            raise ContractError(f"SEMANTIC_PATH_REQUIRED:{engine}:{i}")
        if not isinstance(line, int) or line < 1:
            raise ContractError(f"SEMANTIC_LINE_REQUIRED:{engine}:{i}")
        if not isinstance(expression, str) or not expression:
            raise ContractError(f"SEMANTIC_EXPRESSION_REQUIRED:{engine}:{i}")
        if not isinstance(semantic_type, str) or not semantic_type:
            raise ContractError(f"SEMANTIC_TYPE_REQUIRED:{engine}:{i}")

        rows.append({
            "engine": engine,
            "path": path,
            "line": line,
            "column": int(item.get("column", 0)),
            "expression": expression,
            "type": semantic_type.strip(),
            "kind": str(item.get("kind", "computed")),
            "engine_version": item.get("engine_version"),
        })
    return sorted(
        rows,
        key=lambda x: (
            x["path"], x["line"], x["column"],
            x["expression"], x["kind"], x["type"],
        ),
    )


def semantic_consensus_passport(
    evidence_by_engine: dict[str, list[dict[str, Any]]],
) -> dict[str, Any]:
    normalized = {}
    points: dict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)

    for engine in sorted(evidence_by_engine):
        rows = normalize_semantic_evidence(
            engine,
            evidence_by_engine[engine],
        )
        normalized[engine] = rows
        for row in rows:
            key = (
                row["path"],
                row["line"],
                row["column"],
                row["expression"],
                row["kind"],
            )
            points[key].append(row)

    comparisons = []
    agreements = 0
    disagreements = 0
    single_engine = 0

    for key in sorted(points):
        rows = points[key]
        types = sorted(set(row["type"] for row in rows))
        engines = sorted(row["engine"] for row in rows)
        if len(rows) == 1:
            status = "SINGLE_ENGINE_EVIDENCE"
            single_engine += 1
        elif len(types) == 1:
            status = "CONSENSUS"
            agreements += 1
        else:
            status = "DISAGREEMENT"
            disagreements += 1

        comparisons.append({
            "path": key[0],
            "line": key[1],
            "column": key[2],
            "expression": key[3],
            "kind": key[4],
            "engines": engines,
            "types": {
                row["engine"]: row["type"]
                for row in sorted(rows, key=lambda x: x["engine"])
            },
            "status": status,
        })

    core = {
        "schema": "axm.python-semantic-consensus.v1",
        "engines": sorted(normalized),
        "normalized_evidence": normalized,
        "comparisons": comparisons,
        "summary": {
            "points": len(comparisons),
            "consensus": agreements,
            "disagreements": disagreements,
            "single_engine": single_engine,
        },
        "status": (
            "DISAGREEMENTS_PRESENT"
            if disagreements
            else "CONSENSUS_OR_SINGLE_ENGINE"
        ),
        "truth_boundary": (
            "Type-engine agreement strengthens evidence but is not language truth. "
            "Disagreement is retained as uncertainty rather than voted away."
        ),
    }
    result = dict(core)
    result["passport_digest"] = digest_object(core)
    return result
