from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .adapters import AdapterSpec, BUILTIN_ADAPTERS
from .authority import evaluate_authority
from .canonical import digest_object, stable_id
from .constants import ADAPTER_SCHEMA_V1, CAPABILITY_ID, CAPABILITY_VERSION
from .errors import AuthorityError, ContractError


IGNORED_DIR_NAMES = frozenset({
    ".git", ".hg", ".svn",
    ".venv", "venv", "env",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "node_modules", ".tox", ".nox",
})


@dataclass(frozen=True)
class TreeStats:
    files: int
    bytes: int
    digest: str


def _sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _tree_entries(root: Path, *, max_files: int, max_total_bytes: int) -> list[dict[str, Any]]:
    root = root.resolve()
    if not root.is_dir():
        raise ContractError(f"PROJECT_ROOT_NOT_DIRECTORY:{root}")

    entries = []
    total = 0

    for path in sorted(root.rglob("*"), key=lambda p: p.as_posix()):
        rel = path.relative_to(root)
        if any(part in IGNORED_DIR_NAMES for part in rel.parts):
            continue
        if path.is_symlink():
            raise ContractError(f"SYMLINK_REFUSED:{rel.as_posix()}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise ContractError(f"SPECIAL_FILE_REFUSED:{rel.as_posix()}")

        size = path.stat().st_size
        total += size
        if len(entries) + 1 > max_files:
            raise ContractError(f"PROJECT_FILE_LIMIT:{max_files}")
        if total > max_total_bytes:
            raise ContractError(f"PROJECT_BYTE_LIMIT:{max_total_bytes}")

        entries.append({
            "path": rel.as_posix(),
            "bytes": size,
            "sha256": _sha_file(path),
        })

    return entries


def tree_stats(root: Path, *, max_files: int, max_total_bytes: int) -> TreeStats:
    entries = _tree_entries(root, max_files=max_files, max_total_bytes=max_total_bytes)
    return TreeStats(
        files=len(entries),
        bytes=sum(x["bytes"] for x in entries),
        digest=digest_object(entries),
    )


def _copy_shadow(source: Path, target: Path) -> None:
    def ignore(directory: str, names: list[str]) -> set[str]:
        return {name for name in names if name in IGNORED_DIR_NAMES}

    shutil.copytree(source, target, ignore=ignore, symlinks=False)


def _sanitized_env(work_root: Path) -> dict[str, str]:
    env: dict[str, str] = {}
    for key in ("PATH", "PATHEXT", "SYSTEMROOT", "WINDIR", "LANG", "LC_ALL"):
        value = os.environ.get(key)
        if value:
            env[key] = value

    home = work_root / "home"
    tmp = work_root / "tmp"
    home.mkdir(parents=True, exist_ok=True)
    tmp.mkdir(parents=True, exist_ok=True)

    env.update({
        "HOME": str(home),
        "USERPROFILE": str(home),
        "TMPDIR": str(tmp),
        "TMP": str(tmp),
        "TEMP": str(tmp),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PIP_DISABLE_PIP_VERSION_CHECK": "1",
        "NO_PROXY": "*",
        "no_proxy": "*",
        "CI": "1",
    })
    return env


def _hash_executable(path: str) -> str | None:
    p = Path(path)
    try:
        if p.is_file():
            return "sha256:" + _sha_file(p)
    except OSError:
        pass
    return None


def _discover_executable(spec: AdapterSpec) -> str | None:
    for candidate in spec.executables:
        # Absolute interpreter path support.
        p = Path(candidate)
        if p.is_absolute() and p.exists():
            return str(p)
        found = shutil.which(candidate)
        if found:
            return found
    return None


def _bounded_process(
    command: list[str],
    *,
    cwd: Path,
    env: dict[str, str],
    timeout_seconds: float,
    max_output_bytes: int,
) -> dict[str, Any]:
    started = time.monotonic()
    proc = subprocess.Popen(
        command,
        cwd=str(cwd),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=False,
    )

    lock = threading.Lock()
    total = 0
    output_limit = threading.Event()
    stdout_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []

    def reader(stream, bucket: list[bytes]) -> None:
        nonlocal total
        try:
            while True:
                chunk = stream.read(4096)
                if not chunk:
                    return
                with lock:
                    remaining = max_output_bytes - total
                    if remaining > 0:
                        kept = chunk[:remaining]
                        bucket.append(kept)
                        total += len(kept)
                    if len(chunk) > remaining:
                        output_limit.set()
                if output_limit.is_set():
                    try:
                        proc.kill()
                    except OSError:
                        pass
                    return
        finally:
            try:
                stream.close()
            except Exception:
                pass

    t_out = threading.Thread(target=reader, args=(proc.stdout, stdout_chunks), daemon=True)
    t_err = threading.Thread(target=reader, args=(proc.stderr, stderr_chunks), daemon=True)
    t_out.start()
    t_err.start()

    timed_out = False
    try:
        proc.wait(timeout=timeout_seconds)
    except subprocess.TimeoutExpired:
        timed_out = True
        proc.kill()
        proc.wait()

    t_out.join(timeout=1)
    t_err.join(timeout=1)

    duration_ms = int((time.monotonic() - started) * 1000)
    stdout = b"".join(stdout_chunks).decode("utf-8", errors="replace")
    stderr = b"".join(stderr_chunks).decode("utf-8", errors="replace")

    return {
        "returncode": proc.returncode,
        "stdout": stdout,
        "stderr": stderr,
        "recorded_output_bytes": len(stdout.encode("utf-8")) + len(stderr.encode("utf-8")),
        "output_limit_exceeded": output_limit.is_set(),
        "timed_out": timed_out,
        "duration_ms": duration_ms,
    }


def _version_probe(
    spec: AdapterSpec,
    executable: str,
    *,
    cwd: Path,
    env: dict[str, str],
    offline: bool,
) -> str | None:
    if offline and not spec.version_probe_allowed_offline:
        return None
    result = _bounded_process(
        [executable, *spec.version_args],
        cwd=cwd,
        env=env,
        timeout_seconds=5.0,
        max_output_bytes=16_384,
    )
    if result["timed_out"] or result["output_limit_exceeded"]:
        return None
    text = (result["stdout"] or result["stderr"]).strip()
    return text[:1000] if text else None


def _policy_status(spec: AdapterSpec, *, allow_network: bool) -> str | None:
    if spec.executes_project_code:
        return "REFUSED_EXECUTES_PROJECT_CODE"
    if spec.source_write_intent:
        return "REFUSED_SOURCE_WRITE_INTENT"

    if spec.network_behavior == "network_normally_required" and not allow_network:
        return "REFUSED_NETWORK_POLICY"
    if spec.network_behavior == "bootstrap_uncertain" and not allow_network:
        return "REFUSED_UNCERTAIN_BOOTSTRAP_POLICY"
    return None


def _run_adapter_request(
    raw: dict[str, Any],
    registry: Mapping[str, AdapterSpec],
) -> dict[str, Any]:
    if not isinstance(raw, dict) or raw.get("schema") != ADAPTER_SCHEMA_V1:
        raise ContractError(f"schema must be {ADAPTER_SCHEMA_V1}")

    request_id = raw.get("request_id")
    if not isinstance(request_id, str) or not request_id.strip():
        raise ContractError("request_id must be non-empty")

    project_root = Path(str(raw.get("project_root", ""))).expanduser().resolve()
    requested = raw.get("adapters")
    if not isinstance(requested, list) or not requested:
        raise ContractError("adapters must be a non-empty list")
    if not all(isinstance(x, str) for x in requested):
        raise ContractError("adapters must contain strings")

    authorities = raw.get("authorities", [])
    if not isinstance(authorities, list):
        raise ContractError("authorities must be a list")
    decision = evaluate_authority(authorities)
    if "RUN_STATIC_ANALYZER" not in decision.effective:
        raise AuthorityError("RUN_STATIC_ANALYZER_REQUIRED")

    policy = raw.get("policy", {})
    if not isinstance(policy, dict):
        raise ContractError("policy must be an object")

    allow_network = bool(policy.get("allow_network", False))
    if allow_network:
        # Network is intentionally not part of this capability's current authority ceiling.
        raise AuthorityError("NETWORK_NOT_AUTHORIZED_BY_CAPABILITY")

    timeout_seconds = float(policy.get("timeout_seconds", 30))
    max_output_bytes = int(policy.get("max_output_bytes", 512_000))
    max_files = int(policy.get("max_files", 5_000))
    max_total_bytes = int(policy.get("max_total_bytes", 100 * 1024 * 1024))

    if not (0.1 <= timeout_seconds <= 300):
        raise ContractError("timeout_seconds must be 0.1..300")
    if not (1024 <= max_output_bytes <= 10 * 1024 * 1024):
        raise ContractError("max_output_bytes out of bounds")
    if not (1 <= max_files <= 100_000):
        raise ContractError("max_files out of bounds")
    if not (1024 <= max_total_bytes <= 2 * 1024 * 1024 * 1024):
        raise ContractError("max_total_bytes out of bounds")

    unknown = sorted(set(requested) - set(registry))
    if unknown:
        raise ContractError("UNKNOWN_ADAPTERS:" + ",".join(unknown))

    before = tree_stats(
        project_root,
        max_files=max_files,
        max_total_bytes=max_total_bytes,
    )

    normalized = {
        "schema": ADAPTER_SCHEMA_V1,
        "request_id": request_id,
        "project_digest": before.digest,
        "adapters": sorted(set(requested)),
        "authorities": sorted(set(str(x) for x in authorities)),
        "policy": {
            "allow_network": False,
            "timeout_seconds": timeout_seconds,
            "max_output_bytes": max_output_bytes,
            "max_files": max_files,
            "max_total_bytes": max_total_bytes,
        },
    }
    run_id = stable_id(
        "pyverify",
        {
            "capability": CAPABILITY_ID,
            "version": CAPABILITY_VERSION,
            "request": normalized,
        },
    )

    results = []
    with tempfile.TemporaryDirectory(prefix="axm-python-adapter-") as tmp_name:
        work_root = Path(tmp_name)
        shadow = work_root / "project"
        _copy_shadow(project_root, shadow)
        shadow_before = tree_stats(
            shadow,
            max_files=max_files,
            max_total_bytes=max_total_bytes,
        )
        env = _sanitized_env(work_root)

        for adapter_id in sorted(set(requested)):
            spec = registry[adapter_id]
            policy_refusal = _policy_status(spec, allow_network=False)
            if policy_refusal:
                results.append({
                    "adapter_id": adapter_id,
                    "category": spec.category,
                    "status": policy_refusal,
                    "executed": False,
                    "network_behavior": spec.network_behavior,
                    "source_write_intent": spec.source_write_intent,
                    "executes_project_code": spec.executes_project_code,
                })
                continue

            executable = _discover_executable(spec)
            if not executable:
                results.append({
                    "adapter_id": adapter_id,
                    "category": spec.category,
                    "status": "NOT_INSTALLED",
                    "executed": False,
                    "network_behavior": spec.network_behavior,
                })
                continue

            version = _version_probe(
                spec,
                executable,
                cwd=shadow,
                env=env,
                offline=True,
            )

            run = _bounded_process(
                [executable, *spec.args],
                cwd=shadow,
                env=env,
                timeout_seconds=timeout_seconds,
                max_output_bytes=max_output_bytes,
            )

            if run["timed_out"]:
                status = "TIMEOUT"
            elif run["output_limit_exceeded"]:
                status = "OUTPUT_LIMIT"
            elif run["returncode"] == 0:
                status = "PASS"
            elif run["returncode"] in spec.diagnostic_exit_codes:
                status = "FINDINGS"
            else:
                status = "TOOL_ERROR"

            results.append({
                "adapter_id": adapter_id,
                "category": spec.category,
                "status": status,
                "executed": True,
                "executable": executable,
                "executable_sha256": _hash_executable(executable),
                "version": version,
                "command": [Path(executable).name, *spec.args],
                "returncode": run["returncode"],
                "stdout": run["stdout"],
                "stderr": run["stderr"],
                "recorded_output_bytes": run["recorded_output_bytes"],
                "output_limit_exceeded": run["output_limit_exceeded"],
                "timed_out": run["timed_out"],
                "duration_ms": run["duration_ms"],
                "network_behavior": spec.network_behavior,
                "source_write_intent": spec.source_write_intent,
                "executes_project_code": spec.executes_project_code,
            })

        shadow_after = tree_stats(
            shadow,
            max_files=max_files * 2,
            max_total_bytes=max_total_bytes * 2,
        )

    after = tree_stats(
        project_root,
        max_files=max_files,
        max_total_bytes=max_total_bytes,
    )

    source_unchanged = before.digest == after.digest
    overall = "PASS"
    if not source_unchanged:
        overall = "HOLD_SOURCE_CHANGED"
    elif any(x["status"] in {"TIMEOUT", "OUTPUT_LIMIT", "TOOL_ERROR"} for x in results):
        overall = "HOLD_TOOL_FAILURES"
    elif any(x["status"] == "FINDINGS" for x in results):
        overall = "FINDINGS"
    elif all(x["status"].startswith("REFUSED_") or x["status"] == "NOT_INSTALLED" for x in results):
        overall = "NO_ADAPTER_EXECUTED"

    receipt_core = {
        "schema": "axm.python-adapter-receipt.v1",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "run_id": run_id,
        "request_id": request_id,
        "project_before": before.__dict__,
        "project_after": after.__dict__,
        "source_unchanged": source_unchanged,
        "shadow_before": shadow_before.__dict__,
        "shadow_after": shadow_after.__dict__,
        "shadow_mutated": shadow_before.digest != shadow_after.digest,
        "results": results,
        "overall_status": overall,
        "shell_used": False,
        "network_authorized": False,
        "network_enforcement": "POLICY_AND_TOOL_CLASSIFICATION_NOT_KERNEL_SANDBOX",
        "project_code_execution_authorized": False,
        "packages_installed": False,
        "registered": False,
        "promoted": False,
        "canon": False,
        "status": "DETACHED_ADAPTER_EVIDENCE",
    }
    receipt = dict(receipt_core)
    receipt["receipt_digest"] = digest_object(receipt_core)
    return receipt


def run_adapter_request(raw: dict[str, Any]) -> dict[str, Any]:
    return _run_adapter_request(raw, BUILTIN_ADAPTERS)
