from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from .canonical import digest_object
from .errors import ContractError


def validate_snapshot(snapshot: dict[str, Any]) -> None:
    if not isinstance(snapshot, dict):
        raise ContractError("SNAPSHOT_MUST_BE_OBJECT")
    supplied = snapshot.get("snapshot_digest")
    if not isinstance(supplied, str):
        raise ContractError("SNAPSHOT_DIGEST_REQUIRED")
    core = dict(snapshot)
    core.pop("snapshot_digest", None)
    if digest_object(core) != supplied:
        raise ContractError("SNAPSHOT_DIGEST_MISMATCH")


def persist_snapshot(
    store_dir: str | Path,
    snapshot: dict[str, Any],
) -> dict[str, Any]:
    validate_snapshot(snapshot)
    root = Path(store_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)

    digest = snapshot["snapshot_digest"]
    hex_digest = digest.split(":", 1)[-1]
    if not hex_digest or any(c not in "0123456789abcdef" for c in hex_digest.lower()):
        raise ContractError("INVALID_SNAPSHOT_DIGEST_FORMAT")

    path = root / f"snapshot-{hex_digest}.json"
    payload = (
        json.dumps(snapshot, indent=2, sort_keys=True, ensure_ascii=False)
        + "\n"
    ).encode("utf-8")

    # Atomic replace within the same directory.
    fd, tmp_name = tempfile.mkstemp(
        prefix=".axm-snapshot-",
        suffix=".tmp",
        dir=str(root),
    )
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)

    receipt_core = {
        "schema": "axm.python-evidence-store-receipt.v1",
        "snapshot_digest": digest,
        "path": str(path),
        "bytes": len(payload),
        "atomic_replace": True,
    }
    return {
        **receipt_core,
        "receipt_digest": digest_object(receipt_core),
    }


def load_snapshot(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    try:
        snapshot = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ContractError(f"SNAPSHOT_READ_FAILED:{p}") from exc
    validate_snapshot(snapshot)
    return snapshot
