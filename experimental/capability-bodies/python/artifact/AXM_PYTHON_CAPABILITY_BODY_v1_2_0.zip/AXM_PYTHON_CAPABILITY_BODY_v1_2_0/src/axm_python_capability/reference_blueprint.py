from __future__ import annotations

from typing import Any

from .canonical import digest_object
from .constants import REFERENCE_BLUEPRINT_SCHEMA_V1


LAYERS = [
    {
        "layer": 0,
        "name": "truth_authority",
        "required_contracts": [
            "capability_identity",
            "versioned_manifest",
            "typed_requests",
            "explicit_authority_ceiling",
            "no_automatic_install",
            "no_automatic_register",
            "no_automatic_promote",
            "no_automatic_canon",
            "deterministic_receipts",
        ],
        "generic": True,
    },
    {
        "layer": 1,
        "name": "language_representation",
        "required_contracts": [
            "whole_source_path",
            "canonical_normalization",
            "bounded_staging",
            "syntax_frontend",
            "compile_or_semantic_frontend_without_execution_when_available",
        ],
        "generic": False,
    },
    {
        "layer": 2,
        "name": "static_understanding",
        "required_contracts": [
            "symbols",
            "imports_or_dependencies",
            "public_api_surface",
            "language_features",
            "static_effect_signals",
            "reference_states_include_unresolved",
        ],
        "generic": False,
    },
    {
        "layer": 3,
        "name": "project_intelligence",
        "required_contracts": [
            "project_layout",
            "dependency_classification",
            "module_or_component_graph",
            "cycles",
            "hotspots",
            "test_discovery",
            "architecture_digest",
        ],
        "generic": False,
    },
    {
        "layer": 4,
        "name": "change_intelligence",
        "required_contracts": [
            "before_after_impact",
            "api_compatibility_passport",
            "blast_radius",
            "affected_tests",
            "dependency_migration_plan",
            "compatibility_evidence",
            "change_risk_is_not_merge_authority",
        ],
        "generic": True,
    },
    {
        "layer": 5,
        "name": "deterministic_repair_refactor",
        "required_contracts": [
            "exact_preconditions",
            "ambiguous_change_refusal",
            "impact_guards",
            "post_change_static_verification",
            "exact_vs_ambiguous_refactor_separation",
            "rollback_packet",
        ],
        "generic": True,
    },
    {
        "layer": 6,
        "name": "external_verification_ring",
        "required_contracts": [
            "explicit_analyzer_authority",
            "no_auto_install",
            "shadow_copy",
            "source_hash_before_after",
            "timeout",
            "output_cap",
            "tool_identity_evidence",
            "network_behavior_declaration",
            "findings_distinct_from_tool_failure",
        ],
        "generic": True,
    },
    {
        "layer": 7,
        "name": "hard_sandbox_execution",
        "required_contracts": [
            "explicit_execution_authority",
            "provider_local_probe",
            "no_unsandboxed_fallback",
            "network_isolation_when_forbidden",
            "isolated_writable_worktree",
            "resource_limits",
            "execution_receipt",
            "hold_when_containment_unavailable",
        ],
        "generic": True,
    },
    {
        "layer": 8,
        "name": "governance_return",
        "required_contracts": [
            "candidate_or_evidence_output",
            "evidence_gaps_explicit",
            "complete_evidence_not_approval",
            "governance_external_to_body",
            "no_silent_promotion",
        ],
        "generic": True,
    },
]

LANGUAGE_SPECIFIC_SLOTS = [
    "parser_or_frontend",
    "compiler_or_semantic_checker",
    "package_or_dependency_format",
    "formatter_linter_adapters",
    "type_checker_adapters",
    "project_graph_semantics",
    "reference_name_flow_semantics",
    "test_framework_commands",
    "hard_sandbox_runtime_command",
    "language_version_compatibility_model",
]

DONOR_REFINEMENTS = [
    "content_addressed_incremental_evidence",
    "deterministic_repository_sharding",
    "change_set_conflict_and_dependency_graph",
    "hash_guarded_rollback",
    "dead_code_candidates_not_automatic_deletion",
    "architecture_policy_as_data",
    "behavioral_fixtures_separated_from_execution_authority",
    "semantic_change_provides_requires",
    "streaming_read_only_repository_intake",
    "consolidated_change_evidence_passport",
]


def build_reference_blueprint() -> dict[str, Any]:
    core = {
        "schema": REFERENCE_BLUEPRINT_SCHEMA_V1,
        "name": "AXM Code Body Reference Architecture",
        "maturity_version": "1.0",
        "layers": LAYERS,
        "language_specific_slots": LANGUAGE_SPECIFIC_SLOTS,
        "donor_refinements": DONOR_REFINEMENTS,
        "root_invariants": [
            "truth_before_story",
            "no_fake_done",
            "no_silent_authority_widening",
            "capability_does_not_imply_action",
            "evidence_does_not_imply_governance_approval",
            "ambiguity_prefers_hold_over_guess",
            "rollback_refuses_state_drift",
            "no_unsandboxed_execution_fallback",
        ],
    }
    result = dict(core)
    result["blueprint_digest"] = digest_object(core)
    return result


def assess_candidate_body(candidate: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(candidate, dict):
        return {
            "status": "ROOT_VIOLATIONS",
            "root_violations": ["CANDIDATE_NOT_OBJECT"],
            "missing_layers": list(range(9)),
            "layer_results": [],
            "maturity_percent": 0,
        }

    root_violations = []
    authority = candidate.get("authority", {})
    if not isinstance(authority, dict):
        root_violations.append("AUTHORITY_NOT_OBJECT")
        authority = {}

    for field in (
        "automatic_install",
        "automatic_register",
        "automatic_promote",
        "automatic_canon",
    ):
        if authority.get(field) is True:
            root_violations.append(field.upper() + "_FORBIDDEN")

    if candidate.get("unsandboxed_execution_fallback") is True:
        root_violations.append("UNSANDBOXED_EXECUTION_FALLBACK_FORBIDDEN")

    evidence_layers = candidate.get("layers", {})
    if not isinstance(evidence_layers, dict):
        evidence_layers = {}
        root_violations.append("LAYERS_NOT_OBJECT")

    layer_results = []
    missing_layers = []
    complete = 0

    for layer in LAYERS:
        key = str(layer["layer"])
        supplied = evidence_layers.get(key)
        if not isinstance(supplied, dict):
            missing_layers.append(layer["layer"])
            layer_results.append({
                "layer": layer["layer"],
                "name": layer["name"],
                "status": "MISSING",
                "missing_contracts": layer["required_contracts"],
            })
            continue

        contracts = supplied.get("contracts", [])
        if not isinstance(contracts, list):
            contracts = []
        contract_set = {str(x) for x in contracts}
        missing = sorted(set(layer["required_contracts"]) - contract_set)
        status = "PASS" if not missing else "PARTIAL"
        if status == "PASS":
            complete += 1
        else:
            missing_layers.append(layer["layer"])

        layer_results.append({
            "layer": layer["layer"],
            "name": layer["name"],
            "status": status,
            "missing_contracts": missing,
        })

    maturity_percent = round((complete / len(LAYERS)) * 100)
    status = (
        "ROOT_VIOLATIONS"
        if root_violations
        else "COMPLETE_REFERENCE_CONTRACT"
        if not missing_layers
        else "PARTIAL_MATURITY"
    )

    result = {
        "status": status,
        "root_violations": sorted(root_violations),
        "missing_layers": sorted(set(missing_layers)),
        "layer_results": layer_results,
        "maturity_percent": maturity_percent,
        "automatic_promotion": False,
    }
    result["assessment_digest"] = digest_object(result)
    return result
