from __future__ import annotations

from pathlib import PurePosixPath
from typing import Any

from .reference_index import build_reference_index


SPECIAL_ENTRY_NAMES = {
    "main", "cli", "app", "application", "handler",
    "__getattr__", "__dir__",
}


def dead_code_candidates(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
) -> dict[str, Any]:
    index = build_reference_index(files, target_python, package)
    counts = index["incoming_reference_counts"]
    candidates = []

    for definition in index["definitions"]:
        path_obj = PurePosixPath(definition["path"])
        if (
            "tests" in path_obj.parts
            or path_obj.name.startswith("test_")
            or path_obj.name.endswith("_test.py")
        ):
            continue

        symbol = definition["symbol"]
        name = definition["name"]
        incoming = int(counts.get(symbol, 0))

        if name.startswith("__") and name.endswith("__"):
            continue
        if name in SPECIAL_ENTRY_NAMES:
            continue
        if incoming > 0:
            continue

        if definition["decorated"]:
            confidence = "LOW"
            reason = "UNREFERENCED_DECORATED_SYMBOL_MAY_BE_FRAMEWORK_DISCOVERED"
        elif not definition["public"]:
            confidence = "HIGHER"
            reason = "UNREFERENCED_PRIVATE_SYMBOL"
        else:
            confidence = "LOW"
            reason = "UNREFERENCED_PUBLIC_SYMBOL_MAY_BE_EXTERNAL_API"

        candidates.append({
            "symbol": symbol,
            "path": definition["path"],
            "line": definition["line"],
            "kind": definition["kind"],
            "public": definition["public"],
            "decorated": definition["decorated"],
            "incoming_static_references": incoming,
            "confidence": confidence,
            "reason": reason,
            "automatic_delete": False,
        })

    rank = {"HIGHER": 0, "MEDIUM": 1, "LOW": 2}
    return {
        "schema": "axm.python-dead-code-candidates.v1",
        "candidates": sorted(
            candidates,
            key=lambda x: (rank.get(x["confidence"], 9), x["symbol"]),
        ),
        "automatic_delete": False,
        "truth_boundary": (
            "Unreferenced is not equivalent to dead. Public APIs, plugins, "
            "serialization hooks, reflection, decorators, entry points, and "
            "external consumers may use symbols invisible to static analysis."
        ),
        "reference_index_digest": index["index_digest"],
    }
