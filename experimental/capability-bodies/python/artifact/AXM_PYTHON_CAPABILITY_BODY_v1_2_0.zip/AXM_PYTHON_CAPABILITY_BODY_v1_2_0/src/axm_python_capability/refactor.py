from __future__ import annotations

import ast
from typing import Any

from .analyze import parse_source
from .canonical import digest_object
from .errors import ContractError
from .project_graph import module_name_from_path


def _definition_count(tree: ast.Module, symbol: str) -> int:
    return sum(
        1 for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        and node.name == symbol
    )


def plan_public_symbol_rename(
    files: list[dict[str, str]],
    target_python: str,
    *,
    module: str,
    old: str,
    new: str,
    package: str | None = None,
) -> dict[str, Any]:
    if not old.isidentifier() or not new.isidentifier():
        raise ContractError("old and new must be Python identifiers")
    if old == new:
        raise ContractError("old and new must differ")

    module_files = [
        item for item in files
        if item["path"].endswith(".py")
        and module_name_from_path(item["path"], package) == module
    ]
    if len(module_files) != 1:
        raise ContractError("target module must resolve to exactly one file")

    target_file = module_files[0]
    target_tree = parse_source(target_file["source"], target_file["path"], target_python)
    if not isinstance(target_tree, ast.Module):
        raise ContractError("target must be a module")

    count = _definition_count(target_tree, old)
    if count != 1:
        raise ContractError(
            f"target top-level definition must occur exactly once: found={count}"
        )

    edits = []
    ambiguous = []

    # Target definition line.
    for node in target_tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.name == old:
            line = target_file["source"].splitlines()[node.lineno - 1]
            kind_prefix = (
                "async def "
                if isinstance(node, ast.AsyncFunctionDef)
                else "def "
                if isinstance(node, ast.FunctionDef)
                else "class "
            )
            old_fragment = kind_prefix + old
            new_fragment = kind_prefix + new
            if line.count(old_fragment) == 1:
                edits.append({
                    "path": target_file["path"],
                    "kind": "definition",
                    "line": node.lineno,
                    "old": old_fragment,
                    "new": new_fragment,
                })
            else:
                ambiguous.append({
                    "path": target_file["path"],
                    "line": node.lineno,
                    "reason": "DEFINITION_TEXT_NOT_UNIQUE_ON_LINE",
                })

    # Import statements in every file.
    for item in sorted(files, key=lambda x: x["path"]):
        if not item["path"].endswith(".py"):
            continue
        tree = parse_source(item["source"], item["path"], target_python)
        if not isinstance(tree, ast.Module):
            continue

        lines = item["source"].splitlines()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module == module:
                for alias in node.names:
                    if alias.name == old:
                        line = lines[node.lineno - 1]
                        # Preserve alias: `from m import old as x` -> new as x.
                        old_fragment = old
                        new_fragment = new
                        if line.count(old_fragment) == 1:
                            edits.append({
                                "path": item["path"],
                                "kind": "from_import",
                                "line": node.lineno,
                                "old": old_fragment,
                                "new": new_fragment,
                            })
                        else:
                            ambiguous.append({
                                "path": item["path"],
                                "line": node.lineno,
                                "reason": "IMPORT_REFERENCE_AMBIGUOUS",
                            })

            elif isinstance(node, ast.Attribute) and node.attr == old:
                # We only claim this as a candidate because proving the base
                # object resolves to the target module requires deeper name flow.
                ambiguous.append({
                    "path": item["path"],
                    "line": getattr(node, "lineno", None),
                    "reason": "ATTRIBUTE_REFERENCE_NEEDS_NAME_FLOW_PROOF",
                    "candidate": ast.unparse(node),
                })

            elif isinstance(node, ast.Name) and node.id == old:
                if item["path"] != target_file["path"]:
                    ambiguous.append({
                        "path": item["path"],
                        "line": getattr(node, "lineno", None),
                        "reason": "BARE_NAME_REFERENCE_NEEDS_IMPORT_SCOPE_PROOF",
                        "candidate": old,
                    })

    edits = sorted(
        {
            (e["path"], e["kind"], e["line"], e["old"], e["new"])
            for e in edits
        }
    )
    edits = [
        {"path": p, "kind": k, "line": l, "old": o, "new": n}
        for p, k, l, o, n in edits
    ]
    ambiguous = sorted(
        ambiguous,
        key=lambda x: (x["path"], x.get("line") or -1, x["reason"]),
    )

    status = "READY_EXACT_EDITS" if not ambiguous else "HOLD_AMBIGUOUS_REFERENCES"

    result = {
        "schema": "axm.python-refactor-plan.v1",
        "operation": "RENAME_PUBLIC_TOP_LEVEL_SYMBOL",
        "module": module,
        "old": old,
        "new": new,
        "target_path": target_file["path"],
        "exact_edits": edits,
        "ambiguous_references": ambiguous,
        "status": status,
        "automatic_apply": False,
        "truth_boundary": (
            "Only exact syntactic edits are proposed. Ambiguous bare-name or "
            "attribute references are held instead of guessed."
        ),
    }
    result["plan_digest"] = digest_object(result)
    return result
