from __future__ import annotations

import ast
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

from .analyze import parse_source
from .canonical import digest_object
from .project_graph import module_name_from_path


def _target_names(node: ast.AST) -> set[str]:
    out: set[str] = set()
    if isinstance(node, ast.Name):
        out.add(node.id)
    elif isinstance(node, (ast.Tuple, ast.List)):
        for elt in node.elts:
            out.update(_target_names(elt))
    elif isinstance(node, ast.Starred):
        out.update(_target_names(node.value))
    return out


def _function_bound_names(node: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
    bound = set()
    args = node.args
    for arg in (
        list(args.posonlyargs)
        + list(args.args)
        + list(args.kwonlyargs)
        + ([args.vararg] if args.vararg else [])
        + ([args.kwarg] if args.kwarg else [])
    ):
        if arg:
            bound.add(arg.arg)

    # Bindings anywhere in a function make the name local unless global/nonlocal.
    globals_: set[str] = set()
    nonlocals: set[str] = set()

    class Binder(ast.NodeVisitor):
        def visit_Global(self, n: ast.Global) -> None:
            globals_.update(n.names)

        def visit_Nonlocal(self, n: ast.Nonlocal) -> None:
            nonlocals.update(n.names)

        def visit_Assign(self, n: ast.Assign) -> None:
            for target in n.targets:
                bound.update(_target_names(target))
            self.generic_visit(n.value)

        def visit_AnnAssign(self, n: ast.AnnAssign) -> None:
            bound.update(_target_names(n.target))
            if n.value:
                self.generic_visit(n.value)

        def visit_AugAssign(self, n: ast.AugAssign) -> None:
            bound.update(_target_names(n.target))
            self.generic_visit(n.value)

        def visit_For(self, n: ast.For) -> None:
            bound.update(_target_names(n.target))
            self.generic_visit(n.iter)
            for child in n.body + n.orelse:
                self.visit(child)

        visit_AsyncFor = visit_For

        def visit_With(self, n: ast.With) -> None:
            for item in n.items:
                if item.optional_vars:
                    bound.update(_target_names(item.optional_vars))
                self.visit(item.context_expr)
            for child in n.body:
                self.visit(child)

        visit_AsyncWith = visit_With

        def visit_ExceptHandler(self, n: ast.ExceptHandler) -> None:
            if isinstance(n.name, str):
                bound.add(n.name)
            for child in n.body:
                self.visit(child)

        def visit_Import(self, n: ast.Import) -> None:
            for alias in n.names:
                bound.add(alias.asname or alias.name.split(".")[0])

        def visit_ImportFrom(self, n: ast.ImportFrom) -> None:
            for alias in n.names:
                if alias.name != "*":
                    bound.add(alias.asname or alias.name)

        def visit_FunctionDef(self, n: ast.FunctionDef) -> None:
            # Nested definition binds its name but don't descend into nested scope.
            if n is not node:
                bound.add(n.name)

        def visit_AsyncFunctionDef(self, n: ast.AsyncFunctionDef) -> None:
            if n is not node:
                bound.add(n.name)

        def visit_ClassDef(self, n: ast.ClassDef) -> None:
            bound.add(n.name)

    binder = Binder()
    for child in node.body:
        binder.visit(child)

    bound.difference_update(globals_)
    bound.difference_update(nonlocals)
    return bound


def _module_symbols(module: str, tree: ast.Module) -> dict[str, dict[str, Any]]:
    out = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            key = f"{module}.{node.name}"
            out[node.name] = {
                "symbol": key,
                "kind": type(node).__name__,
                "name": node.name,
                "line": node.lineno,
                "decorated": bool(getattr(node, "decorator_list", [])),
                "public": not node.name.startswith("_"),
            }
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = []
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    targets.extend(sorted(_target_names(target)))
            else:
                targets.extend(sorted(_target_names(node.target)))
            for name in targets:
                if name == "__all__":
                    continue
                key = f"{module}.{name}"
                out.setdefault(name, {
                    "symbol": key,
                    "kind": "ConstantOrVariable",
                    "name": name,
                    "line": node.lineno,
                    "decorated": False,
                    "public": not name.startswith("_"),
                })
    return out


def _resolve_relative(source_module: str, raw_module: str, level: int) -> str | None:
    if level <= 0:
        return raw_module or None
    parts = source_module.split(".")[:-1]
    climb = level - 1
    if climb > len(parts):
        return None
    if climb:
        parts = parts[:-climb]
    if raw_module:
        parts += raw_module.split(".")
    return ".".join(parts) if parts else None


@dataclass
class Scope:
    kind: str
    local_bound: set[str]


class _ReferenceVisitor(ast.NodeVisitor):
    def __init__(
        self,
        *,
        path: str,
        module: str,
        module_symbols: dict[str, dict[str, Any]],
        all_symbols: set[str],
        all_modules: set[str],
        symbol_aliases: dict[str, str],
        module_aliases: dict[str, str],
    ) -> None:
        self.path = path
        self.module = module
        self.module_symbols = module_symbols
        self.all_symbols = all_symbols
        self.all_modules = all_modules
        self.symbol_aliases = symbol_aliases
        self.module_aliases = module_aliases
        self.scopes: list[Scope] = [Scope("module", set())]
        self.references: list[dict[str, Any]] = []

    def _shadowed(self, name: str) -> bool:
        # Any non-module active function scope with local binding shadows module/import.
        for scope in reversed(self.scopes[1:]):
            if name in scope.local_bound:
                return True
        return False

    def _add(self, node: ast.AST, raw: str, target: str | None, resolution: str) -> None:
        self.references.append({
            "path": self.path,
            "module": self.module,
            "line": getattr(node, "lineno", None),
            "column": getattr(node, "col_offset", None),
            "end_line": getattr(node, "end_lineno", None),
            "end_column": getattr(node, "end_col_offset", None),
            "raw": raw,
            "target": target,
            "resolution": resolution,
        })

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.scopes.append(Scope("function", _function_bound_names(node)))
        for child in node.body:
            self.visit(child)
        self.scopes.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.scopes.append(Scope("function", _function_bound_names(node)))
        for child in node.body:
            self.visit(child)
        self.scopes.pop()

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        # Class body assignments are class namespace, but method references should
        # resolve independently. Treat class namespace as a boundary without
        # shadowing module imports for method bodies.
        self.scopes.append(Scope("class", set()))
        for child in node.body:
            self.visit(child)
        self.scopes.pop()

    def visit_Name(self, node: ast.Name) -> None:
        if not isinstance(node.ctx, ast.Load):
            return
        name = node.id
        if self._shadowed(name):
            self._add(node, name, None, "SHADOWED_LOCAL")
            return

        if name in self.symbol_aliases:
            self._add(node, name, self.symbol_aliases[name], "RESOLVED_IMPORTED_SYMBOL")
            return

        if name in self.module_symbols:
            self._add(node, name, self.module_symbols[name]["symbol"], "RESOLVED_MODULE_SYMBOL")
            return

        self._add(node, name, None, "UNRESOLVED_OR_BUILTIN")

    def visit_Attribute(self, node: ast.Attribute) -> None:
        # Avoid double-counting the root Name for module aliases.
        if isinstance(node.value, ast.Name):
            root = node.value.id
            if not self._shadowed(root) and root in self.module_aliases:
                module = self.module_aliases[root]
                target = f"{module}.{node.attr}"
                resolution = (
                    "RESOLVED_IMPORTED_ATTRIBUTE"
                    if target in self.all_symbols
                    else "IMPORTED_MODULE_ATTRIBUTE_EXTERNAL_OR_UNKNOWN"
                )
                self._add(node, f"{root}.{node.attr}", target, resolution)
                return
        self.generic_visit(node)


def build_reference_index(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
) -> dict[str, Any]:
    py_files = [x for x in files if x["path"].endswith(".py")]
    trees: dict[str, ast.Module] = {}
    path_to_module: dict[str, str] = {}
    symbols_by_module: dict[str, dict[str, dict[str, Any]]] = {}

    for item in sorted(py_files, key=lambda x: x["path"]):
        module = module_name_from_path(item["path"], package)
        path_to_module[item["path"]] = module
        tree = parse_source(item["source"], item["path"], target_python)
        if not isinstance(tree, ast.Module):
            continue
        trees[module] = tree
        symbols_by_module[module] = _module_symbols(module, tree)

    all_modules = set(trees)
    all_symbols = {
        info["symbol"]
        for module_symbols in symbols_by_module.values()
        for info in module_symbols.values()
    }

    definitions = []
    for path, module in sorted(path_to_module.items()):
        for info in symbols_by_module.get(module, {}).values():
            definitions.append({"path": path, "module": module, **info})
    definitions = sorted(definitions, key=lambda x: (x["symbol"], x["path"], x["line"]))

    import_bindings = []
    references = []

    for item in sorted(py_files, key=lambda x: x["path"]):
        path = item["path"]
        module = path_to_module[path]
        tree = trees[module]
        symbol_aliases: dict[str, str] = {}
        module_aliases: dict[str, str] = {}

        for node in tree.body:
            if isinstance(node, ast.Import):
                for alias in node.names:
                    local = alias.asname or alias.name.split(".")[0]
                    if alias.name in all_modules:
                        module_aliases[local] = alias.name
                        import_bindings.append({
                            "path": path,
                            "module": module,
                            "local_name": local,
                            "target": alias.name,
                            "kind": "MODULE_IMPORT",
                            "line": node.lineno,
                        })

            elif isinstance(node, ast.ImportFrom):
                base = _resolve_relative(module, node.module or "", node.level)
                for alias in node.names:
                    if alias.name == "*":
                        import_bindings.append({
                            "path": path,
                            "module": module,
                            "local_name": "*",
                            "target": base,
                            "kind": "STAR_IMPORT_UNRESOLVED",
                            "line": node.lineno,
                        })
                        continue

                    local = alias.asname or alias.name
                    symbol_target = f"{base}.{alias.name}" if base else alias.name
                    module_target = symbol_target

                    if symbol_target in all_symbols:
                        symbol_aliases[local] = symbol_target
                        kind = "SYMBOL_IMPORT"
                        target = symbol_target
                    elif module_target in all_modules:
                        module_aliases[local] = module_target
                        kind = "MODULE_FROM_IMPORT"
                        target = module_target
                    else:
                        kind = "EXTERNAL_OR_UNKNOWN_IMPORT"
                        target = symbol_target

                    import_bindings.append({
                        "path": path,
                        "module": module,
                        "local_name": local,
                        "target": target,
                        "kind": kind,
                        "line": node.lineno,
                    })

        visitor = _ReferenceVisitor(
            path=path,
            module=module,
            module_symbols=symbols_by_module.get(module, {}),
            all_symbols=all_symbols,
            all_modules=all_modules,
            symbol_aliases=symbol_aliases,
            module_aliases=module_aliases,
        )
        visitor.visit(tree)
        references.extend(visitor.references)

    references = sorted(
        references,
        key=lambda x: (
            x["path"],
            x["line"] if x["line"] is not None else -1,
            x["column"] if x["column"] is not None else -1,
            x["raw"],
        ),
    )

    incoming: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for ref in references:
        if ref["target"] in all_symbols and ref["resolution"].startswith("RESOLVED_"):
            incoming[ref["target"]].append(ref)

    result = {
        "schema": "axm.python-reference-index.v1",
        "target_python": target_python,
        "path_to_module": dict(sorted(path_to_module.items())),
        "definitions": definitions,
        "import_bindings": sorted(
            import_bindings,
            key=lambda x: (x["path"], x["line"], x["local_name"], x["kind"]),
        ),
        "references": references,
        "incoming_reference_counts": {
            symbol: len(incoming.get(symbol, []))
            for symbol in sorted(all_symbols)
        },
        "truth_boundary": (
            "Static lexical/name-flow index. Dynamic globals mutation, exec/eval, "
            "descriptor behavior, runtime import hooks, monkey patching, and "
            "framework discovery can create references not proven here."
        ),
    }
    result["index_digest"] = digest_object({
        "definitions": definitions,
        "imports": result["import_bindings"],
        "references": references,
    })
    return result
