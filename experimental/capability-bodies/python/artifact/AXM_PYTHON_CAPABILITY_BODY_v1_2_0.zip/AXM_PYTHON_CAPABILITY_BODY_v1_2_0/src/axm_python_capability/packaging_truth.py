from __future__ import annotations

import re
import tomllib
from typing import Any

from .canonical import digest_object
from .errors import ContractError


_DIST_NORMALIZE = re.compile(r"[-_.]+")


def normalize_distribution_name(name: str) -> str:
    return _DIST_NORMALIZE.sub("-", name).lower().strip("-")


def requirement_distribution(requirement: str) -> str:
    # Lexical extraction only. Markers/URLs/specifiers remain separate evidence.
    value = requirement.split(";", 1)[0].strip()
    value = value.split("@", 1)[0].strip()
    match = re.match(r"^([A-Za-z0-9_.-]+)", value)
    if not match:
        raise ContractError(f"UNPARSEABLE_REQUIREMENT:{requirement}")
    return normalize_distribution_name(match.group(1))


def parse_pyproject(text: str) -> dict[str, Any]:
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError as exc:
        raise ContractError("PYPROJECT_TOML_INVALID") from exc

    project = data.get("project", {})
    if not isinstance(project, dict):
        project = {}

    deps = project.get("dependencies", [])
    if deps is None:
        deps = []
    if not isinstance(deps, list):
        raise ContractError("PROJECT_DEPENDENCIES_NOT_LIST")

    optional = project.get("optional-dependencies", {})
    if optional is None:
        optional = {}
    if not isinstance(optional, dict):
        raise ContractError("OPTIONAL_DEPENDENCIES_NOT_OBJECT")

    return {
        "project_name": project.get("name"),
        "requires_python": project.get("requires-python"),
        "dependencies": sorted(str(x) for x in deps),
        "optional_dependencies": {
            str(group): sorted(str(x) for x in values)
            for group, values in sorted(optional.items())
            if isinstance(values, list)
        },
        "scripts": dict(sorted((project.get("scripts") or {}).items()))
        if isinstance(project.get("scripts") or {}, dict)
        else {},
    }


def parse_pylock(text: str) -> dict[str, Any]:
    """
    Structural PEP-751-style pylock reader.
    It intentionally does not resolve/download anything.
    """
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError as exc:
        raise ContractError("PYLOCK_TOML_INVALID") from exc

    packages = data.get("packages", [])
    if packages is None:
        packages = []
    if not isinstance(packages, list):
        raise ContractError("PYLOCK_PACKAGES_NOT_LIST")

    rows = []
    for i, package in enumerate(packages):
        if not isinstance(package, dict):
            raise ContractError(f"PYLOCK_PACKAGE_NOT_OBJECT:{i}")
        name = package.get("name")
        version = package.get("version")
        if not isinstance(name, str) or not name:
            raise ContractError(f"PYLOCK_PACKAGE_NAME_REQUIRED:{i}")
        rows.append({
            "name": normalize_distribution_name(name),
            "version": str(version) if version is not None else None,
            "requires_python": package.get("requires-python"),
            "marker": package.get("marker"),
        })

    return {
        "lock_version": data.get("lock-version"),
        "requires_python": data.get("requires-python"),
        "packages": sorted(
            rows,
            key=lambda x: (x["name"], x["version"] or "", str(x["marker"])),
        ),
    }


def normalize_distribution_metadata(records: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Normalize externally supplied installed/index metadata.
    PEP 794 Import-Name / Import-Namespace are represented as explicit facts.
    No package index/network access occurs here.
    """
    distributions = {}
    import_to_distributions: dict[str, list[str]] = {}
    namespaces: dict[str, list[str]] = {}

    for i, raw in enumerate(records):
        if not isinstance(raw, dict):
            raise ContractError(f"METADATA_RECORD_NOT_OBJECT:{i}")
        name = raw.get("name")
        if not isinstance(name, str) or not name:
            raise ContractError(f"METADATA_NAME_REQUIRED:{i}")
        dist = normalize_distribution_name(name)

        import_names = raw.get("import_names", [])
        import_namespaces = raw.get("import_namespaces", [])
        if not isinstance(import_names, list) or not all(isinstance(x, str) for x in import_names):
            raise ContractError(f"IMPORT_NAMES_NOT_STRING_LIST:{dist}")
        if not isinstance(import_namespaces, list) or not all(isinstance(x, str) for x in import_namespaces):
            raise ContractError(f"IMPORT_NAMESPACES_NOT_STRING_LIST:{dist}")

        record = {
            "name": dist,
            "version": str(raw.get("version")) if raw.get("version") is not None else None,
            "import_names": sorted(set(import_names)),
            "import_namespaces": sorted(set(import_namespaces)),
        }
        distributions[dist] = record

        for module in record["import_names"]:
            import_to_distributions.setdefault(module, []).append(dist)
        for namespace in record["import_namespaces"]:
            namespaces.setdefault(namespace, []).append(dist)

    for mapping in (import_to_distributions, namespaces):
        for key in mapping:
            mapping[key] = sorted(set(mapping[key]))

    return {
        "distributions": dict(sorted(distributions.items())),
        "import_to_distributions": dict(sorted(import_to_distributions.items())),
        "namespace_to_distributions": dict(sorted(namespaces.items())),
    }


def packaging_truth_passport(
    *,
    pyproject_text: str,
    observed_import_roots: list[str],
    distribution_metadata: list[dict[str, Any]] | None = None,
    pylock_text: str | None = None,
) -> dict[str, Any]:
    project = parse_pyproject(pyproject_text)
    metadata = normalize_distribution_metadata(distribution_metadata or [])
    lock = parse_pylock(pylock_text) if pylock_text is not None else None

    declared_runtime = {
        requirement_distribution(req)
        for req in project["dependencies"]
    }
    declared_optional = {
        group: {
            requirement_distribution(req)
            for req in requirements
        }
        for group, requirements in project["optional_dependencies"].items()
    }

    mapped_imports = {}
    unknown_imports = []
    ambiguous_imports = []

    for root in sorted(set(observed_import_roots)):
        candidates = metadata["import_to_distributions"].get(root, [])
        namespace_candidates = metadata["namespace_to_distributions"].get(root, [])
        combined = sorted(set(candidates + namespace_candidates))
        if len(combined) == 1:
            mapped_imports[root] = combined[0]
        elif len(combined) > 1:
            ambiguous_imports.append({
                "import_root": root,
                "distributions": combined,
            })
        else:
            unknown_imports.append(root)

    observed_distributions = set(mapped_imports.values())
    missing_runtime_declarations = sorted(
        observed_distributions - declared_runtime
    )
    unused_runtime_declarations = sorted(
        declared_runtime - observed_distributions
    )

    locked_names = {
        package["name"]
        for package in (lock or {}).get("packages", [])
    }
    unlocked_runtime = (
        sorted(declared_runtime - locked_names)
        if lock is not None
        else []
    )

    core = {
        "schema": "axm.python-packaging-truth-passport.v1",
        "project": project,
        "lock": lock,
        "metadata": metadata,
        "observed_import_roots": sorted(set(observed_import_roots)),
        "mapped_imports": dict(sorted(mapped_imports.items())),
        "unknown_import_roots": unknown_imports,
        "ambiguous_import_roots": ambiguous_imports,
        "declared_runtime_distributions": sorted(declared_runtime),
        "declared_optional_distributions": {
            group: sorted(values)
            for group, values in sorted(declared_optional.items())
        },
        "missing_runtime_declarations": missing_runtime_declarations,
        "unused_runtime_declarations": unused_runtime_declarations,
        "unlocked_runtime_declarations": unlocked_runtime,
        "network_used": False,
        "packages_installed": False,
        "truth_boundary": (
            "Import-to-distribution truth depends on supplied metadata. Unknown "
            "mappings remain unknown rather than using hyphen/underscore guessing."
        ),
    }
    result = dict(core)
    result["passport_digest"] = digest_object(core)
    return result
