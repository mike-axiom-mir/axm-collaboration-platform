from __future__ import annotations

import hashlib
import json
import os
import resource
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any

from .authority import evaluate_authority
from .canonical import digest_object, stable_id
from .constants import (
    CAPABILITY_ID,
    CAPABILITY_VERSION,
    SANDBOX_TEST_SCHEMA_V1,
)
from .errors import AuthorityError, ContractError
from .sandbox import sandbox_doctor


IGNORE = frozenset({
    ".git", ".hg", ".svn", ".venv", "venv", "env", "__pycache__",
    ".mypy_cache", ".pytest_cache", ".ruff_cache", "node_modules", ".tox", ".nox",
})


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _tree(root: Path) -> list[dict[str, Any]]:
    root = root.resolve()
    out = []
    for p in sorted(root.rglob("*"), key=lambda x: x.as_posix()):
        rel = p.relative_to(root)
        if any(part in IGNORE for part in rel.parts):
            continue
        if p.is_symlink():
            raise ContractError(f"SYMLINK_REFUSED:{rel.as_posix()}")
        if p.is_file():
            out.append({
                "path": rel.as_posix(),
                "bytes": p.stat().st_size,
                "sha256": _sha(p),
            })
    return out


def _copy_shadow(source: Path, target: Path) -> None:
    def ignore(_dir: str, names: list[str]) -> set[str]:
        return {name for name in names if name in IGNORE}
    shutil.copytree(source, target, ignore=ignore, symlinks=False)


def _limits(cpu_seconds: int, memory_bytes: int, file_bytes: int, processes: int):
    def set_limits() -> None:
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
        resource.setrlimit(resource.RLIMIT_AS, (memory_bytes, memory_bytes))
        resource.setrlimit(resource.RLIMIT_FSIZE, (file_bytes, file_bytes))
        resource.setrlimit(resource.RLIMIT_NPROC, (processes, processes))
        resource.setrlimit(resource.RLIMIT_NOFILE, (128, 128))
    return set_limits


def _bounded_run(
    command: list[str],
    *,
    cwd: Path,
    env: dict[str, str],
    timeout: float,
    max_output_bytes: int,
    cpu_seconds: int,
    memory_bytes: int,
    file_bytes: int,
    processes: int,
) -> dict[str, Any]:
    started = time.monotonic()
    proc = subprocess.Popen(
        command,
        cwd=str(cwd),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=False,
        preexec_fn=_limits(cpu_seconds, memory_bytes, file_bytes, processes),
    )

    lock = threading.Lock()
    total = 0
    output_limit = threading.Event()
    out_chunks: list[bytes] = []
    err_chunks: list[bytes] = []

    def reader(stream, bucket: list[bytes]) -> None:
        nonlocal total
        try:
            while True:
                chunk = stream.read(4096)
                if not chunk:
                    return
                with lock:
                    remaining = max_output_bytes - total
                    if remaining > 0:
                        kept = chunk[:remaining]
                        bucket.append(kept)
                        total += len(kept)
                    if len(chunk) > remaining:
                        output_limit.set()
                if output_limit.is_set():
                    try:
                        proc.kill()
                    except OSError:
                        pass
                    return
        finally:
            try:
                stream.close()
            except Exception:
                pass

    t1 = threading.Thread(target=reader, args=(proc.stdout, out_chunks), daemon=True)
    t2 = threading.Thread(target=reader, args=(proc.stderr, err_chunks), daemon=True)
    t1.start()
    t2.start()

    timed_out = False
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        proc.kill()
        proc.wait()

    t1.join(timeout=1)
    t2.join(timeout=1)

    return {
        "returncode": proc.returncode,
        "stdout": b"".join(out_chunks).decode("utf-8", errors="replace"),
        "stderr": b"".join(err_chunks).decode("utf-8", errors="replace"),
        "timed_out": timed_out,
        "output_limit_exceeded": output_limit.is_set(),
        "duration_ms": int((time.monotonic() - started) * 1000),
    }


def _bubblewrap_command(executable: str, shadow: Path, test_command: list[str]) -> list[str]:
    cmd = [
        executable,
        "--die-with-parent",
        "--new-session",
        "--unshare-all",
        "--cap-drop", "ALL",
        "--ro-bind", "/usr", "/usr",
        "--proc", "/proc",
        "--dev", "/dev",
        "--tmpfs", "/tmp",
        "--dir", "/home",
        "--bind", str(shadow), "/work",
        "--chdir", "/work",
        "--setenv", "HOME", "/home",
        "--setenv", "TMPDIR", "/tmp",
        "--setenv", "PYTHONDONTWRITEBYTECODE", "1",
        "--setenv", "PIP_DISABLE_PIP_VERSION_CHECK", "1",
        "--setenv", "PYTHONPATH", "/work/src:/work",
    ]

    for link, target in (
        ("/bin", "usr/bin"),
        ("/sbin", "usr/sbin"),
        ("/lib", "usr/lib"),
        ("/lib64", "usr/lib64"),
    ):
        if Path(link).is_symlink():
            cmd += ["--symlink", target, link]
        elif Path(link).exists():
            cmd += ["--ro-bind", link, link]

    if Path("/usr/local").exists():
        cmd += ["--ro-bind", "/usr/local", "/usr/local"]

    cmd += test_command
    return cmd


def run_sandbox_test_request(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict) or raw.get("schema") != SANDBOX_TEST_SCHEMA_V1:
        raise ContractError(f"schema must be {SANDBOX_TEST_SCHEMA_V1}")

    request_id = raw.get("request_id")
    if not isinstance(request_id, str) or not request_id.strip():
        raise ContractError("request_id must be non-empty")

    authorities = raw.get("authorities", [])
    if not isinstance(authorities, list):
        raise ContractError("authorities must be a list")
    decision = evaluate_authority(authorities)
    if "RUN_SANDBOX_TESTS" not in decision.effective:
        raise AuthorityError("RUN_SANDBOX_TESTS_REQUIRED")

    project_root = Path(str(raw.get("project_root", ""))).expanduser().resolve()
    if not project_root.is_dir():
        raise ContractError("project_root must be a directory")

    framework = raw.get("framework", "unittest")
    if framework not in {"unittest"}:
        raise ContractError("only builtin unittest is enabled in v0.5")

    policy = raw.get("policy", {})
    if not isinstance(policy, dict):
        raise ContractError("policy must be an object")

    timeout = float(policy.get("timeout_seconds", 30))
    max_output = int(policy.get("max_output_bytes", 512_000))
    cpu_seconds = int(policy.get("cpu_seconds", 20))
    memory_bytes = int(policy.get("memory_bytes", 512 * 1024 * 1024))
    file_bytes = int(policy.get("file_bytes", 32 * 1024 * 1024))
    processes = int(policy.get("processes", 32))

    before_entries = _tree(project_root)
    before_digest = digest_object(before_entries)
    doctor = sandbox_doctor()

    normalized = {
        "schema": SANDBOX_TEST_SCHEMA_V1,
        "request_id": request_id,
        "project_digest": before_digest,
        "framework": framework,
        "authorities": sorted(set(str(x) for x in authorities)),
        "policy": {
            "timeout_seconds": timeout,
            "max_output_bytes": max_output,
            "cpu_seconds": cpu_seconds,
            "memory_bytes": memory_bytes,
            "file_bytes": file_bytes,
            "processes": processes,
        },
    }
    run_id = stable_id(
        "pytestbox",
        {
            "capability": CAPABILITY_ID,
            "version": CAPABILITY_VERSION,
            "request": normalized,
        },
    )

    hard = [
        p for p in doctor["providers"]
        if p.get("hard_test_ready")
    ]
    if not hard:
        core = {
            "schema": "axm.python-sandbox-test-receipt.v1",
            "capability_id": CAPABILITY_ID,
            "capability_version": CAPABILITY_VERSION,
            "run_id": run_id,
            "request_id": request_id,
            "project_digest": before_digest,
            "framework": framework,
            "sandbox_doctor": doctor,
            "test_execution": False,
            "result": "HOLD_NO_VERIFIED_HARD_SANDBOX",
            "network_authorized": False,
            "host_project_write_authorized": False,
            "packages_installed": False,
            "registered": False,
            "promoted": False,
            "canon": False,
            "status": "DETACHED_HOLD",
        }
        receipt = dict(core)
        receipt["receipt_digest"] = digest_object(core)
        return receipt

    provider = hard[0]
    if provider["provider_id"] != "bubblewrap":
        raise ContractError("NO_IMPLEMENTED_HARD_PROVIDER")

    bwrap = provider["executable"]
    with tempfile.TemporaryDirectory(prefix="axm-python-testbox-") as tmp:
        shadow = Path(tmp) / "project"
        _copy_shadow(project_root, shadow)

        test_command = [
            sys.executable,
            "-B",
            "-m",
            "unittest",
            "discover",
            "-v",
        ]
        command = _bubblewrap_command(bwrap, shadow, test_command)
        env = {
            "PATH": os.environ.get("PATH", ""),
            "LANG": os.environ.get("LANG", "C.UTF-8"),
            "LC_ALL": os.environ.get("LC_ALL", "C.UTF-8"),
            "PYTHONDONTWRITEBYTECODE": "1",
        }
        run = _bounded_run(
            command,
            cwd=shadow,
            env=env,
            timeout=timeout,
            max_output_bytes=max_output,
            cpu_seconds=cpu_seconds,
            memory_bytes=memory_bytes,
            file_bytes=file_bytes,
            processes=processes,
        )
        shadow_after = digest_object(_tree(shadow))

    after_entries = _tree(project_root)
    after_digest = digest_object(after_entries)

    if run["timed_out"]:
        result = "TIMEOUT"
    elif run["output_limit_exceeded"]:
        result = "OUTPUT_LIMIT"
    elif run["returncode"] == 0:
        result = "PASS"
    else:
        result = "TEST_FAILURE"

    core = {
        "schema": "axm.python-sandbox-test-receipt.v1",
        "capability_id": CAPABILITY_ID,
        "capability_version": CAPABILITY_VERSION,
        "run_id": run_id,
        "request_id": request_id,
        "project_before_digest": before_digest,
        "project_after_digest": after_digest,
        "source_unchanged": before_digest == after_digest,
        "framework": framework,
        "provider": provider,
        "test_execution": True,
        "command_inside_sandbox": test_command,
        "returncode": run["returncode"],
        "stdout": run["stdout"],
        "stderr": run["stderr"],
        "timed_out": run["timed_out"],
        "output_limit_exceeded": run["output_limit_exceeded"],
        "duration_ms": run["duration_ms"],
        "shadow_after_digest": shadow_after,
        "result": result,
        "network_authorized": False,
        "filesystem_visibility": "BUBBLEWRAP_CONSTRUCTED_ROOT",
        "resource_limits": {
            "cpu_seconds": cpu_seconds,
            "memory_bytes": memory_bytes,
            "file_bytes": file_bytes,
            "processes": processes,
        },
        "packages_installed": False,
        "registered": False,
        "promoted": False,
        "canon": False,
        "status": "DETACHED_SANDBOX_TEST_EVIDENCE",
    }
    receipt = dict(core)
    receipt["receipt_digest"] = digest_object(core)
    return receipt
