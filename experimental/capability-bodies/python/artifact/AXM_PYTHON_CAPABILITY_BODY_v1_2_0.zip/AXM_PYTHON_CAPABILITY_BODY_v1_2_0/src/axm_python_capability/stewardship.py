from __future__ import annotations

from typing import Any

from .architecture_policy import check_architecture_policy
from .canonical import digest_object
from .dead_code import dead_code_candidates
from .engineering import architecture_report
from .reference_index import build_reference_index


def stewardship_report(
    files: list[dict[str, str]],
    target_python: str,
    package: str | None = None,
    policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    architecture = architecture_report(files, target_python, package)
    references = build_reference_index(files, target_python, package)
    dead = dead_code_candidates(files, target_python, package)

    attention = []

    for cycle in architecture["cycles"]:
        attention.append({
            "severity": "HIGH",
            "kind": "IMPORT_CYCLE",
            "evidence": cycle,
            "automatic_action": False,
        })

    for hotspot in architecture["hotspots"][:5]:
        if hotspot["coupling"] >= 4:
            attention.append({
                "severity": "MEDIUM",
                "kind": "COUPLING_HOTSPOT",
                "evidence": hotspot,
                "automatic_action": False,
            })

    for candidate in dead["candidates"]:
        if candidate["confidence"] == "HIGHER":
            attention.append({
                "severity": "LOW",
                "kind": "DEAD_CODE_CANDIDATE",
                "evidence": candidate,
                "automatic_action": False,
            })

    policy_result = None
    if policy is not None:
        policy_result = check_architecture_policy(
            files, target_python, policy, package
        )
        for violation in policy_result["violations"]:
            attention.append({
                "severity": "HIGH",
                "kind": "ARCHITECTURE_POLICY_VIOLATION",
                "evidence": violation,
                "automatic_action": False,
            })

    rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    attention.sort(
        key=lambda x: (
            rank.get(x["severity"], 9),
            x["kind"],
            str(x["evidence"]),
        )
    )

    report = {
        "schema": "axm.python-stewardship-report.v1",
        "architecture_digest": architecture["architecture_digest"],
        "reference_index_digest": references["index_digest"],
        "dead_code_candidate_count": len(dead["candidates"]),
        "policy_status": policy_result["status"] if policy_result else "NOT_SUPPLIED",
        "attention_queue": attention,
        "automatic_changes": False,
        "truth_boundary": (
            "Stewardship findings are evidence/attention candidates. No item "
            "authorizes deletion, refactor, dependency change, or promotion."
        ),
    }
    report["report_digest"] = digest_object(report)
    return report
