from __future__ import annotations

import importlib.util
from typing import Any

from .canonical import digest_object
from .errors import ContractError


def libcst_status() -> dict[str, Any]:
    spec = importlib.util.find_spec("libcst")
    return {
        "adapter_id": "libcst",
        "installed": spec is not None,
        "module_origin": getattr(spec, "origin", None) if spec else None,
        "automatic_install": False,
    }


def analyze_lossless_source(source: str) -> dict[str, Any]:
    status = libcst_status()
    if not status["installed"]:
        core = {
            "schema": "axm.python-lossless-cst-evidence.v1",
            "adapter": status,
            "status": "NOT_INSTALLED",
            "source_rewritten": False,
        }
        result = dict(core)
        result["evidence_digest"] = digest_object(core)
        return result

    try:
        import libcst as cst
        from libcst.metadata import (
            MetadataWrapper,
            PositionProvider,
            ScopeProvider,
        )
    except Exception as exc:
        raise ContractError("LIBCST_IMPORT_FAILED") from exc

    try:
        module = cst.parse_module(source)
        wrapper = MetadataWrapper(module)
        positions = wrapper.resolve(PositionProvider)
        scopes = wrapper.resolve(ScopeProvider)
    except Exception as exc:
        raise ContractError("LIBCST_PARSE_OR_METADATA_FAILED") from exc

    nodes = []
    for node, position in positions.items():
        if isinstance(node, (cst.FunctionDef, cst.ClassDef, cst.Import, cst.ImportFrom)):
            nodes.append({
                "kind": type(node).__name__,
                "start": [position.start.line, position.start.column],
                "end": [position.end.line, position.end.column],
            })

    core = {
        "schema": "axm.python-lossless-cst-evidence.v1",
        "adapter": status,
        "status": "PASS",
        "roundtrip_exact": module.code == source,
        "structural_nodes": sorted(
            nodes,
            key=lambda x: (x["start"], x["end"], x["kind"]),
        ),
        "metadata_scope_count": len(set(id(scope) for scope in scopes.values())),
        "source_rewritten": False,
        "truth_boundary": (
            "LibCST is optional enhanced evidence. Python AST/compile remains the "
            "baseline path and this adapter is never auto-installed."
        ),
    }
    result = dict(core)
    result["evidence_digest"] = digest_object(core)
    return result
