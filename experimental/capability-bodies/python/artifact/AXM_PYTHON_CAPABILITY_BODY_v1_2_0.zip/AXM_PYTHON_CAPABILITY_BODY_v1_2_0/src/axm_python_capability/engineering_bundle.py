from __future__ import annotations

from typing import Any

from .constants import ENGINEERING_BUNDLE_SCHEMA_V1
from .contracts import normalize_target_python, safe_relpath
from .errors import ContractError


def normalize_engineering_bundle(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict) or raw.get("schema") != ENGINEERING_BUNDLE_SCHEMA_V1:
        raise ContractError(f"schema must be {ENGINEERING_BUNDLE_SCHEMA_V1}")

    target_python = normalize_target_python(raw.get("target_python"))
    package = raw.get("package")
    if package is not None and (not isinstance(package, str) or not package.isidentifier()):
        raise ContractError("package must be a Python identifier when supplied")

    files_raw = raw.get("files")
    if not isinstance(files_raw, list) or not files_raw:
        raise ContractError("files must be a non-empty list")

    files = []
    seen = set()
    for i, item in enumerate(files_raw):
        if not isinstance(item, dict):
            raise ContractError(f"files[{i}] must be an object")
        path = safe_relpath(item.get("path"), f"files[{i}].path")
        source = item.get("source")
        if not isinstance(source, str):
            raise ContractError(f"files[{i}].source must be a string")
        if path in seen:
            raise ContractError(f"duplicate file path: {path}")
        seen.add(path)
        files.append({
            "path": path,
            "source": source.replace("\r\n", "\n").replace("\r", "\n"),
        })

    dependencies = raw.get("dependencies", [])
    if not isinstance(dependencies, list) or not all(isinstance(x, str) for x in dependencies):
        raise ContractError("dependencies must be a string list")

    return {
        "schema": ENGINEERING_BUNDLE_SCHEMA_V1,
        "target_python": target_python,
        "package": package,
        "files": sorted(files, key=lambda x: x["path"]),
        "dependencies": sorted(set(dependencies)),
        "metadata": raw.get("metadata", {}),
    }
