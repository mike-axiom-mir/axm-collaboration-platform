from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class AdapterSpec:
    adapter_id: str
    category: str
    executables: tuple[str, ...]
    args: tuple[str, ...]
    version_args: tuple[str, ...]
    network_behavior: str
    executes_project_code: bool
    source_write_intent: bool
    diagnostic_exit_codes: tuple[int, ...]
    description: str
    version_probe_allowed_offline: bool = True


BUILTIN_ADAPTERS: Mapping[str, AdapterSpec] = {
    "host_compile": AdapterSpec(
        adapter_id="host_compile",
        category="compiler",
        executables=(sys.executable,),
        args=("-I", "-B", "-m", "compileall", "-q", "-f", "."),
        version_args=("--version",),
        network_behavior="none_expected",
        executes_project_code=False,
        source_write_intent=False,
        diagnostic_exit_codes=(),
        description="Compile Python source to bytecode in the shadow copy; does not import it.",
    ),
    "ruff_lint": AdapterSpec(
        adapter_id="ruff_lint",
        category="lint",
        executables=("ruff",),
        args=("--isolated", "check", "--no-cache", "--output-format", "json", "."),
        version_args=("--version",),
        network_behavior="none_expected",
        executes_project_code=False,
        source_write_intent=False,
        diagnostic_exit_codes=(1,),
        description="Ruff lint in isolated, no-cache, machine-readable check mode.",
    ),
    "ruff_format_check": AdapterSpec(
        adapter_id="ruff_format_check",
        category="format",
        executables=("ruff",),
        args=("--isolated", "format", "--check", "--no-cache", "--output-format", "json", "."),
        version_args=("--version",),
        network_behavior="none_expected",
        executes_project_code=False,
        source_write_intent=False,
        diagnostic_exit_codes=(1,),
        description="Ruff formatter check-only mode; no source rewrite requested.",
    ),
    "mypy": AdapterSpec(
        adapter_id="mypy",
        category="type_check",
        executables=("mypy",),
        args=(
            "--config-file=",
            "--no-incremental",
            "--no-error-summary",
            "--show-error-codes",
            "--no-pretty",
            ".",
        ),
        version_args=("--version",),
        network_behavior="none_expected",
        executes_project_code=False,
        source_write_intent=False,
        diagnostic_exit_codes=(1,),
        description="Mypy static type check with project config disabled and incremental cache disabled.",
    ),
    "pyright": AdapterSpec(
        adapter_id="pyright",
        category="type_check",
        executables=("pyright",),
        args=("--outputjson", "."),
        version_args=("--version",),
        network_behavior="bootstrap_uncertain",
        executes_project_code=False,
        source_write_intent=False,
        diagnostic_exit_codes=(1,),
        description=(
            "Pyright static analysis. Strict-offline policy blocks it by default because some "
            "Python wrapper installations can bootstrap Node/Pyright."
        ),
        version_probe_allowed_offline=False,
    ),
    "pyrefly": AdapterSpec(
        adapter_id="pyrefly",
        category="type_check",
        executables=("pyrefly",),
        args=("check", "--output-format", "json", "."),
        version_args=("--version",),
        network_behavior="none_expected",
        executes_project_code=False,
        source_write_intent=False,
        diagnostic_exit_codes=(1,),
        description=(
            "Pyrefly static type-check adapter. Optional/preinstalled only; "
            "no installation or network authority is implied."
        ),
    ),
    "ty": AdapterSpec(
        adapter_id="ty",
        category="type_check",
        executables=("ty",),
        args=("check", "."),
        version_args=("--version",),
        network_behavior="none_expected",
        executes_project_code=False,
        source_write_intent=False,
        diagnostic_exit_codes=(1,),
        description=(
            "Astral ty static type-check adapter. Optional/preinstalled only; "
            "beta/stability differences are retained as evidence."
        ),
    ),
    "pip_audit": AdapterSpec(
        adapter_id="pip_audit",
        category="dependency_security",
        executables=("pip-audit",),
        args=("--progress-spinner", "off", "--format", "json", "."),
        version_args=("--version",),
        network_behavior="network_normally_required",
        executes_project_code=False,
        source_write_intent=False,
        diagnostic_exit_codes=(1,),
        description=(
            "Dependency vulnerability audit. Declared network-capable and refused by the "
            "strict-offline default policy."
        ),
        version_probe_allowed_offline=True,
    ),
}


def adapter_catalog() -> list[dict[str, object]]:
    return [
        {
            "adapter_id": spec.adapter_id,
            "category": spec.category,
            "executables": list(spec.executables),
            "network_behavior": spec.network_behavior,
            "executes_project_code": spec.executes_project_code,
            "source_write_intent": spec.source_write_intent,
            "description": spec.description,
        }
        for spec in sorted(BUILTIN_ADAPTERS.values(), key=lambda s: s.adapter_id)
    ]
