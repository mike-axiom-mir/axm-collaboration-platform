CATALOG = {
    "language": [
        "expressions", "assignments", "unpacking", "walrus operator",
        "if/elif/else", "for/while", "break/continue", "match/case",
        "functions", "positional-only args", "keyword-only args", "closures",
        "lambda", "decorators", "generators", "yield from",
        "classes", "inheritance", "dunder methods", "properties",
        "classmethod", "staticmethod", "descriptors", "metaclasses",
        "exceptions", "exception groups", "context managers",
        "async/await", "async iterators", "async context managers",
        "comprehensions", "annotations", "generic typing"
    ],
    "stdlib_domains": [
        "argparse", "asyncio", "collections", "concurrent.futures", "contextlib",
        "csv", "dataclasses", "datetime", "decimal", "enum", "functools",
        "hashlib", "heapq", "html", "http", "importlib", "inspect", "io",
        "itertools", "json", "logging", "math", "multiprocessing", "operator",
        "os", "pathlib", "pickle", "queue", "random", "re", "shutil",
        "socket", "sqlite3", "statistics", "string", "subprocess", "tempfile",
        "threading", "time", "tomllib", "traceback", "typing", "unittest",
        "urllib", "uuid", "venv", "xml", "zipfile"
    ],
    "software_patterns": [
        "CLI", "library package", "data model", "parser", "serializer",
        "plugin interface", "protocol", "adapter", "registry", "state machine",
        "event bus", "pipeline", "worker", "cache", "repository",
        "dependency injection", "iterator", "context manager", "test suite"
    ],
    "build_modes": [
        "structured components",
        "whole-module Python source",
        "nested package modules",
        "text/json resources"
    ],
}

RECIPE_NAMES = (
    "argparse_cli",
    "async_worker",
    "context_manager",
    "dataclass_model",
    "enum_state",
    "generator_pipeline",
    "protocol_adapter",
    "unittest_case",
)
