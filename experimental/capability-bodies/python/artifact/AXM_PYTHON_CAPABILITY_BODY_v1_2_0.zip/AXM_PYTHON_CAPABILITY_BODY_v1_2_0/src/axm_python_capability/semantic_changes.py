from __future__ import annotations

from collections import defaultdict
from typing import Any

from .canonical import digest_object
from .change_sets import analyze_change_set_conflicts
from .errors import ContractError


def _normalize_units(units: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not isinstance(units, list) or not units:
        raise ContractError("change units must be a non-empty list")

    out = []
    seen = set()
    for i, unit in enumerate(units):
        if not isinstance(unit, dict):
            raise ContractError(f"units[{i}] must be an object")
        change_id = unit.get("change_id")
        if not isinstance(change_id, str) or not change_id:
            raise ContractError(f"units[{i}].change_id required")
        if change_id in seen:
            raise ContractError(f"duplicate change_id: {change_id}")
        seen.add(change_id)

        def string_list(name: str) -> list[str]:
            value = unit.get(name, [])
            if not isinstance(value, list) or not all(
                isinstance(x, str) and x for x in value
            ):
                raise ContractError(f"{change_id}.{name} must be string list")
            return sorted(set(value))

        operations = unit.get("operations", [])
        if not isinstance(operations, list):
            raise ContractError(f"{change_id}.operations must be a list")

        out.append({
            "change_id": change_id,
            "depends_on": string_list("depends_on"),
            "provides": string_list("provides"),
            "requires": string_list("requires"),
            "operations": operations,
            "metadata": unit.get("metadata", {}),
        })

    return sorted(out, key=lambda x: x["change_id"])


def semantic_change_graph(units: list[dict[str, Any]]) -> dict[str, Any]:
    normalized = _normalize_units(units)
    ids = {x["change_id"] for x in normalized}

    providers: dict[str, list[str]] = defaultdict(list)
    for unit in normalized:
        for token in unit["provides"]:
            providers[token].append(unit["change_id"])
    for token in providers:
        providers[token].sort()

    edges: dict[str, set[str]] = {
        unit["change_id"]: set(unit["depends_on"])
        for unit in normalized
    }
    holds = []
    semantic_edges = []

    # Explicit dependency validation.
    for unit in normalized:
        for dependency in unit["depends_on"]:
            if dependency not in ids:
                holds.append({
                    "change_id": unit["change_id"],
                    "kind": "MISSING_EXPLICIT_DEPENDENCY",
                    "dependency": dependency,
                })

    # Resolve requires -> provider only when unique, or when exactly one provider
    # is already selected by explicit dependency.
    for unit in normalized:
        for token in unit["requires"]:
            candidates = providers.get(token, [])
            candidates = [x for x in candidates if x != unit["change_id"]]
            explicit_candidates = [
                x for x in candidates if x in unit["depends_on"]
            ]

            if len(explicit_candidates) == 1:
                provider = explicit_candidates[0]
                edges[unit["change_id"]].add(provider)
                semantic_edges.append({
                    "from": unit["change_id"],
                    "to": provider,
                    "requires": token,
                    "resolution": "EXPLICIT_PROVIDER",
                })
            elif len(candidates) == 1:
                provider = candidates[0]
                edges[unit["change_id"]].add(provider)
                semantic_edges.append({
                    "from": unit["change_id"],
                    "to": provider,
                    "requires": token,
                    "resolution": "UNIQUE_PROVIDER",
                })
            elif not candidates:
                holds.append({
                    "change_id": unit["change_id"],
                    "kind": "MISSING_SEMANTIC_PROVIDER",
                    "requires": token,
                })
            else:
                holds.append({
                    "change_id": unit["change_id"],
                    "kind": "AMBIGUOUS_SEMANTIC_PROVIDER",
                    "requires": token,
                    "providers": candidates,
                })

    # Stable topological sort.
    dependents: dict[str, set[str]] = defaultdict(set)
    remaining = {key: set(value) for key, value in edges.items()}
    for child, deps in remaining.items():
        for dep in deps:
            if dep in ids:
                dependents[dep].add(child)

    ready = sorted(
        change_id for change_id, deps in remaining.items()
        if not {d for d in deps if d in ids}
    )
    order = []

    while ready:
        current = ready.pop(0)
        order.append(current)
        for child in sorted(dependents.get(current, set())):
            remaining[child].discard(current)
            if (
                not {d for d in remaining[child] if d in ids}
                and child not in order
                and child not in ready
            ):
                ready.append(child)
                ready.sort()

    cyclic = sorted(
        change_id
        for change_id in ids
        if change_id not in order
    )
    if cyclic:
        holds.append({
            "kind": "CHANGE_DEPENDENCY_CYCLE",
            "changes": cyclic,
        })

    # Reuse operation conflict evidence.
    conflict_input = [
        {
            "change_id": unit["change_id"],
            "depends_on": sorted(edges[unit["change_id"]]),
            "operations": unit["operations"],
        }
        for unit in normalized
        if unit["operations"]
    ]
    conflicts = (
        analyze_change_set_conflicts(conflict_input)
        if conflict_input else {
            "status": "CLEAN",
            "conflicts": [],
            "order_dependencies": [],
        }
    )

    if conflicts.get("conflicts"):
        holds.append({
            "kind": "PATCH_OPERATION_CONFLICTS",
            "conflicts": conflicts["conflicts"],
        })

    status = "PASS" if not holds else "HOLD"
    result = {
        "schema": "axm.python-semantic-change-graph.v1",
        "status": status,
        "order": order if status == "PASS" else [],
        "providers": dict(sorted(providers.items())),
        "dependency_edges": [
            {"change_id": key, "depends_on": sorted(value)}
            for key, value in sorted(edges.items())
        ],
        "semantic_edges": sorted(
            semantic_edges,
            key=lambda x: (x["from"], x["requires"], x["to"]),
        ),
        "holds": sorted(
            holds,
            key=lambda x: (
                str(x.get("change_id", "")),
                x["kind"],
                str(x),
            ),
        ),
        "operation_conflicts": conflicts,
        "truth_boundary": (
            "Semantic tokens are declared contracts between change units. "
            "The graph does not invent providers from prose or source-code guesses."
        ),
    }
    result["graph_digest"] = digest_object(result)
    return result
